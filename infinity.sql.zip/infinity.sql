-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 04 2014 г., 12:27
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `infinity`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `channels`
--

DROP TABLE IF EXISTS `channels`;
CREATE TABLE IF NOT EXISTS `channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8_unicode_ci,
  `desc` text COLLATE utf8_unicode_ci,
  `file` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `channels`
--

INSERT INTO `channels` (`id`, `category_id`, `product_id`, `template`, `title`, `price`, `year`, `link`, `short`, `desc`, `file`, `image_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, 1, 0, '1', 'АБСОЛЮТНО НОВЫЙ INFINITI Q50', NULL, NULL, '0', '<p>\r\n	<span style="background-color: initial;"></span>\r\n</p>\r\n<p>\r\n	  Заводит на уровне инстинктов.\r\n</p>', '', NULL, 39, 0, '2014-07-31 14:18:33', '2014-08-01 07:50:17'),
(2, 1, 0, '1', 'INFINITI QX70. ПЕРЕРОЖДЕНИЕ', NULL, NULL, '0', '', '', NULL, 34, 0, '2014-08-01 07:37:50', '2014-08-01 07:37:50'),
(3, 1, 0, '1', 'INFINITI QX60 Hybrid', NULL, NULL, '0', '<p>\r\n	 <span style="background-color: initial;">Роскошь во всех измерениях.<br>\r\n	 </span><span style="background-color: initial;">Преимущество дизеля в гибриде.</span>\r\n</p>', '', NULL, 40, 0, '2014-08-01 07:39:55', '2014-08-01 07:56:18'),
(4, 1, 0, '1', 'INFINITI QX50. ЭЛЕГАНТНОСТЬ ТОЖЕ СПОРТ', NULL, NULL, '0', '', '', NULL, 36, 0, '2014-08-01 07:41:59', '2014-08-01 07:42:24'),
(5, 1, 0, '1', 'INFINITI Q50 EAU ROUGE', NULL, NULL, '0', '<p>\r\n	 <span style="background-color: initial;">Q50 Eau Rouge – яркое воплощение гоночного болида в уникальном стиле автомобилей Infiniti.</span>\r\n</p>', '', NULL, 38, 0, '2014-08-01 07:47:24', '2014-08-01 07:48:47'),
(6, 2, 0, '2', 'Infiniti QX80 в июле по эксклюзивной цене', NULL, NULL, 'infiniti-qx80-v-iyule-po-ksklyuzivnoiy-cene', '<p>\r\n	<span style="background-color: initial;">Стоимость на Infiniti QX80 в июле достигает рекордной отметки — от 3 305 000 руб.</span>\r\n</p>', '<p>\r\n	<span style="background-color: initial;">Данный автомобиль обладает просторным 8-местным салоном премиального уровня, динамикой </span><span style="background-color: initial;">и комфортом полноценного внедорожника и мощным 405-сильным мотором. А опциональное </span><span style="background-color: initial;">разнообразие удивит даже самого искушенного владельца. </span><span style="background-color: initial;">В нашем дилерском центре по-прежнему действует кредитная программа INFINITI FINANCE со </span><span style="background-color: initial;">ставкой 5,75%.</span>\r\n</p>\r\n<div>\r\n	  Мы ждем Вас в любое удобное для Вас время. Получить более подробную информацию, а так же <span style="background-color: initial;">записаться на тест-драйв Вы можете у менеджеров отдела продаж по тел. (863) 305-05-00 и при </span><span style="background-color: initial;">личной встрече.</span>\r\n</div>', NULL, 41, 0, '2014-08-01 08:03:22', '2014-08-01 08:08:46'),
(7, 2, 0, '2', 'Встречайте: абсолютно новый INFINITI Q50', NULL, NULL, 'vstrechaiyte-absolyutno-novaya-model-infiniti-q50-v-rostove', '<p>\r\n	 <span style="background-color: initial;">2 августа с 11:00 до 17:00 мы приглашаем всех тест-драйв.</span>\r\n</p>', '<p>\r\n	 <span style="background-color: initial;">2 августа с 11:00 до 17:00 мы приглашаем всех в салон официального дилера INFINITI на тест-драйв абсолютно новой модели INFINITI Q50. </span><span style="background-color: initial;">Вы сможете увидеть настоящий болид RB9, автомобили в эксклюзивном обвесе от LARTE DESIGN и легендарный FX VETTEL.</span>\r\n</p>', NULL, 42, 0, '2014-08-01 08:10:54', '2014-08-01 08:11:58'),
(8, 2, 0, '2', 'Летнее предложение на сервис', NULL, NULL, 'letnee-predlojenie-na-servis', '<p>\r\n	<span style="background-color: initial;">Летняя диагностика с экономией до 50%</span>\r\n</p>', '<p>\r\n	<span style="background-color: initial;">Лето—время свежих впечатлений и неиспытанных эмоций.  Вам остается только выбрать маршрут для Вашего путешествия, а мы с удовольствием подготовим Ваш автомобиль к яркому сезону. Ждём Вас в нашем сервисном центре Инфинити «Гедон Авто-Премиум» на прохождение летней диагностики с экономией до 50%. (863) 305-05-00.</span>\r\n</p>', NULL, 43, 0, '2014-08-01 08:15:06', '2014-08-01 08:15:06');

-- --------------------------------------------------------

--
-- Структура таблицы `channel_category`
--

DROP TABLE IF EXISTS `channel_category`;
CREATE TABLE IF NOT EXISTS `channel_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `channel_category`
--

INSERT INTO `channel_category` (`id`, `title`, `slug`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Сладер продукции на главной странице', 'main-page-slider', NULL, '2014-07-31 11:12:18', '2014-07-31 11:12:18'),
(2, 'Спецпредложения', 'offer', NULL, '2014-07-31 11:44:26', '2014-07-31 11:44:26'),
(3, 'Автомобили в наличии', 'сars-in-stock', NULL, '2014-08-04 07:50:08', '2014-08-04 07:50:08'),
(4, 'Автомобили с пробегом', 'car-for-sale', NULL, '2014-08-04 07:50:31', '2014-08-04 07:50:31');

-- --------------------------------------------------------

--
-- Структура таблицы `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `published_at` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `events_publication_index` (`publication`),
  KEY `events_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `events_meta`
--

DROP TABLE IF EXISTS `events_meta`;
CREATE TABLE IF NOT EXISTS `events_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` mediumtext COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `events_meta_event_id_index` (`event_id`),
  KEY `events_meta_language_index` (`language`),
  KEY `events_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `settings`, `created_at`, `updated_at`) VALUES
(1, 'products - 1', '', '2014-07-31 12:10:06', '2014-07-31 12:10:06'),
(2, 'products - 1', '', '2014-07-31 14:14:16', '2014-07-31 14:14:16'),
(3, 'products - 1', '', '2014-07-31 14:14:16', '2014-07-31 14:14:16');

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'user', 'Пользователи', '', '', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(3, 'moderator', 'Модераторы', 'admin', '', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news`
--

DROP TABLE IF EXISTS `i18n_news`;
CREATE TABLE IF NOT EXISTS `i18n_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `i18n_news_publication_index` (`publication`),
  KEY `i18n_news_published_at_index` (`published_at`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `i18n_news`
--

INSERT INTO `i18n_news` (`id`, `template`, `slug`, `publication`, `image_id`, `gallery_id`, `created_at`, `updated_at`, `published_at`) VALUES
(1, 'default', '1', 1, 0, 0, '2014-08-01 08:27:26', '2014-08-01 08:27:46', '2014-07-22'),
(2, 'default', '2', 1, 0, 0, '2014-08-01 08:28:39', '2014-08-01 08:28:39', '2014-07-05'),
(3, 'default', '3', 1, 0, 0, '2014-08-01 08:31:06', '2014-08-01 08:31:06', '2014-07-04'),
(4, 'default', '4', 1, 0, 0, '2014-08-01 08:33:42', '2014-08-01 08:33:42', '2014-07-02'),
(5, 'default', '5', 1, 0, 0, '2014-08-01 08:34:35', '2014-08-01 08:34:35', '2014-07-01');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news_meta`
--

DROP TABLE IF EXISTS `i18n_news_meta`;
CREATE TABLE IF NOT EXISTS `i18n_news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_news_meta_news_id_index` (`news_id`),
  KEY `i18n_news_meta_language_index` (`language`),
  KEY `i18n_news_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `i18n_news_meta`
--

INSERT INTO `i18n_news_meta` (`id`, `news_id`, `language`, `title`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Встречайте: абсолютно новая модель INFINITI Q50 в Ростове!', '<p>\n	 <span style="background-color: initial;">2 августа с 11:00 до 17:00 мы приглашаем всех в салон официального дилера INFINITI на тест-драйв абсолютно новой модели INFINITI Q50. </span><span style="background-color: initial;">Вы сможете увидеть настоящий болид RB9, автомобили в эксклюзивном обвесе от LARTE DESIGN и легендарный FX VETTEL.</span>\n</p>', '', 'vstrechaiyte-absolyutno-novaya-model-infiniti-q50-v-rostove', 'Встречайте: абсолютно новая модель INFINITI Q50 в Ростове!', '', '', '', '2014-08-01 08:27:26', '2014-08-01 08:27:46'),
(2, 2, 'ru', 'Летнее предложение на сервис', '<p>\n	<span style="background-color: initial;">Лето—время свежих впечатлений и неиспытанных эмоций.  Вам остается только выбрать маршрут для Вашего путешествия, а мы с удовольствием подготовим Ваш автомобиль к яркому сезону. Ждём Вас в нашем сервисном центре Infiniti «Гедон Авто-Премиум» на прохождение летней диагностики с экономией до 50%.</span>\n</p>', '', 'letnee-predlojenie-na-servis', 'Летнее предложение на сервис', '', '', '', '2014-08-01 08:28:39', '2014-08-01 08:28:39'),
(3, 3, 'ru', 'Специальное предложение для первых владельцев Infiniti Q50', '<p>\n	<span style="background-color: initial;">Оформите предзаказ на покупку Infiniti Q50 бензиновой версии  и получите комплект зимних шин от Pirelli. </span><span style="background-color: initial;">Infiniti Q50 — одна из новейших и самых ярких моделей, входящих в класс среднеразмерных седанов премиум-класса. С качествами, обращенными к уму и сердцу водителя, Infiniti Q50 сочетает в себе черты элегантных концепт-каров бренда и гостеприимный интерьер, отличающийся использованием самых современных технологий и традиционно высокого качества исполнения. </span>\n</p>', '', 'specialnoe-predlojenie-dlya-pervyh-vladelcev-infiniti-q50', 'Специальное предложение для первых владельцев Infiniti Q50', '', '', '', '2014-08-01 08:31:06', '2014-08-01 08:31:06'),
(4, 4, 'ru', 'Эксклюзивное предложение на 5 автомобилей', '<p>\n	 <span style="background-color: initial;">Вы не привыкли себя ограничивать? Мы Вас тоже. В салоне официального дилера действует специальное предложение на 5 автомобилей. Спешите! Условия действуют исключительно до 31.07.14 г.</span>\n</p>', '', 'eksklyuzivnoe-predlojenie-na-5-avtomobileiy', 'Эксклюзивное предложение на 5 автомобилей', '', '', '', '2014-08-01 08:33:42', '2014-08-01 08:33:42'),
(5, 5, 'ru', '20 автомобилей по себестоимости!', '<p>\n	<span style="background-color: initial;">Внимание! Действует беспрецедентная акция - 20 автомобилей по себестоимости. Подробности — при встрече. </span><span style="background-color: initial;">Предложение действует на автомобили в наличии до 30.07.14</span>\n</p>', '', '20-avtomobileiy-po-sebestoimosti', '20 автомобилей по себестоимости!', '', '', '', '2014-08-01 08:34:35', '2014-08-01 08:34:35');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages`
--

DROP TABLE IF EXISTS `i18n_pages`;
CREATE TABLE IF NOT EXISTS `i18n_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `i18n_pages`
--

INSERT INTO `i18n_pages` (`id`, `slug`, `template`, `publication`, `start_page`, `in_menu`, `sort_menu`, `created_at`, `updated_at`) VALUES
(1, '', 'index', 1, 1, 0, 1, '2014-07-31 11:13:05', '2014-07-31 11:13:05'),
(2, 'offers', 'offers', 1, 0, 0, 2, '2014-07-31 11:13:39', '2014-07-31 11:13:39'),
(3, 'news', 'default', 1, 0, 0, 4, '2014-07-31 13:52:55', '2014-07-31 13:53:18'),
(4, 'history', 'default', 1, 0, 0, 5, '2014-08-01 08:35:04', '2014-08-01 08:35:04'),
(5, 'about', 'default', 1, 0, 0, 6, '2014-08-01 08:50:02', '2014-08-01 08:50:02'),
(7, 'reserve-parts', 'default', 1, 0, 0, 44, '2014-08-01 08:50:44', '2014-08-01 13:41:51'),
(8, 'services', 'default', 1, 0, 0, 9, '2014-08-01 08:51:06', '2014-08-01 08:51:06'),
(9, 'persons-of-the-company', 'default', 1, 0, 0, 10, '2014-08-01 08:51:29', '2014-08-01 08:51:29'),
(10, 'vacancies', 'default', 1, 0, 0, 12, '2014-08-01 08:51:44', '2014-08-01 08:52:00'),
(11, 'club', 'default', 1, 0, 0, 13, '2014-08-01 08:52:23', '2014-08-01 08:52:23'),
(12, 'contacts', 'contacts', 1, 0, 0, 16, '2014-08-01 08:55:41', '2014-08-01 10:45:35'),
(13, 'reserve-parts-accessories', 'reserve-parts-accessories', 1, 0, 0, 45, '2014-08-01 14:28:24', '2014-08-01 14:28:24'),
(14, 'сars-for-sale', 'used-cars', 1, 0, 0, 46, '2014-08-04 11:46:18', '2014-08-04 11:46:18');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages_meta`
--

DROP TABLE IF EXISTS `i18n_pages_meta`;
CREATE TABLE IF NOT EXISTS `i18n_pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_meta_page_id_index` (`page_id`),
  KEY `i18n_pages_meta_language_index` (`language`),
  KEY `i18n_pages_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `i18n_pages_meta`
--

INSERT INTO `i18n_pages_meta` (`id`, `page_id`, `language`, `name`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Главная страница', '', 'glavnaya-stranica', 'Главная страница', '', '', '', '2014-07-31 11:13:05', '2014-07-31 11:13:05'),
(2, 2, 'ru', 'Спецпредложения', '', 'specpredlojeniya', 'Спецпредложения', '', '', '', '2014-07-31 11:13:39', '2014-07-31 11:13:39'),
(3, 3, 'ru', 'Новости', '<section class="sect-wrapper"><header>\n<h1>Новости</h1>\n</header></section> [news]', 'novosti', 'Новости', '', '', '', '2014-07-31 13:52:55', '2014-07-31 13:53:18'),
(4, 4, 'ru', 'История', '<section class="sect-wrapper information history">\n<h1>История Infiniti</h1>\n<div class="history-banner">\n	<img class="history-banner" src="/theme/img/history-banner.jpg">\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="medium-desc">\n			                             Целью создания бренда Infiniti с самого начала являлось предложение новой концепции автомобильной роскоши, в которой на первое место выходит удовольствие от вождения и неповторимая индивидуальность.\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="big-desc">\n			                             Автомобильная роскошь\n		</div>\n	</div>\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="history-date">\n			                                 1989\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="desc">\n			                                                              С первых дней своего существования Infiniti отличался инновационным дизайном, техническим совершенством, широким использованием современных технологий и новейших технических решений, а также заботой о каждом клиенте в течение всего срока эксплуатации автомобиля.                             <br>\n			                                                              Официально продажи Infiniti стартовали в США 8 ноября 1989 года. Однако проект создания Infiniti уходит корнями в 1985 год, когда с целью разработки нового бренда высококачественных престижных автомобилей в компании Nissan была образована сверхсекретная группа Horizon Task Force.                             <br>\n			                                                              Группа Horizon Task Force отобрала и тщательно изучила несколько компаний, предоставляющих сервисные услуги, но не относящихся к автомобильному бизнесу, в том числе курьерскую службу Federal Express, гостиничную сеть Four Seasons и торговую сеть Nordstrom. Впоследствии выводы, сделанные группой Horizon Task Force, оказали непосредственное влияние на все аспекты проекта, начиная от дизайнерского решения первых салонов, больше похожих на роскошный отель, нежели на дилерский центр, и заканчивая корпоративной символикой бренда — от оформления визитных карточек до упаковки запчастей и аксессуаров.                             <br>\n		</div>\n	</div>\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="medium-desc">\n			                                                              Была разработана новая концепция – программа привилегированного обслуживания покупателей Infiniti. Она затрагивала не только покупку, но и последующий процесс обслуживания автомобиля, вплоть до бесплатного предоставления подменного автомобиля — практика, которая в то время никем не использовалась.                             <br>\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="big-desc">\n			                             Infiniti Total Ownership Experience\n		</div>\n	</div>\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="history-date">\n			                             1987\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="desc">\n			                                                              Название, выбранное для нового престижного бренда в июле 1987 года, символизирует непрерывное движение вперед, к новым горизонтам. Так родилось название с измененным написанием имени бренда с четырьмя буквами «i» в слове «бесконечность» (Infiniti вместо Infinity) — и эмблема, с двумя линиями, стремящимися к бесконечно удаленной точке горизонта.                             <br>\n			                                                              Так Infiniti раскрыла автомобильному миру свою философию, основанную на оригинальности автомобилей, их техническом совершенстве, высоком качестве и эмоциональности вождения.                             <br>\n		</div>\n	</div>\n</div>\n</section>', 'istoriya', 'История', '', '', '', '2014-08-01 08:35:04', '2014-08-01 08:35:04'),
(5, 5, 'ru', 'О компании', '', 'o-kompanii', 'О компании', '', '', '', '2014-08-01 08:50:02', '2014-08-01 08:50:02'),
(7, 7, 'ru', 'Сервис и запчасти', '<main><section class="information">\n<ul id="tabs" class="tabs">\n	<li data-tab="service" class="active">Сервис</li>\n	<li data-tab="spares">Запчасти</li>\n	<li data-tab="guarantee">Гарантия</li>\n</ul>\n<ul id="tabContent" class="tabs-content">\n	<li class="tab-li active" data-tab="service">\n	<h2>Техническое обслуживание</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-40">\n			<span style="background-color: initial;">Официальный сервисный центр INFINITI «Гедон Авто-Премиум» предлагает исключительно индивидуальный сервис. Современное оборудование, опыт и профессионализм сотрудников, оперативность в планировании и проведении работ, поэтапный  контроль качества в сочетании с новейшими комплектующими и расходными материалами - вот то, что определяет высокую степень доверия к  нам сегодня.</span>\n		</div>\n		<div class="desc">\n			            С нами Вы может быть абсолютно уверенны в:\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">надёжности вашего автомобиля;</span></li>\n				<li class="typical-li">  Вашей личной безопасности и безопасности Ваших близких при эксплуатации вашего автомобиля;</li>\n				<li class="typical-li"><span style="background-color: initial;">своевременном выявлении и оперативном устранении любых неисправностей;</span> </li>\n				<li class="typical-li">оптимально выгодных предложениях на техническое обслуживание — мы дорожим нашей репутацией и рекомендуем только действительно необходимые к проведению работы; </li>\n				<li class="typical-li">продление срока эксплуатации автомобиля   </li>\n			</ul>\n		</div>\n	</div>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			       Также мы можем предоставить Вам историю ремонта вашего автомобиля, что значительно повысит его стоимость при продаже.  При обслуживании мы используем только  оригинальные запасные части, что гарантирует и соответствие Вашего автомобиля всем техническим нормам безопасности, а так же экономичную и надежную его эксплуатацию.  Напоминаем, что только обслуживание у официального дилера позволит быть уверенным в качестве выполняемых работ и позволит Вам надежно и экономично использовать Ваш автомобиль.\n		</div>\n	</div>\n	<h3>ПРОГРАММА «ВМЕСТЕ НАВСЕГДА»</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-40">\n			      Если Ваш автомобиль старше 3-х лет, предлагаем воспользоваться программой поддержки автомобилей с истекшим гарантийным сроком «Вместе навсегда». Вы всегда можете воспользоваться особыми преимуществами качественного сервиса на максимально выгодных условиях:\n		</div>\n		<div class="column column-60">\n			                          Вы можете воспользоваться особыми преимуществами качественного сервиса  на максимально выгодных условиях:\n			<ul class="typical-ul">\n				<li>  10% на услуги СТО и запчасти - на а/м INFINITI c пробегом более 100 000 км</li>\n				<li><span style="background-color: initial;">15% на услуги СТО и запчасти – INFINITI старше 3-х лет</span></li>\n				<li><span style="background-color: initial;">20% на услуги СТО и запчасти - INFINITI старше 5-х лет</span></li>\n			</ul>\n		</div>\n	</div>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			 Сервисный центр «Гедон Авто-Премиум» — это максимальная степень надежности, гарантия качества выполняемых работ и профессиональный подход в любой ситуации.  Не стоит ждать, пока наступит неисправность. Доверьте заботу об автомобиле нашим профессионалам. Вы можете записаться на сервис, воспользовавшись формой online записи или по телефону (863) 305-05-00.\n		</div>\n	</div>\n	 </li>\n	<li class="tab-li" data-tab="spares">\n	<h2>Запасные части и аксессуары</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-40">\n			                        Опытные специалисты автоцентра «Гедон Авто-Премиум» помогут сделать Infiniti уникальным, соответствующим именно Вашему стилю.\n		</div>\n		<div class="column column-60">\n			<div class="desc">\n				                       Оригинальные запасные части и аксессуары Infiniti – отличная возможность придать Вашему автомобилю эксклюзивные черты. Установка дополнительного оборудования позволит подчеркнуть неповторимость и совершенство каждого автомобиля Infiniti, максимум комфорта, надежности и безопасности.\n			</div>\n		</div>\n	</div>\n	<h3>В нашем автоцентре Вы можете приобрести и установить:</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			<ul class="typical-ul">\n				<li><span style="background-color: initial;">Хромированные элементы экстерьера,</span></li>\n				<li>Ксеноновые фары,</li>\n				<li>Спутниковые охранные системы,</li>\n				<li>Механические противоугонные устройства,</li>\n				<li>Защита двигателя и АКПП,</li>\n				<li>Предпусковые обогреватели двигателя и салона,</li>\n				<li>Аудио-видео устройства,</li>\n				<li>Навигационное оборудование,</li>\n				<li>Аэродинамический обвес,</li>\n				<li>Литые, кованные колесные диски,</li>\n				<li>Произвести тонировку или бронировку стекол,</li>\n				<li>Произвести антискольное покрытие кузова.</li>\n			</ul>\n		</div>\n	</div>\n	<h2>Оптовая продажа запчастей</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-40">\n			                        Для оптовых покупателей действует гибкая система скидок, размер которой зависит от выбранного ассортимента товара и объема заказа.\n		</div>\n		<div class="column column-60">\n			<div class="desc">\n				                       Компания «Гедон Авто-Премиум» предлагает оптовые продажи оригинальных запчастей для автомобилей Infiniti.  Поставка запчастей осуществляется под заказ со складов компании и с центрального склада производителя в Москве.\n			</div>\n		</div>\n	</div>\n	<h3>Ваши преимущества:</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			<ul class="typical-ul">\n				<li><span style="background-color: initial;">только оригинальные запасные части,</span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">широкий ассортимент в наличии для всего модельного ряда Infiniti, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">гибкая ценовая политика, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">сжатые сроки поставки, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">специальные программы и скидки, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">квалифицированное техническое сопровождение в течение всего заказа.</span></li>\n			</ul>\n		</div>\n	</div>\n	 </li>\n	<li class="tab-li" data-tab="guarantee">\n	<h2>Гарантия</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-40">\n			                 Мы уверены в качестве и надежности автомобилей Infiniti.\n		</div>\n		<div class="column column-60">\n			<div class="desc">\n				                На новые автомобили Infiniti предоставляется гарантия 3 года или 100 000 км пробега, в зависимости от того, что наступит первым.\n			</div>\n		</div>\n	</div>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">Гарантийные обязательства Infiniti распространяются на каждый новый автомобиль Infiniti, проданный, зарегистрированный и эксплуатируемый на территории Российской Федерации, где имеются официальные дилеры Infiniti.</span></li>\n				<li>  Распространяется на все узлы и агрегаты автомобиля если неисправность вызвана использованием некачественных материалов или нарушением технологии производства.</li>\n				<li><span style="background-color: initial;">Не распространяется на любые запасные части и работы, связанные с проведением обязательного или рекомендуемого технического обслуживания.</span></li>\n				<li><span style="background-color: initial;">В случае неожиданной поломки Вашего автомобиля, когда автомобиль обездвижен или его эксплуатация запрещена правилами дорожного движения, он будет бесплатно транспортирован до ближайшего сервисного центра Infiniti или авторизованного регионального сервисного центра Nissan.</span></li>\n				<li><span style="background-color: initial;">Гарантия против сквозной коррозии – 12 лет.</span></li>\n				<li><span style="background-color: initial;">Гарантия на окраску составляет 3 года независимо от пробега.</span></li>\n				<li><span style="background-color: initial;">Гарантия на запасные части, приобретенные и установленные у официального дилера, — 1 год.</span></li>\n			</ul>\n			               При возникновении вопросов обращайтесь к нашему инженеру по гарантии.\n		</div>\n	</div>\n	</li>\n </section></main>', 'servis-i-zapchasti', 'Сервис и запчасти', '', '', '', '2014-08-01 08:50:44', '2014-08-01 13:41:51'),
(8, 8, 'ru', 'Услуги', '', 'uslugi', 'Услуги', '', '', '', '2014-08-01 08:51:06', '2014-08-01 08:51:06'),
(9, 9, 'ru', 'Лица компании', '', 'lica-kompanii', 'Лица компании', '', '', '', '2014-08-01 08:51:29', '2014-08-01 08:51:29'),
(10, 10, 'ru', 'Вакансии', '', 'vakansii', 'Вакансии', '', '', '', '2014-08-01 08:51:44', '2014-08-01 08:52:00'),
(11, 11, 'ru', 'Клуб', '', 'klub', 'Клуб', '', '', '', '2014-08-01 08:52:23', '2014-08-01 08:52:23'),
(12, 12, 'ru', 'Контакты', '', 'kontakty', 'Контакты', '', '', '', '2014-08-01 08:55:41', '2014-08-01 10:45:35'),
(13, 13, 'ru', 'Сервис и запчасти. Аксессуары', '', 'servis-i-zapchasti-aksessuary', 'Сервис и запчасти. Аксессуары', '', '', '', '2014-08-01 14:28:24', '2014-08-01 14:28:24'),
(14, 14, 'ru', 'Автомобили с пробегом', '', 'avtomobili-s-probegom', 'Автомобили с пробегом', '', '', '', '2014-08-04 11:46:18', '2014-08-04 11:46:18');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_i18n_pages_table', 1),
('2014_01_01_100070_create_i18n_news_table', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_tags_table', 1),
('2014_06_19_133757_create_production_tables', 1),
('2014_07_14_124747_create_channels_tables', 1),
('2014_07_17_130340_create_session_table', 1),
('2014_07_23_150206_create_events_table', 1),
('2014_07_29_104336_create_production_video', 1),
('2014_07_30_111418_create_production_colors', 1),
('2014_07_30_142645_create_production_complections', 1),
('2014_07_31_081207_create_production_accessories', 1),
('2014_07_31_081802_create_production_accessories_categories', 1),
('2014_07_31_081809_create_production_accessories_accessibility', 1),
('2014_08_01_104650_create_related_production', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'pages', 1, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'news', 1, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(3, 'galleries', 1, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:41'),
(4, 'tags', 0, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:38'),
(5, 'production', 1, 0, '2014-07-31 11:11:39', '2014-07-31 11:11:39'),
(6, 'events', 1, 0, '2014-07-31 11:11:42', '2014-07-31 11:11:42'),
(7, 'channels', 1, 0, '2014-07-31 11:11:43', '2014-07-31 11:11:43');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, '1406808517_1574.jpg', '0', '2014-07-31 12:08:38', '2014-07-31 12:08:38'),
(5, '1406808967_1814.jpg', '0', '2014-07-31 12:16:07', '2014-07-31 12:16:07'),
(6, '1406813549_1794.jpg', '0', '2014-07-31 13:32:29', '2014-07-31 13:32:29'),
(7, '1406813612_1701.jpg', '0', '2014-07-31 13:33:32', '2014-07-31 13:33:32'),
(8, '1406813643_1988.jpg', '0', '2014-07-31 13:34:03', '2014-07-31 13:34:03'),
(9, '1406813674_1020.jpg', '0', '2014-07-31 13:34:35', '2014-07-31 13:34:35'),
(10, '1406813696_1132.jpg', '0', '2014-07-31 13:34:56', '2014-07-31 13:34:56'),
(11, '1406813796_1658.jpg', '0', '2014-07-31 13:36:36', '2014-07-31 13:36:36'),
(12, '1406813829_1414.jpg', '0', '2014-07-31 13:37:09', '2014-07-31 13:37:09'),
(13, '1406813908_1137.jpg', '0', '2014-07-31 13:38:28', '2014-07-31 13:38:28'),
(14, '1406813929_1488.jpg', '0', '2014-07-31 13:38:49', '2014-07-31 13:38:49'),
(15, '1406813955_1440.jpg', '0', '2014-07-31 13:39:15', '2014-07-31 13:39:15'),
(16, '1406814004_1303.jpg', '0', '2014-07-31 13:40:04', '2014-07-31 13:40:04'),
(17, '1406814119_1511.jpg', '0', '2014-07-31 13:41:59', '2014-07-31 13:41:59'),
(19, '1406814584_1804.png', '0', '2014-07-31 13:49:44', '2014-07-31 13:49:44'),
(20, '1406815097_1047.png', '0', '2014-07-31 13:58:17', '2014-07-31 13:58:17'),
(21, '1406815978_1699.jpeg', '2', '2014-07-31 14:12:59', '2014-07-31 14:14:16'),
(22, '1406815980_1997.jpeg', '2', '2014-07-31 14:13:00', '2014-07-31 14:14:16'),
(23, '1406815980_1544.jpeg', '2', '2014-07-31 14:13:01', '2014-07-31 14:14:16'),
(24, '1406815981_1260.jpeg', '2', '2014-07-31 14:13:02', '2014-07-31 14:14:16'),
(25, '1406816046_1997.jpeg', '3', '2014-07-31 14:14:08', '2014-07-31 14:14:16'),
(26, '1406816047_1057.jpeg', '3', '2014-07-31 14:14:08', '2014-07-31 14:14:16'),
(27, '1406816049_1376.jpeg', '3', '2014-07-31 14:14:09', '2014-07-31 14:14:16'),
(34, '1406878667_1424.jpeg', '-1', '2014-08-01 07:37:47', '2014-08-01 07:37:50'),
(36, '1406878914_1101.jpeg', '-1', '2014-08-01 07:41:55', '2014-08-01 07:41:59'),
(38, '1406879324_1625.jpg', '-1', '2014-08-01 07:48:45', '2014-08-01 07:48:47'),
(39, '1406879414_1100.jpeg', '-1', '2014-08-01 07:50:15', '2014-08-01 07:50:17'),
(40, '1406879775_1169.jpeg', '-1', '2014-08-01 07:56:16', '2014-08-01 07:56:18'),
(41, '1406880177_1211.jpeg', '-1', '2014-08-01 08:02:58', '2014-08-01 08:03:22'),
(42, '1406880617_1491.jpeg', '-1', '2014-08-01 08:10:17', '2014-08-01 08:10:54'),
(43, '1406880902_1292.jpeg', '-1', '2014-08-01 08:15:03', '2014-08-01 08:15:06'),
(44, '1406882720_1384.jpg', '0', '2014-08-01 08:45:20', '2014-08-01 08:45:20'),
(46, '1406883525_1336.jpg', '0', '2014-08-01 08:58:45', '2014-08-01 08:58:45'),
(47, '1406884135_1958.jpg', '0', '2014-08-01 09:08:55', '2014-08-01 09:08:55'),
(48, '1406884745_1651.jpg', '0', '2014-08-01 09:19:05', '2014-08-01 09:19:05'),
(49, '1406885158_1709.jpg', '0', '2014-08-01 09:25:58', '2014-08-01 09:25:58'),
(52, '1406887791_1136.jpg', '0', '2014-08-01 10:09:51', '2014-08-01 10:09:51'),
(53, '1406888220_1203.jpg', '0', '2014-08-01 10:17:00', '2014-08-01 10:17:00'),
(54, '1406888744_1203.jpg', '0', '2014-08-01 10:25:44', '2014-08-01 10:25:44');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `publication` tinyint(1) unsigned DEFAULT '1',
  `brochure` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `image_menu_id` int(10) unsigned DEFAULT NULL,
  `gallery_color_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_publication_index` (`publication`),
  KEY `image_menu_id` (`image_menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `category_id`, `publication`, `brochure`, `in_menu`, `image_id`, `image_menu_id`, `gallery_color_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '/uploads/1406901925_1768.pdf', 1, 1, 44, 0, 0, '2014-07-31 12:08:41', '2014-08-01 14:05:25'),
(2, 1, 1, NULL, 1, 0, 46, 0, 0, '2014-08-01 08:50:25', '2014-08-01 13:03:31'),
(3, 1, 1, NULL, NULL, 0, 47, 0, 0, '2014-08-01 09:09:02', '2014-08-01 13:03:46'),
(4, 1, 1, NULL, 1, 0, 48, 0, 0, '2014-08-01 09:20:12', '2014-08-01 13:04:08'),
(5, 2, 1, NULL, 1, 0, 49, 0, 0, '2014-08-01 09:26:55', '2014-08-01 13:04:24'),
(6, 2, 1, NULL, 1, 0, 54, 0, 0, '2014-08-01 09:37:33', '2014-08-01 13:04:38'),
(7, 2, 1, NULL, 1, 0, 52, 0, 0, '2014-08-01 10:10:34', '2014-08-01 13:04:50'),
(8, 2, 1, NULL, 1, 0, 53, 0, 0, '2014-08-01 10:17:05', '2014-08-01 13:05:00');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessories`
--

DROP TABLE IF EXISTS `products_accessories`;
CREATE TABLE IF NOT EXISTS `products_accessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `category_id` int(10) unsigned DEFAULT '0',
  `accessibility_id` int(10) unsigned DEFAULT '0',
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `products_accessories`
--

INSERT INTO `products_accessories` (`id`, `title`, `price`, `description`, `category_id`, `accessibility_id`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 6, 1, '2014-07-31 13:32:52', '2014-07-31 13:32:52'),
(2, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 7, 1, '2014-07-31 13:33:45', '2014-07-31 13:33:45'),
(3, 'Полиуретановые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное полиуретановые покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 8, 1, '2014-07-31 13:34:20', '2014-07-31 13:34:20'),
(4, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 9, 1, '2014-07-31 13:34:42', '2014-07-31 13:34:42'),
(5, 'Спортивная радиаторная решетка', '0', '<p>\n	<span style="background-color: initial;">Стильная радиаторная решетка придает спортивный характер Вашему автомобилю.</span>\n</p>', 1, 1, 10, 1, '2014-07-31 13:35:05', '2014-07-31 13:35:05'),
(6, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид. На брызговиках имеются рельефные контуры, благодаря которым они точно устанавливаются в колесные арки.</span>\n</p>', 2, 1, 11, 1, '2014-07-31 13:36:52', '2014-07-31 13:36:52'),
(7, 'Спойлер на крышку багажника', '0', '<p>\n	<span style="background-color: initial;">Стильный спойлер придает агрессивный вид Вашему Infiniti.</span>\n</p>', 2, 1, 12, 1, '2014-07-31 13:37:17', '2014-07-31 13:37:17'),
(8, 'Внешняя подсветка порогов', '0', '<p>\n	<span style="background-color: initial;">Отлично подчеркивает внешний вид спортивного автомобиля. Помогает при парковке в темное время суток.</span>\n</p>', 2, 1, 13, 1, '2014-07-31 13:38:32', '2014-07-31 13:38:33'),
(9, 'Легкосплавный диск R17', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti.</span>\n</p>', 2, 1, 14, 1, '2014-07-31 13:38:57', '2014-07-31 13:38:57'),
(10, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 15, 1, '2014-07-31 13:39:21', '2014-07-31 13:39:21'),
(11, 'Багажник на крышу', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система для крепления багажника на крыше автомобиля идеально вписывается в экстерьер и гармонично сочетается с формой крыши. Устанавливается с помощью надежных крепежей. Грузоподъемность 75кг.</span>\n</p>', 3, 1, 16, 1, '2014-07-31 13:40:17', '2014-07-31 13:40:17'),
(12, 'Багажник на крышу', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система для крепления багажника на крыше автомобиля идеально вписывается в экстерьер и гармонично сочетается с формой крыши. Устанавливается с помощью надежных крепежей. Грузоподъемность 75кг.</span>\n</p>', 4, 1, 17, 1, '2014-07-31 13:42:05', '2014-07-31 13:42:05');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessory_accessibility`
--

DROP TABLE IF EXISTS `products_accessory_accessibility`;
CREATE TABLE IF NOT EXISTS `products_accessory_accessibility` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `products_accessory_accessibility`
--

INSERT INTO `products_accessory_accessibility` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'в наличии', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'под заказ', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessory_categories`
--

DROP TABLE IF EXISTS `products_accessory_categories`;
CREATE TABLE IF NOT EXISTS `products_accessory_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `products_accessory_categories`
--

INSERT INTO `products_accessory_categories` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'интерьер', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'аксессуары внешнего дизайна', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(3, 'для багажа', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(4, 'аксессуары в багажник', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(5, 'противоугонные системы', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(6, 'другие аксессуары', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `products_category`
--

DROP TABLE IF EXISTS `products_category`;
CREATE TABLE IF NOT EXISTS `products_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `products_category`
--

INSERT INTO `products_category` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Седаны и купе', NULL, '2014-07-31 11:49:17', '2014-07-31 11:49:17'),
(2, 'Кроссоверы и внедорожники', NULL, '2014-07-31 11:49:30', '2014-07-31 11:49:30');

-- --------------------------------------------------------

--
-- Структура таблицы `products_colors`
--

DROP TABLE IF EXISTS `products_colors`;
CREATE TABLE IF NOT EXISTS `products_colors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `products_colors`
--

INSERT INTO `products_colors` (`id`, `title`, `color`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 'виктор', '#ff0000', 5, 1, '2014-07-31 12:16:25', '2014-07-31 12:16:25');

-- --------------------------------------------------------

--
-- Структура таблицы `products_complections`
--

DROP TABLE IF EXISTS `products_complections`;
CREATE TABLE IF NOT EXISTS `products_complections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brochure` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `dynamics` text COLLATE utf8_unicode_ci,
  `exterior` text COLLATE utf8_unicode_ci,
  `interior` text COLLATE utf8_unicode_ci,
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `products_complections`
--

INSERT INTO `products_complections` (`id`, `title`, `price`, `brochure`, `description`, `dynamics`, `exterior`, `interior`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 'Q50 2.0 RWD Base', '1 450 000 руб', NULL, '<ul>\r\n	<li>2,0-литровый бензиновый двигатель с турбонаддувом мощностью 211л.с.</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения</li>\r\n	<li>17" легкосплавные колесные диски, летние шины размерности 225/55R17</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>17" легкосплавные колесные диски, летние шины размерности 225/55R17</li>\r\n	<li>Хромированная декоративная решетка радиатора</li>\r\n	<li>Задний спойлер интегрированный в крышку багажника</li>\r\n	<li>Окрашенные в цвет кузова ручки дверей</li>\r\n	<li>Бамперы, окрашенные в цвет кузова</li>\r\n	<li>Боковые молдинги, окрашенные в цвет кузова</li>\r\n	<li>Две хромированные насадки на выпускные трубы</li>\r\n	<li>Стеклоочиститель с прерывистым режимом работы, зависящим от скорости движения автомобиля</li>\r\n	<li>(ASAP) Краска сопротивляющаяся мелким царапинам</li>\r\n</ul>', '<ul>\r\n	<li>5-местный салон</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>Подогрев лобового стекла в районе дворников</li>\r\n	<li>Автоматический двузонный климат-контроль</li>\r\n	<li>Датчик наружной температуры</li>\r\n	<li>Вентиляционные отверстия в задней части центральной консоли и воздуховоды отопителя на полу</li>\r\n	<li>Электрические стеклоподъемники двери водителя с режимом однократного нажатия для подъема/опускания и автореверсом</li>\r\n	<li>Замки дверей с электроприводом</li>\r\n	<li>Электрический привод открывания крышки багажника</li>\r\n	<li>Сохраняющееся в течение 45 секунд после остановки двигателя питание привода стекол дверей</li>\r\n	<li>Ключ для обслуживающего персонала с функцией блокировки багажника</li>\r\n	<li>Удлинители передних солнцезащитных козырьков</li>\r\n	<li>Футляр для солнечных очков</li>\r\n	<li>Двойные передние и задние подстаканники</li>\r\n	<li>Передний подлокотник с емкостью для хранения вещей и электрической розеткой напряжением 12В</li>\r\n	<li>Откидной центральный подлокотник заднего сиденья с емкостью для хранения вещей</li>\r\n	<li>Зуммер предупреждения о забытых в автомобиле ключах</li>\r\n	<li>Зуммер предупреждения о невыключенных фарах</li>\r\n	<li>Световой индикатор предупреждения о незакрытой двери багажника</li>\r\n	<li>Солнцезащитные козырьки с зеркалом и подсветкой (для водителя и переднего пассажира)</li>\r\n	<li>Два подголовника задних сидений</li>\r\n	<li>Система давления в шинах (TPMS)</li>\r\n	<li>Cветодиодная подсветка салона спереди</li>\r\n</ul>', 19, 1, '2014-07-31 13:49:51', '2014-07-31 13:52:38'),
(2, 'Q50 2.0 RWD Elegance', '1 530 000 руб', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Base</li>\r\n	<li>Кожаный салон</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Base</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Base</li>\r\n	<li>Кожаный салон</li>\r\n</ul>', 20, 1, '2014-07-31 13:58:29', '2014-07-31 13:59:28');

-- --------------------------------------------------------

--
-- Структура таблицы `products_meta`
--

DROP TABLE IF EXISTS `products_meta`;
CREATE TABLE IF NOT EXISTS `products_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_title` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` mediumtext COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `in_menu_content` text COLLATE utf8_unicode_ci,
  `specifications` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_meta_product_id_index` (`product_id`),
  KEY `products_meta_language_index` (`language`),
  KEY `products_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `products_meta`
--

INSERT INTO `products_meta` (`id`, `product_id`, `language`, `title`, `price`, `short_title`, `preview`, `content`, `in_menu_content`, `specifications`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'INFINITI Q50', '1295000', 'Q50', '<p>\r\n	        ОБЪЕКТ ПРИТЯЖЕНИЯ\r\n</p>\r\n<ul>\r\n	<li>Двигатель 2.0 л R-4, 16V С Турбонаддувом</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний привод</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     Infiniti Q50 – основные особености                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/OQUApuF90akguGBH.jpg">\r\n		<div class="column-body">\r\n			<h2>НУЛЕВАЯ ПОДЪЕМНАЯ СИЛА</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					                 Скорость обладает особой магией. В миг, когда устремляешься вперед, ощущаешь, с какой силой ускоряются эмоции, как много страсти под капотом. Это больше, чем просто движение. Аэродинамика автомобиля направляет воздушные потоки так, чтобы ваш Q50 сохранял идеальный баланс, устойчивость и связь с дорогой даже во время сильного ветра и встречных потоков воздуха.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/qzCYL3h0Fe7fOJjH.jpg">\r\n		<div class="column-body">\r\n			<h2>СИСТЕМА ПРЕДОТВРАЩЕНИЯ СТОЛКНОВЕНИЯ ПРИ ДВИЖЕНИИ ЗАДНИМ ХОДОМ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Уникальная технология, определеляющая с помощью сенсорсов наличие помехи сзади. Если что-то появляется на пути при движении назад, система предупредит вас и при необходимости активирует тормоза для избежания столкновения.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		<img src="/uploads/Mea5vNmJnLAyJhss.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>АДАПТИВНОЕ ЭЛЕКТРОННОЕ УПРАВЛЕНИЕ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Расширяет чувство полного контроля за рулем, вы можете полностью расслабиться: </span><span style="background-color: initial;">электронное адаптивное рулевое управление обеспечивает беспрецедентный уровень управляемости и устраняется вибрация на рулевом колесе.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>АКТИВНЫЙ КРУИЗ-КОНТРОЛЬ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Система автоматически снижает скорость автомобиля, когда трафик перед вами замедляется. Когда путь свободен, автомобиль ускоряется обратно к желаемой скорости. Лазерные сенсоры и цифровой локатор обнаруживают впереди идущие автомобили и поддерживают выбранную Вами дистанцию.  Меньше усилий, больше легкости.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/jaYRH5eVQ1d0308B.jpg">\r\n		<div class="column-body">\r\n			<h2>СИЛА В КАЖДОМ ПРИКОСНОВЕНИИ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">INFINITI INTOUCH™ включает вашу цифровую жизнь. Все приложения доступны с одного прикосновения. Одно движение пальцем – и вы в электронной почте, в вашей аудиотеке или в социальных сетях.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/UjEAQlKdJhLljkiM.jpg">\r\n		<div class="column-body">\r\n			<h2>ДИСПЛЕЙ КРУГОВОГО ОБЗОРА                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Революционная технология Infiniti, помогающая вам видеть автомобиль и окружающую обстановку сверху. С обзором 360° вы получаете стопроцентную уверенность в своих действиях.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/yHU1Ene28Vo0OxI5.jpg">\r\n		<div class="column-body">\r\n			<h2>ПРЯМОЙ ОТКЛИК                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Технология гибридного двигателя Infiniti Direct Response («Прямой отклик»)® не попросит Вас выбирать между эффективностью и экспрессией. С расходом бензина 6.8 литров на 100 км Вы получаете 355 лошадиных сил с захватывающей быстротой. Мощный двигатель дает высокий крутящий момент на большем диапазоне оборотов и дольше выдерживает перегрузки.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/1nRdKOxizGmVP3j9.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕПРЕВЗОЙДЕННАЯ ФАКТУРА МАТЕРИАЛОВ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Прикоснитесь к материалу отделки салона и вы ощутите невероятное чувство. За полтора года мы опросили 360 человек по всему миру, чтобы определить самые приятные тактильные ощущения. А затем мы создали материалы, на 100% отвечающие вашим представлениям об идеальном прикосновении.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', '<p>\r\n	<span style="background-color: initial;">ОБЪЕКТ ПРИТЯЖЕНИЯ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель 2.0 л R-4, 16V С Турбонаддувом</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний привод</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     Infiniti Q50 – основные особености                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/OQUApuF90akguGBH.jpg">\r\n		<div class="column-body">\r\n			<h2>НУЛЕВАЯ ПОДЪЕМНАЯ СИЛА</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					                 Скорость обладает особой магией. В миг, когда устремляешься вперед, ощущаешь, с какой силой ускоряются эмоции, как много страсти под капотом. Это больше, чем просто движение. Аэродинамика автомобиля направляет воздушные потоки так, чтобы ваш Q50 сохранял идеальный баланс, устойчивость и связь с дорогой даже во время сильного ветра и встречных потоков воздуха.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/qzCYL3h0Fe7fOJjH.jpg">\r\n		<div class="column-body">\r\n			<h2>СИСТЕМА ПРЕДОТВРАЩЕНИЯ СТОЛКНОВЕНИЯ ПРИ ДВИЖЕНИИ ЗАДНИМ ХОДОМ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Уникальная технология, определеляющая с помощью сенсорсов наличие помехи сзади. Если что-то появляется на пути при движении назад, система предупредит вас и при необходимости активирует тормоза для избежания столкновения.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		<img src="/uploads/Mea5vNmJnLAyJhss.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>АДАПТИВНОЕ ЭЛЕКТРОННОЕ УПРАВЛЕНИЕ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Расширяет чувство полного контроля за рулем, вы можете полностью расслабиться: </span><span style="background-color: initial;">электронное адаптивное рулевое управление обеспечивает беспрецедентный уровень управляемости и устраняется вибрация на рулевом колесе.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>АКТИВНЫЙ КРУИЗ-КОНТРОЛЬ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Система автоматически снижает скорость автомобиля, когда трафик перед вами замедляется. Когда путь свободен, автомобиль ускоряется обратно к желаемой скорости. Лазерные сенсоры и цифровой локатор обнаруживают впереди идущие автомобили и поддерживают выбранную Вами дистанцию.  Меньше усилий, больше легкости.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/jaYRH5eVQ1d0308B.jpg">\r\n		<div class="column-body">\r\n			<h2>СИЛА В КАЖДОМ ПРИКОСНОВЕНИИ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">INFINITI INTOUCH™ включает вашу цифровую жизнь. Все приложения доступны с одного прикосновения. Одно движение пальцем – и вы в электронной почте, в вашей аудиотеке или в социальных сетях.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/UjEAQlKdJhLljkiM.jpg">\r\n		<div class="column-body">\r\n			<h2>ДИСПЛЕЙ КРУГОВОГО ОБЗОРА                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Революционная технология Infiniti, помогающая вам видеть автомобиль и окружающую обстановку сверху. С обзором 360° вы получаете стопроцентную уверенность в своих действиях.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/yHU1Ene28Vo0OxI5.jpg">\r\n		<div class="column-body">\r\n			<h2>ПРЯМОЙ ОТКЛИК                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Технология гибридного двигателя Infiniti Direct Response («Прямой отклик»)® не попросит Вас выбирать между эффективностью и экспрессией. С расходом бензина 6.8 литров на 100 км Вы получаете 355 лошадиных сил с захватывающей быстротой. Мощный двигатель дает высокий крутящий момент на большем диапазоне оборотов и дольше выдерживает перегрузки.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/1nRdKOxizGmVP3j9.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕПРЕВЗОЙДЕННАЯ ФАКТУРА МАТЕРИАЛОВ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Прикоснитесь к материалу отделки салона и вы ощутите невероятное чувство. За полтора года мы опросили 360 человек по всему миру, чтобы определить самые приятные тактильные ощущения. А затем мы создали материалы, на 100% отвечающие вашим представлениям об идеальном прикосновении.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', 'infiniti-q50', 'INFINITI Q50', '', '', '', '2014-07-31 12:08:41', '2014-08-01 14:05:25'),
(2, 2, 'ru', 'INFINITI Q60 Coupe', '', 'Q60', '<p>\r\n	   ЖАЖДА АДРЕНАЛИНА\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с.</li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	  и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">ЖАЖДА АДРЕНАЛИНА</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с.</li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '', 'infiniti-q60-coupe', 'INFINITI Q60 Coupe', '', '', '', '2014-08-01 08:50:25', '2014-08-01 13:03:31'),
(3, 3, 'ru', 'INFINITI Q60 Cabrio', '', 'Q60', '<p>\r\n	    ОТКРОЙТЕ ТАЙНУ, ИЗВЕСТНУЮ ТОЛЬКО ВЕТРУ\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с. </li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	    и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">ОТКРОЙТЕ ТАЙНУ, ИЗВЕСТНУЮ ТОЛЬКО ВЕТРУ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с.</li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '', 'infiniti-q60-cabrio', 'INFINITI Q60 Cabrio', '', '', '', '2014-08-01 09:09:02', '2014-08-01 13:03:46'),
(4, 4, 'ru', 'INFINITI Q70', '', 'Q70', '<p>\r\n	<span style="background-color: initial;">РОСКОШЕН. СОВЕРШЕНЕН.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л, 3.7 л и V8 5.6 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний и полный приводы</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">РОСКОШЕН. СОВЕРШЕНЕН.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л, 3.7 л и V8 5.6 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний и полный приводы</li>\r\n</ul>', '', 'infiniti-q70', 'INFINITI Q70', '', '', '', '2014-08-01 09:20:12', '2014-08-01 13:04:08'),
(5, 5, 'ru', 'INFINITI QX50', '', 'QX50', '<p>\r\n	   ЭЛЕГАНТНОСТЬ ТОЖЕ СПОРТ\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л и 3.7 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения<br>\r\n	  и cпортивным режимом DS</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">ЭЛЕГАНТНОСТЬ ТОЖЕ СПОРТ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л и 3.7 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения<br>\r\n	и cпортивным режимом DS</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx50', 'INFINITI QX50', '', '', '', '2014-08-01 09:26:55', '2014-08-01 13:04:24'),
(6, 6, 'ru', 'INFINITI QX60', '', 'QX60', '<p>\r\n	   РОСКОШЬ ВО ВСЕХ ИЗМЕРЕНИЯХ\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.5 л, 262 л.с.</li>\r\n	<li>Трансмиссия СVT (Xtronic) с функцией <br>\r\n	  ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">РОСКОШЬ ВО ВСЕХ ИЗМЕРЕНИЯХ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.5 л, 262 л.с.</li>\r\n	<li>Трансмиссия СVT (Xtronic) с функцией <br>\r\n	ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx60', 'INFINITI QX60', '', '', '', '2014-08-01 09:37:33', '2014-08-01 13:04:38'),
(7, 7, 'ru', 'INFINITI QX70', '', 'QX70', '<p>\r\n	 ПРИРОЖДЕННЫЙ ПРОВОКАТОР\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 3.0 л, 3.7 л и V8 5.0 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">ПРИРОЖДЕННЫЙ ПРОВОКАТОР</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 3.0 л, 3.7 л и V8 5.0 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx70', 'INFINITI QX70', '', '', '', '2014-08-01 10:10:34', '2014-08-01 13:04:50'),
(8, 8, 'ru', 'INFINITI QX80', '', 'QX80', '<p>\r\n	   ЕЖЕДНЕВНО. ПЕРВЫМ КЛАССОМ.\r\n</p>\r\n<ul>\r\n	<li>Двигатель V8 5.6 л, 405 л.с.</li>\r\n	<li>7-ст АКП с функцией <br>\r\n	 ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', '<p>\r\n	<span style="background-color: initial;">ЕЖЕДНЕВНО. ПЕРВЫМ КЛАССОМ.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V8 5.6 л, 405 л.с.</li>\r\n	<li>7-ст АКП с функцией <br>\r\n	ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx80', 'INFINITI QX80', '', '', '', '2014-08-01 10:17:05', '2014-08-01 13:05:00');

-- --------------------------------------------------------

--
-- Структура таблицы `products_video`
--

DROP TABLE IF EXISTS `products_video`;
CREATE TABLE IF NOT EXISTS `products_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci,
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `related_production`
--

DROP TABLE IF EXISTS `related_production`;
CREATE TABLE IF NOT EXISTS `related_production` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT '0',
  `related_product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `related_production`
--

INSERT INTO `related_production` (`id`, `product_id`, `related_product_id`, `created_at`, `updated_at`) VALUES
(1, 2, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `rel_mod_gallery`
--

INSERT INTO `rel_mod_gallery` (`id`, `module`, `unit_id`, `gallery_id`) VALUES
(1, 'products', 1, 1),
(2, 'products', 1, 2),
(3, 'products', 1, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('1c38996d68c019ef48782db94eb843f5c50656cd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidk9DRHp3Zk9qZzhOZ2pvWm9XRndWUXRremJqbThQNVUzVzhRNlJkbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDU2MTY7czoxOiJjIjtpOjE0MDcxNDU2MTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407145619),
('283a1f422c54c65b03e6a0bb82cd1badc5d1b970', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiekRYR0FlOFc1NHloZHpSNlE1SmVFZHpqY25lbGZDV3FvZnBqU29DQSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDY5NTk7czoxOiJjIjtpOjE0MDcxNDY5NTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407146962),
('3d761b101f183caa5ef4e26e80e307c95dd03221', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZkhxaHBzbHNBNnY1WmJsVkZyTmVQaDNFRXU2ajcwb2JmNTlUaDZZaSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNzE0NjMxNDtzOjE6ImMiO2k6MTQwNzE0MDc5MjtzOjE6ImwiO3M6MToiMCI7fX0=', 1407146314),
('4ace73896ce231250e93fbf3d9e7efa3820e2b47', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmJmRU05VTNGTjNZSHFEVGx4RU45dHozMllvaG41WGpFQW5RYTR4aCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDU2MzA7czoxOiJjIjtpOjE0MDcxNDU2MzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407145633),
('61e51b5b6381feb08e6a36c982fdec039568b463', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXhacjVOVUUwUUUxZ2hiUTBGOUZTTlFTU2Jwd0NKbHY5Nkw2anRacCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNTAzMjY7czoxOiJjIjtpOjE0MDcxNTAzMjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407150329),
('7a83e42ede4947189bbac98e744401aff810c56a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGIwWllIWVJsU1FkcTd0QlRuWVpBN2NPMDhCcW9HbmhWa1hLMGhzSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNTIxNTU7czoxOiJjIjtpOjE0MDcxNTIxNTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407152157),
('7a9323d5b50e183181529eb56f144ff9cb60e7c9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3MyazJ3TDBzbE5mU3QxQlNOREIyWHNIQ0RWMG9ITDFhTHMycVBPRiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDkxMDg7czoxOiJjIjtpOjE0MDcxNDkxMDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407149111),
('a71a994c2045db4733ad17e96e7a13ea359ae4c1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFNMaHFKTjQxQXptd0lHMm1GN3p4aG9scXBOWmF3MXJMbTdJQlJWayI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNzE1Mzg2OTtzOjE6ImMiO2k6MTQwNzE1MDUzMjtzOjE6ImwiO3M6MToiMCI7fX0=', 1407153869),
('a9db242842466e37022b582d23a4df01da2ce159', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUxWWlBQcHR1ckphSk01dWJoSUNwWkhQNmc0aFBOTTBxU2ltb2ZWMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNTEwODQ7czoxOiJjIjtpOjE0MDcxNTEwODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407151087),
('aaa0bde0d061581d59e3f70cc5d67edf5e7e4fc1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMzFUTkJVUHhGOHJUT2RQZUNBbmtzc2h5VDk1bVlxMTlqaWF6ZHNyZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDg0ODU7czoxOiJjIjtpOjE0MDcxNDg0ODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407148488),
('aee5ee56b780d87c9d09a5c06f813d20d9fc4300', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid1JKZlZJak5FY1d3SW9LandzZGRLeXFncjBpdWFLWlpVdzNkTWh4YSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNzE1MzE1NjtzOjE6ImMiO2k6MTQwNzEzMzAwMDtzOjE6ImwiO3M6MToiMCI7fX0=', 1407153156),
('b9daa9f6191c6707bd5886610ae81c3604d7c7db', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUNqVjcxY0ZVdUtZMEdra0RiNFRmMHpCUmhPYTJEQ3Bjb29zVDM2ayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDkwMjY7czoxOiJjIjtpOjE0MDcxNDkwMjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407149030),
('d45c8daeee108d70a867cbb3bf16a247313e40eb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTBQZk9XbW5ORW1wY080cm0zT05CcG8wMDdjM3c4QnZSZzJUYzlNRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDgwNTU7czoxOiJjIjtpOjE0MDcxNDgwNTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407148058),
('d63a8dd128c1e6cc02e1257c96557a67d4e7f745', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieXFUVkVXbmxDdGJCSUcyeU9UMDZ6djZjR3loUzZSSm92RFJDRXh3SCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNzE0NjM1NztzOjE6ImMiO2k6MTQwNzE0MjYzMTtzOjE6ImwiO3M6MToiMCI7fX0=', 1407146357),
('ec4766ca1d6c5c6aafd9b07def4a0d2508eac4a3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieTljQTVhMkZMdzRBelRiclRsTUZ2dTd3TTJ1VUF1RzVyam9mTW10TSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDcxNDcxOTE7czoxOiJjIjtpOjE0MDcxNDcxOTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1407147194);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `tag` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_module_unit_id_tag_unique` (`module`,`unit_id`,`tag`),
  KEY `tags_module_index` (`module`),
  KEY `tags_module_unit_id_index` (`module`,`unit_id`),
  KEY `tags_tag_index` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@infiniti-gedon.ru', 1, '$2y$10$TgZ.n2ih/yOxxMKgiEl.Uu7zWsCBM6wF/ILTnKwFcT8hSodPoonYG', '', '', '', 0, 'Q38vPtDXED0urRxZlmHmOvTh7qmvRL0mRLcwLGQazTjjK6XXmhTd1jqkeR8H', '2014-07-31 11:11:00', '2014-07-31 11:11:33'),
(2, 2, 'Пользователь', '', 'user@infiniti-gedon.ru', 1, '$2y$10$C/4m6SMOWkjVlrN63CBmRuUkW7PmAd.HkB9dtWV4Ky7uhrlqIsE7i', '', '', '', 0, NULL, '2014-07-31 11:11:00', '2014-07-31 11:11:00'),
(3, 3, 'Модератор', '', 'moder@infiniti-gedon.ru', 1, '$2y$10$H6tRPiRo7pOQfmfVTl1Fs..TualCzyl9zihCaj5XpIP/Qtb60E4m6', '', '', '', 0, NULL, '2014-07-31 11:11:01', '2014-07-31 11:11:01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
