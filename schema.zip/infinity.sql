-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 18 2014 г., 12:28
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `infinity`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `channels`
--

DROP TABLE IF EXISTS `channels`;
CREATE TABLE IF NOT EXISTS `channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8_unicode_ci,
  `desc` text COLLATE utf8_unicode_ci,
  `file` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `channels`
--

INSERT INTO `channels` (`id`, `category_id`, `product_id`, `template`, `title`, `price`, `year`, `link`, `short`, `desc`, `file`, `image_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, 1, 0, '2', 'НОВЫЙ INFINITI Q50', '', '', '0', '<p>\r\n	              ЗАВОДИТ НА УРОВНЕ ИНСТИНКТОВ\r\n</p>\r\n<ul>\r\n	<li>Двигатель 2.0 л R-4, 16V С Турбонаддувом</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний привод</li>\r\n</ul>', '', NULL, 39, 0, '2014-07-31 14:18:33', '2014-08-05 13:48:01'),
(2, 1, 0, '1', 'INFINITI QX70. ПЕРЕРОЖДЕНИЕ', '', '', '0', '<ul>\r\n	<li>Двигатели V6 3.0 л, 3.7 л и V8 5.0 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', NULL, 34, 0, '2014-08-01 07:37:50', '2014-08-07 12:02:18'),
(4, 1, 0, '2', 'Новый INFINITI Q70', '', '', '0', '<p>\r\n	 <span style="background-color: initial;">РОСКОШЕН. СОВЕРШЕНЕН.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л, 3.7 л и V8 5.6 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний и полный приводы</li>\r\n</ul>', '', NULL, 103, 0, '2014-08-01 07:41:59', '2014-08-07 11:55:27'),
(6, 2, 0, '2', 'Infiniti QX80 в июле по эксклюзивной цене', '', '', 'infiniti-qx80-v-iyule-po-ksklyuzivnoiy-cene', '<p>\r\n	<span style="background-color: initial;">Стоимость на Infiniti QX80 в июле достигает рекордной отметки — от 3 305 000 руб.</span>\r\n</p>', '<p>\r\n	 <span style="background-color: initial;">Данный автомобиль обладает просторным 8-местным салоном премиального уровня, динамикой <br>\r\n	 </span><span style="line-height: 1.5em; background-color: initial;">и комфортом полноценного внедорожника и мощным 405-сильным мотором. А опциональное<br>\r\n	 </span><span style="line-height: 1.5em; background-color: initial;">разнообразие удивит даже самого искушенного владельца. </span><span style="line-height: 1.5em; background-color: initial;">В нашем дилерском центре по-прежнему<br>\r\n	 действует кредитная программа INFINITI FINANCE со </span><span style="line-height: 1.5em; background-color: initial;">ставкой 5,75%.</span>\r\n</p>\r\n<p>\r\n	<br>\r\n	Мы ждем Вас в любое удобное для Вас время. Получить более подробную информацию, а так же<br>\r\n	 <span style="background-color: initial;">записаться на тест-драйв Вы можете у менеджеров отдела продаж по тел. (863) 305-05-00 <br>\r\n	 и при </span><span style="background-color: initial;">личной встрече.</span>\r\n</p>', NULL, 56, 0, '2014-08-01 08:03:22', '2014-08-05 06:12:43'),
(7, 2, 0, '2', 'Встречайте: абсолютно новый INFINITI Q50', '', '', 'vstrechaiyte-absolyutno-novaya-model-infiniti-q50-v-rostove', '<p>\r\n	 <span style="background-color: initial;">2 августа с 11:00 до 17:00 мы приглашаем всех тест-драйв.</span>\r\n</p>', '<p>\r\n	 <span style="background-color: initial;">2 августа с 11:00 до 17:00 мы приглашаем всех в салон официального дилера INFINITI на тест-драйв<br>\r\n	абсолютно новой модели INFINITI Q50. </span><span style="background-color: initial;">Вы сможете увидеть настоящий болид RB9, автомобили в<br>\r\n	эксклюзивном обвесе от LARTE DESIGN и легендарный FX VETTEL.</span>\r\n</p>', NULL, 57, 0, '2014-08-01 08:10:54', '2014-08-05 06:13:20'),
(8, 2, 0, '2', 'Летнее предложение на сервис', '', '', 'letnee-predlojenie-na-servis', '<p>\r\n	 <span style="background-color: initial;">Летняя диагностика с экономией до 50%</span>\r\n</p>', '<p>\r\n	<span style="background-color: initial;">Лето—время свежих впечатлений и неиспытанных эмоций. Вам остается только выбрать <br>\r\n	маршрут для Вашего путешествия, а мы с удовольствием подготовим Ваш автомобиль <br>\r\n	к яркому сезону. Ждём Вас в нашем сервисном центре INFINITI «Гедон Авто-Премиум» <br>\r\n	на прохождение летней диагностики </span><span style="background-color: initial;">с экономией до 50%. (863) 305-05-00.</span>\r\n</p>', NULL, 58, 0, '2014-08-01 08:15:06', '2014-08-05 06:10:13'),
(9, 4, 5, '6', 'INFINITI EX37', '1 100 000 руб.', '2008', 'infinityex37', '<dl class="chars-list">\r\n	<dt>Год:</dt>\r\n	<dd>2008</dd>\r\n	<dt>Пробег:</dt>\r\n	<dd>68 172 км</dd>\r\n	<dt>Цвет:</dt>\r\n	<dd>коричневый металлик</dd>\r\n	<dt>КПП:</dt>\r\n	<dd>автомат</dd>\r\n	<dt>Цена:</dt>\r\n	<dd>1 100 000 р</dd>\r\n</dl>', '<p>\r\n	      Усилитель руля (гидравлический), Управление климатом (двузонный климат контроль), Парктроники (задний парктроник), Регулировка руля (по высоте, по углу наклона), Электроприводы (передних стекол, задних стекол, зеркал, сидений), Обивка салона (кожа), Подушки безопасности, Регулировка сиденья водителя, Регулировка сиденья пассажира, Обогрев сидений, акет для мобильного телефона, Регулировка сиденья водителя электропривод с памятью, Система кондиционирования воздуха климат (2 зоны), Центральный замок, Электропривод регулировки зеркал.\r\n</p>', NULL, 92, 35, '2014-08-05 11:17:00', '2014-08-07 09:59:26'),
(11, 3, 1, '5', 'Infiniti Q50', '1 450 000 руб.', '2014', 'infiniti-q50-black', '<div>\r\n	2,0-литровый бензиновый двигатель с турбонаддувом мощностью 211л.с.\r\n</div>\r\n<div>\r\n	<span style="background-color: initial;">7-ступенчатая автоматическая коробка передач с режимом ручного переключения</span>\r\n</div>\r\n<div>\r\n	17" легкосплавные колесные диски, летние шины размерности 225/55R17\r\n</div>', '<p>\r\n	  22222222222222222222222222222222222222222222\r\n</p>', NULL, 106, 0, '2014-08-05 13:17:04', '2014-08-05 19:25:37');

-- --------------------------------------------------------

--
-- Структура таблицы `channel_category`
--

DROP TABLE IF EXISTS `channel_category`;
CREATE TABLE IF NOT EXISTS `channel_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `channel_category`
--

INSERT INTO `channel_category` (`id`, `title`, `slug`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Сладер продукции на главной странице', 'main-page-slider', NULL, '2014-07-31 11:12:18', '2014-07-31 11:12:18'),
(2, 'Спецпредложения', 'offer', NULL, '2014-07-31 11:44:26', '2014-07-31 11:44:26'),
(3, 'Автомобили в наличии', 'сars-in-stock', NULL, '2014-08-04 07:50:08', '2014-08-04 07:50:08'),
(4, 'Автомобили с пробегом', 'car-for-sale', NULL, '2014-08-04 07:50:31', '2014-08-04 07:50:31');

-- --------------------------------------------------------

--
-- Структура таблицы `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `published_at` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `events_publication_index` (`publication`),
  KEY `events_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `events_meta`
--

DROP TABLE IF EXISTS `events_meta`;
CREATE TABLE IF NOT EXISTS `events_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` mediumtext COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `events_meta_event_id_index` (`event_id`),
  KEY `events_meta_language_index` (`language`),
  KEY `events_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=51 ;

--
-- Дамп данных таблицы `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `settings`, `created_at`, `updated_at`) VALUES
(1, 'products - 1', '', '2014-07-31 12:10:06', '2014-07-31 12:10:06'),
(2, 'products - 1', '', '2014-07-31 14:14:16', '2014-07-31 14:14:16'),
(3, 'products - 1', '', '2014-07-31 14:14:16', '2014-07-31 14:14:16'),
(4, 'products - 1', '', '2014-08-05 10:23:07', '2014-08-05 10:23:08'),
(5, 'products - 9', '', '2014-08-05 11:17:00', '2014-08-05 11:17:00'),
(7, 'products - 10', '', '2014-08-05 12:42:21', '2014-08-05 12:42:21'),
(8, 'products - 9', '', '2014-08-05 12:43:35', '2014-08-05 12:43:35'),
(9, 'products - 9', '', '2014-08-05 12:52:51', '2014-08-05 12:52:51'),
(10, 'products - 10', '', '2014-08-05 13:09:44', '2014-08-05 13:09:44'),
(11, 'products - 11', '', '2014-08-05 13:17:04', '2014-08-05 13:17:04'),
(12, 'products - 1', '', '2014-08-05 20:16:35', '2014-08-05 20:16:35'),
(13, 'products - 1', '', '2014-08-05 20:16:35', '2014-08-05 20:16:35'),
(14, 'products - 1', '', '2014-08-06 08:20:29', '2014-08-06 08:20:29'),
(15, 'products - 1', '', '2014-08-06 12:26:19', '2014-08-06 12:26:19'),
(16, 'products - 1', '', '2014-08-06 12:42:30', '2014-08-06 12:42:30'),
(17, 'products - 8', '', '2014-08-06 13:28:44', '2014-08-06 13:28:44'),
(18, 'products - 7', '', '2014-08-06 13:30:29', '2014-08-06 13:30:29'),
(19, 'products - 6', '', '2014-08-06 13:31:43', '2014-08-06 13:31:43'),
(20, 'products - 5', '', '2014-08-06 13:33:42', '2014-08-06 13:33:42'),
(21, 'products - 4', '', '2014-08-06 13:37:42', '2014-08-06 13:37:42'),
(22, 'products - 3', '', '2014-08-06 13:38:08', '2014-08-06 13:38:08'),
(23, 'products - 2', '', '2014-08-06 13:38:36', '2014-08-06 13:38:36'),
(24, 'products - 4', '', '2014-08-06 13:43:59', '2014-08-06 13:43:59'),
(25, 'products - 3', '', '2014-08-06 14:00:50', '2014-08-06 14:00:50'),
(26, 'products - 4', '', '2014-08-06 14:19:51', '2014-08-06 14:19:51'),
(27, 'products - 1', '', '2014-08-06 15:20:39', '2014-08-06 15:20:39'),
(28, 'products - 1', '', '2014-08-06 15:40:38', '2014-08-06 15:40:39'),
(29, 'products - 1', '', '2014-08-06 15:42:04', '2014-08-06 15:42:04'),
(30, 'products - 1', '', '2014-08-06 15:55:12', '2014-08-06 15:55:12'),
(31, 'products - 1', '', '2014-08-06 15:56:01', '2014-08-06 15:56:01'),
(32, 'products - 1', '', '2014-08-06 15:57:05', '2014-08-06 15:57:05'),
(33, 'products - 6', '', '2014-08-07 05:54:33', '2014-08-07 05:54:33'),
(34, 'products - 6', '', '2014-08-07 05:59:24', '2014-08-07 05:59:24'),
(35, 'products - 9', '', '2014-08-07 09:27:42', '2014-08-07 09:27:42'),
(36, 'products - 5', '', '2014-08-07 12:24:16', '2014-08-07 12:24:16'),
(37, 'products - 4', '', '2014-08-07 13:42:52', '2014-08-07 13:42:52'),
(38, 'products - 4', '', '2014-08-07 13:42:52', '2014-08-07 13:42:52'),
(39, 'products - 2', '', '2014-08-07 13:47:33', '2014-08-07 13:47:33'),
(40, 'products - 2', '', '2014-08-07 13:47:33', '2014-08-07 13:47:33'),
(41, 'products - 3', '', '2014-08-07 13:51:33', '2014-08-07 13:51:33'),
(42, 'products - 3', '', '2014-08-07 13:51:33', '2014-08-07 13:51:33'),
(43, 'products - 5', '', '2014-08-07 13:57:41', '2014-08-07 13:57:41'),
(44, 'products - 5', '', '2014-08-07 13:57:41', '2014-08-07 13:57:41'),
(45, 'products - 6', '', '2014-08-07 14:04:26', '2014-08-07 14:04:26'),
(46, 'products - 6', '', '2014-08-07 14:04:26', '2014-08-07 14:04:26'),
(47, 'products - 7', '', '2014-08-07 14:12:35', '2014-08-07 14:12:35'),
(48, 'products - 7', '', '2014-08-07 14:12:35', '2014-08-07 14:12:35'),
(49, 'products - 8', '', '2014-08-07 14:18:58', '2014-08-07 14:18:58'),
(50, 'products - 8', '', '2014-08-07 14:18:58', '2014-08-07 14:18:58');

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'user', 'Пользователи', '', '', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(3, 'moderator', 'Модераторы', 'admin', '', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news`
--

DROP TABLE IF EXISTS `i18n_news`;
CREATE TABLE IF NOT EXISTS `i18n_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `i18n_news_publication_index` (`publication`),
  KEY `i18n_news_published_at_index` (`published_at`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `i18n_news`
--

INSERT INTO `i18n_news` (`id`, `template`, `slug`, `publication`, `image_id`, `gallery_id`, `created_at`, `updated_at`, `published_at`) VALUES
(1, 'default', '1', 1, 0, 0, '2014-08-01 08:27:26', '2014-08-01 08:27:46', '2014-07-22'),
(2, 'default', '2', 1, 0, 0, '2014-08-01 08:28:39', '2014-08-01 08:28:39', '2014-07-05'),
(3, 'default', '3', 1, 0, 0, '2014-08-01 08:31:06', '2014-08-01 08:31:06', '2014-07-04'),
(4, 'default', '4', 1, 0, 0, '2014-08-01 08:33:42', '2014-08-01 08:33:42', '2014-07-02'),
(5, 'default', '5', 1, 0, 0, '2014-08-01 08:34:35', '2014-08-01 08:34:35', '2014-07-01');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news_meta`
--

DROP TABLE IF EXISTS `i18n_news_meta`;
CREATE TABLE IF NOT EXISTS `i18n_news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_news_meta_news_id_index` (`news_id`),
  KEY `i18n_news_meta_language_index` (`language`),
  KEY `i18n_news_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `i18n_news_meta`
--

INSERT INTO `i18n_news_meta` (`id`, `news_id`, `language`, `title`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Встречайте: абсолютно новая модель INFINITI Q50 в Ростове!', '<p>\n	 <span style="background-color: initial;">2 августа с 11:00 до 17:00 мы приглашаем всех в салон официального дилера INFINITI на тест-драйв абсолютно новой модели INFINITI Q50. </span><span style="background-color: initial;">Вы сможете увидеть настоящий болид RB9, автомобили в эксклюзивном обвесе от LARTE DESIGN и легендарный FX VETTEL.</span>\n</p>', '', 'vstrechaiyte-absolyutno-novaya-model-infiniti-q50-v-rostove', 'Встречайте: абсолютно новая модель INFINITI Q50 в Ростове!', '', '', '', '2014-08-01 08:27:26', '2014-08-01 08:27:46'),
(2, 2, 'ru', 'Летнее предложение на сервис', '<p>\n	<span style="background-color: initial;">Лето—время свежих впечатлений и неиспытанных эмоций.  Вам остается только выбрать маршрут для Вашего путешествия, а мы с удовольствием подготовим Ваш автомобиль к яркому сезону. Ждём Вас в нашем сервисном центре Infiniti «Гедон Авто-Премиум» на прохождение летней диагностики с экономией до 50%.</span>\n</p>', '', 'letnee-predlojenie-na-servis', 'Летнее предложение на сервис', '', '', '', '2014-08-01 08:28:39', '2014-08-01 08:28:39'),
(3, 3, 'ru', 'Специальное предложение для первых владельцев Infiniti Q50', '<p>\n	<span style="background-color: initial;">Оформите предзаказ на покупку Infiniti Q50 бензиновой версии  и получите комплект зимних шин от Pirelli. </span><span style="background-color: initial;">Infiniti Q50 — одна из новейших и самых ярких моделей, входящих в класс среднеразмерных седанов премиум-класса. С качествами, обращенными к уму и сердцу водителя, Infiniti Q50 сочетает в себе черты элегантных концепт-каров бренда и гостеприимный интерьер, отличающийся использованием самых современных технологий и традиционно высокого качества исполнения. </span>\n</p>', '', 'specialnoe-predlojenie-dlya-pervyh-vladelcev-infiniti-q50', 'Специальное предложение для первых владельцев Infiniti Q50', '', '', '', '2014-08-01 08:31:06', '2014-08-01 08:31:06'),
(4, 4, 'ru', 'Эксклюзивное предложение на 5 автомобилей', '<p>\n	 <span style="background-color: initial;">Вы не привыкли себя ограничивать? Мы Вас тоже. В салоне официального дилера действует специальное предложение на 5 автомобилей. Спешите! Условия действуют исключительно до 31.07.14 г.</span>\n</p>', '', 'eksklyuzivnoe-predlojenie-na-5-avtomobileiy', 'Эксклюзивное предложение на 5 автомобилей', '', '', '', '2014-08-01 08:33:42', '2014-08-01 08:33:42'),
(5, 5, 'ru', '20 автомобилей по себестоимости!', '<p>\n	<span style="background-color: initial;">Внимание! Действует беспрецедентная акция - 20 автомобилей по себестоимости. Подробности — при встрече. </span><span style="background-color: initial;">Предложение действует на автомобили в наличии до 30.07.14</span>\n</p>', '', '20-avtomobileiy-po-sebestoimosti', '20 автомобилей по себестоимости!', '', '', '', '2014-08-01 08:34:35', '2014-08-01 08:34:35');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages`
--

DROP TABLE IF EXISTS `i18n_pages`;
CREATE TABLE IF NOT EXISTS `i18n_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `i18n_pages`
--

INSERT INTO `i18n_pages` (`id`, `slug`, `template`, `publication`, `start_page`, `in_menu`, `sort_menu`, `created_at`, `updated_at`) VALUES
(1, '', 'index', 1, 1, 0, 1, '2014-07-31 11:13:05', '2014-07-31 11:13:05'),
(2, 'offers', 'offers', 1, 0, 0, 2, '2014-07-31 11:13:39', '2014-07-31 11:13:39'),
(3, 'news', 'default', 1, 0, 0, 4, '2014-07-31 13:52:55', '2014-07-31 13:53:18'),
(4, 'history', 'default', 1, 0, 0, 5, '2014-08-01 08:35:04', '2014-08-01 08:35:04'),
(5, 'about', 'default', 1, 0, 0, 156, '2014-08-01 08:50:02', '2014-08-12 12:35:05'),
(7, 'reserve-parts', 'default', 1, 0, 0, 183, '2014-08-01 08:50:44', '2014-08-12 13:48:43'),
(8, 'services', 'default', 1, 0, 0, 172, '2014-08-01 08:51:06', '2014-08-12 13:41:50'),
(12, 'contacts', 'contacts', 1, 0, 0, 16, '2014-08-01 08:55:41', '2014-08-01 10:45:35'),
(13, 'reserve-parts-accessories', 'reserve-parts-accessories', 1, 0, 0, 45, '2014-08-01 14:28:24', '2014-08-01 14:28:24'),
(14, 'cars-for-sale', 'used-cars', 1, 0, 0, 83, '2014-08-04 11:46:18', '2014-08-05 12:55:48'),
(15, 'cars-in-stock', 'stock-cars', 1, 0, 0, 95, '2014-08-05 15:11:30', '2014-08-05 15:11:30');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages_meta`
--

DROP TABLE IF EXISTS `i18n_pages_meta`;
CREATE TABLE IF NOT EXISTS `i18n_pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_meta_page_id_index` (`page_id`),
  KEY `i18n_pages_meta_language_index` (`language`),
  KEY `i18n_pages_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `i18n_pages_meta`
--

INSERT INTO `i18n_pages_meta` (`id`, `page_id`, `language`, `name`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Главная страница', '', 'glavnaya-stranica', 'Главная страница', '', '', '', '2014-07-31 11:13:05', '2014-07-31 11:13:05'),
(2, 2, 'ru', 'Спецпредложения', '', 'specpredlojeniya', 'Спецпредложения', '', '', '', '2014-07-31 11:13:39', '2014-07-31 11:13:39'),
(3, 3, 'ru', 'Новости', '<section class="sect-wrapper"><header>\n<h1>Новости</h1>\n</header></section> [news]', 'novosti', 'Новости', '', '', '', '2014-07-31 13:52:55', '2014-07-31 13:53:18'),
(4, 4, 'ru', 'История', '<section class="sect-wrapper information history">\n<h1>История Infiniti</h1>\n<div class="history-banner">\n	<img class="history-banner" src="/theme/img/history-banner.jpg">\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="medium-desc">\n			                             Целью создания бренда Infiniti с самого начала являлось предложение новой концепции автомобильной роскоши, в которой на первое место выходит удовольствие от вождения и неповторимая индивидуальность.\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="big-desc">\n			                             Автомобильная роскошь\n		</div>\n	</div>\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="history-date">\n			                                 1989\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="desc">\n			                                                              С первых дней своего существования Infiniti отличался инновационным дизайном, техническим совершенством, широким использованием современных технологий и новейших технических решений, а также заботой о каждом клиенте в течение всего срока эксплуатации автомобиля.                             <br>\n			                                                              Официально продажи Infiniti стартовали в США 8 ноября 1989 года. Однако проект создания Infiniti уходит корнями в 1985 год, когда с целью разработки нового бренда высококачественных престижных автомобилей в компании Nissan была образована сверхсекретная группа Horizon Task Force.                             <br>\n			                                                              Группа Horizon Task Force отобрала и тщательно изучила несколько компаний, предоставляющих сервисные услуги, но не относящихся к автомобильному бизнесу, в том числе курьерскую службу Federal Express, гостиничную сеть Four Seasons и торговую сеть Nordstrom. Впоследствии выводы, сделанные группой Horizon Task Force, оказали непосредственное влияние на все аспекты проекта, начиная от дизайнерского решения первых салонов, больше похожих на роскошный отель, нежели на дилерский центр, и заканчивая корпоративной символикой бренда — от оформления визитных карточек до упаковки запчастей и аксессуаров.                             <br>\n		</div>\n	</div>\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="medium-desc">\n			                                                              Была разработана новая концепция – программа привилегированного обслуживания покупателей Infiniti. Она затрагивала не только покупку, но и последующий процесс обслуживания автомобиля, вплоть до бесплатного предоставления подменного автомобиля — практика, которая в то время никем не использовалась.                             <br>\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="big-desc">\n			                             Infiniti Total Ownership Experience\n		</div>\n	</div>\n</div>\n<div class="margin-bottom-100 clearfix">\n	<div class="column column-40">\n		<div class="history-date">\n			                             1987\n		</div>\n	</div>\n	<div class="column column-60">\n		<div class="desc">\n			                                                              Название, выбранное для нового престижного бренда в июле 1987 года, символизирует непрерывное движение вперед, к новым горизонтам. Так родилось название с измененным написанием имени бренда с четырьмя буквами «i» в слове «бесконечность» (Infiniti вместо Infinity) — и эмблема, с двумя линиями, стремящимися к бесконечно удаленной точке горизонта.                             <br>\n			                                                              Так Infiniti раскрыла автомобильному миру свою философию, основанную на оригинальности автомобилей, их техническом совершенстве, высоком качестве и эмоциональности вождения.                             <br>\n		</div>\n	</div>\n</div>\n</section>', 'istoriya', 'История', '', '', '', '2014-08-01 08:35:04', '2014-08-01 08:35:04'),
(5, 5, 'ru', 'О компании', '<main><section class="information">\n<h1>О компании</h1>\n<div class="clearfix margin-bottom-60">\n	<div class="column column-60">\n		<img src="/uploads/e16CJxZUb0wnqRuW.jpg">\n	</div>\n	<div class="column column-40">\n		          Компания «Гедон Авто-Премиум» является первым официальным дилером марки INFINITI в Южном Федеральном округе с 2008 года. Автоцентр входит в состав крупнейшего автохолдинга в регионе — Группу компаний «Гедон», владеющей 13 автоцентрами в Ростове-на-Дону, Таганроге, Краснодаре и Ставрополе. <br>\n		 <br>\n		                      К 20-летнему юбилею компании, в 2010 году построен новый постоянный автоцентр INFINITI, полностью соответсующий стандартам IREDI. Уникальный дизайн в стиле NEW WAVE подразумевает использование стекла как одного из основных строительных элементов. <br>\n		 <br>\n		         В отделке интерьеров использованы только натуральные материалы, включая мраморовидный известняк, деревья редких пород, различные сорта итальянской керамики. Принцип ориентации на современную роскошь, комфорт и функциональность заложен в дизайне каждого помещения салона. <br>\n		<br>\n		    Добро пожаловать в особый мир INFINITI, который дарит незабываемые эмоции и ощущения. С самого первого контакта мы хотим, чтобы Вы чувствовали к себе особое отношение, погружаясь в атмосферу современной роскоши и уникальных дизайнерских решений.\n	</div>\n</div>\n<div class="clearfix margin-bottom-60">\n	<div class="column column-60">\n		               Мы прилагаем все усилия, чтобы Вы остались абсолютно довольны качеством обслуживания, начиная от приобретения автомобилем до его обслуживания. На весь модельный ряд распространяется программа кредитования INFINITI FINANCE, позволяющая купить автомобиль на специальных условиях. Центр технического обслуживания оснащен современным диагностическим, подъемным и ремонтным оборудованием. Наши специалисты проходят регулярное обучение. Мы предлагаем владельцам автомобилей INFINITI полный спектр услуг в области сервисного обслуживания на высочайшем уровне.\n	</div>\n</div>\n<div class="clearfix margin-bottom-60">\n	<div class="awwards">\n		<div class="desc">\n			                    В 2010 и 2011 годах компания «Гедон Авто-Премиум была отмечена званием «Лучший региональный дилер в России».\n		</div>\n		<div class="desc">\n			                    В 2012 году — «Лучший дилер в области кредитования и страхования».\n		</div>\n		<div class="desc">\n			                    В 2013 году — «Лучший сервис».\n		</div>\n	</div>\n</div>\n</section> </main>', 'o-kompanii', 'О компании', '', '', '', '2014-08-01 08:50:02', '2014-08-12 12:35:05'),
(7, 7, 'ru', 'Сервис и запчасти', '<main><section class="information">\n<ul id="tabs" class="tabs">\n	<li data-tab="service" class="active">Сервис</li>\n	<li data-tab="spares">Запчасти</li>\n	<li data-tab="guarantee">Гарантия</li>\n	<li data-tab="vip">VIP обслуживание</li>\n</ul>\n<ul id="tabContent" class="tabs-content">\n	<li class="tab-li active" data-tab="service">\n	<h2>Техническое обслуживание</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                                Официальный сервисный центр INFINITI <nobr>«Гедон Авто-Премиум</nobr>» предлагает исключительно индивидуальный сервис. Современное оборудование, опыт и профессионализм сотрудников, оперативность в планировании и проведении работ, поэтапный контроль качества в сочетании с новейшими комплектующими и расходными материалами — вот то, что определяет высокую степень доверия к нам сегодня. <br>\n			 <br>\n			 Также мы можем предоставить Вам историю ремонта вашего автомобиля, что значительно повысит его стоимость при продаже.  При обслуживании мы используем только  оригинальные запасные части, что гарантирует и соответствие Вашего автомобиля всем техническим нормам безопасности, а так же экономичную и надежную его эксплуатацию.  Напоминаем, что только обслуживание у официального дилера позволит быть уверенным в качестве выполняемых работ и позволит Вам надежно и экономично использовать Ваш автомобиль.\n		</div>\n		<div class="column column-40">\n			 Вы можете записаться на сервис, воспользовавшись формой <br>\n			 online-записи или по телефону +7 (863) 305-05-00.<br><br>\n			<div class="information-btns">\n				<a href="#" class="js-pop-show us-btn" data-popup="call"><i class="fa fa-phone"></i>Заказать звонок</a> <a href="#" class="js-pop-show us-btn" data-popup="recover"><i class="fa fa-wrench"></i>Записаться на сервис</a>\n			</div>\n		</div>\n	</div>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                                                    С нами Вы может быть абсолютно уверенны в:\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">надёжности вашего автомобиля;</span></li>\n				<li class="typical-li">  Вашей личной безопасности и безопасности Ваших близких при эксплуатации вашего автомобиля;</li>\n				<li class="typical-li"><span style="background-color: initial;">своевременном выявлении и оперативном устранении любых неисправностей;</span> </li>\n				<li class="typical-li">оптимально выгодных предложениях на техническое обслуживание — мы дорожим нашей репутацией и рекомендуем только действительно необходимые к проведению работы; </li>\n				<li class="typical-li">продлении срока эксплуатации автомобиля.</li>\n			</ul>\n		</div>\n	</div>\n<!--\n	<div class="information clearfix margin-bottom-60" style="padding-left: 0px;">\n		<div class="information-btns">\n			<a href="#" class="js-pop-show us-btn" data-popup="call"><i class="fa fa-phone"></i>Заказать звонок</a> <a href="#" class="js-pop-show us-btn" data-popup="recover"><i class="fa fa-wrench"></i>Записаться на сервис</a>\n		</div>\n	</div> -->\n	<h3>ПРОГРАММА «ВМЕСТЕ НАВСЕГДА»</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-40">\n			                                              Если Ваш автомобиль старше 3-х лет, предлагаем воспользоваться программой поддержки автомобилей с истекшим гарантийным сроком «Вместе навсегда». Вы всегда можете воспользоваться особыми преимуществами качественного сервиса на максимально выгодных условиях:\n		</div>\n		<div class="column column-60">\n			<ul class="typical-ul">\n				<li>  10% на услуги СТО и запчасти - на а/м INFINITI c пробегом более 100 000 км</li>\n				<li><span style="background-color: initial;">15% на услуги СТО и запчасти – INFINITI старше 3-х лет</span></li>\n				<li><span style="background-color: initial;">20% на услуги СТО и запчасти - INFINITI старше 5-х лет</span></li>\n			</ul>\n		</div>\n	</div>\n	 </li>\n	<li class="tab-li" data-tab="spares">\n	<h2>Запасные части и аксессуары</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                                     Опытные специалисты автоцентра «Гедон Авто-Премиум» помогут сделать INFINITI уникальным, соответствующим именно Вашему стилю. Оригинальные запасные части и аксессуары INFINITI – отличная возможность придать Вашему автомобилю эксклюзивные черты. Установка дополнительного оборудования позволит подчеркнуть неповторимость и совершенство каждого автомобиля INFINITI, максимум комфорта, надежности и безопасности.\n		</div>\n	</div>\n	<h3>В нашем автоцентре Вы можете приобрести и установить:</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			<ul class="typical-ul">\n				<li><span style="background-color: initial;">Хромированные элементы экстерьера,</span></li>\n				<li>Ксеноновые фары,</li>\n				<li>Спутниковые охранные системы,</li>\n				<li>Механические противоугонные устройства,</li>\n				<li>Защита двигателя и АКПП,</li>\n				<li>Предпусковые обогреватели двигателя и салона,</li>\n				<li>Аудио-видео устройства,</li>\n				<li>Навигационное оборудование,</li>\n				<li>Аэродинамический обвес,</li>\n				<li>Литые, кованные колесные диски,</li>\n				<li>Произвести тонировку или бронировку стекол,</li>\n				<li>Произвести антискольное покрытие кузова.</li>\n			</ul>\n		</div>\n	</div>\n	<div class="information clearfix margin-bottom-60" style="padding-left: 0px;">\n		<div class="information-btns">\n			<a href="#" class="js-pop-show us-btn" data-popup="call"><i class="fa fa-phone"></i>Заказать звонок</a> <a href="#" class="js-pop-show us-btn" data-popup="items"><i class="fa fa-wrench"></i>Заказать запчасти</a>\n		</div>\n	</div>\n	<h2>Оптовая продажа запчастей</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                                                               Компания «Гедон Авто-Премиум» предлагает оптовые продажи оригинальных запчастей для автомобилей INFINITI.  Поставка запчастей осуществляется под заказ со складов компании и с центрального склада производителя в Москве.  Для оптовых покупателей действует гибкая система скидок, размер которой зависит от выбранного ассортимента товара и объема заказа.\n		</div>\n	</div>\n	<h3>Ваши преимущества:</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="desc">\n			<ul class="typical-ul">\n				<li><span style="background-color: initial;">только оригинальные запасные части,</span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">широкий ассортимент в наличии для всего модельного ряда INFINITI, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">гибкая ценовая политика, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">сжатые сроки поставки, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">специальные программы и скидки, </span></li>\n				<li><span style="background-color: initial;"></span><span style="background-color: initial;">квалифицированное техническое сопровождение в течение всего заказа.</span></li>\n			</ul>\n		</div>\n	</div>\n	 </li>\n	<li class="tab-li" data-tab="guarantee">\n	<h2>Гарантия</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                                                         Мы уверены в качестве и надежности автомобилей INFINITI. На новые автомобили INFINITI предоставляется гарантия 3 года или 100 000 км пробега, в зависимости от того, что наступит первым.\n		</div>\n	</div>\n	<h3>Условия гарантии</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">Гарантийные обязательства INFINITI распространяются на каждый новый автомобиль INFINITI, проданный, зарегистрированный и эксплуатируемый на территории Российской Федерации, где имеются официальные дилеры INFINITI.</span></li>\n				<li>  Распространяется на все узлы и агрегаты автомобиля если неисправность вызвана использованием некачественных материалов или нарушением технологии производства.</li>\n				<li><span style="background-color: initial;">Не распространяется на любые запасные части и работы, связанные с проведением обязательного или рекомендуемого технического обслуживания.</span></li>\n				<li><span style="background-color: initial;">В случае неожиданной поломки Вашего автомобиля, когда автомобиль обездвижен или его эксплуатация запрещена правилами дорожного движения, он будет бесплатно транспортирован до ближайшего сервисного центра INFINITI или авторизованного регионального сервисного центра Nissan.</span></li>\n				<li><span style="background-color: initial;">Гарантия против сквозной коррозии – 12 лет.</span></li>\n				<li><span style="background-color: initial;">Гарантия на окраску составляет 3 года независимо от пробега.</span></li>\n				<li><span style="background-color: initial;">Гарантия на запасные части, приобретенные и установленные у официального дилера, — 1 год.</span></li>\n			</ul>\n		</div>\n	</div>\n	</li>\n	<li class="tab-li" data-tab="vip">\n	<h2>Привилегированное обслуживание INFINITI</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			            Наша цель — обеспечить Привилегированное обслуживание гостя INFINITI, начиная с первого посещения дилерского центра и в течение всего срока эксплуатации автомобиля. Мы гарантируем, что Вы испытаете положительные эмоции не только при покупке и находясь за рулем автомобиля INFINITI, но и при его обслуживании.<br>\n			<br>\n			            Привилегированное обслуживание INFINITI — это наши обязательства по предоставлению владельцам Infiniti широкого спектра услуг на высоком уровне.<br>\n			<br>\n			            Привилегированное обслуживание INFINITI — это новый стандарт обслуживания, принципиально иное измерение комфорта и надежности.\n		</div>\n		<div>\n			<strong>    Служба поддержки INFINITI </strong><br>\n			        8-800-200-70-77  <br>\n			    24 часа. В любое время. В любой ситуации.   <br>\n			<br>\n			        Служба клиентской поддержки INFINITI — это единый телефонный номер. Это консультации, ответы на возникшие вопросы, оперативное решение по эвакуации автомобиля и многое другое.\n		</div>\n	</div>\n	<h3>Покупка</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			            В нашем дилерском центре предусмотрено все для комфортного приобретения автомобиля INFINITI. Продавец–консультант станет Вашим личным проводником в мир INFINITI, ответит на все Ваши вопросы, предоставит информацию о программах кредитования и страхования, поможет сделать правильный выбор и оформить покупку.\n		</div>\n	</div>\n	<h3>Предпродажная подготовка</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			         Все автомобили INFINITI в обязательном порядке проходят предпродажную подготовку в дилерском центре INFINITI. Квалифицированные технические специалисты проверяют работу всего оборудования автомобиля, его готовность к эксплуатации. Предпродажная подготовка INFINITI — это гарантия безопасности и безупречная передача нового автомобиля владельцу.\n		</div>\n	</div>\n	<h3>Помощь на дороге</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			 <span style="background-color: initial;">Помощь на дорогах в различных ситуациях, требующих быстрого реагирования и разрешения. Мы рады сообщить, что воспользоваться услугами программы «Помощь на дороге» могут все владельцы автомобилей INFINITI в течение всего срока гарантии на автомобиль. Если Вы прокололи колесо, помощь по устранению неисправности будет предоставлена с максимальной быстротой. Просто позвоните по телефону поддержки INFINITI 8-800-200-70-77. </span>\n		</div>\n	</div>\n	<h3>Эвакуация</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			 <span style="background-color: initial;">В случае неожиданной поломки Вашего автомобиля, когда автомобиль обездвижен или его эксплуатация запрещена правилами дорожного движения, он будет бесплатно транспортирован до ближайшего сервисного центра INFINITI или авторизованного регионального сервисного центра Nissan. Вы можете позвонить в Службу клиентской поддержки INFINITI по номеру 8-800-200-70-77 и воспользоваться услугой эвакуации. </span>\n		</div>\n	</div>\n	<h3>Предоставление подменного автомобиля</h3>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			         Дилер INFINITI предоставит Вам подменный автомобиль на весь срок ремонта, если данный ремонт является гарантийным, и устранить неисправность в день обращения в сервисный центр невозможно. Для Вашего удобства предусмотрена система предварительной записи на ремонт и обслуживание. Дополнительную информацию Вы можете получить у Вашего официального дилера INFINITI.\n		</div>\n	</div>\n	 </li>\n</ul>\n </section></main>', 'servis-i-zapchasti', 'Сервис и запчасти', '', '', '', '2014-08-01 08:50:44', '2014-08-12 13:48:43'),
(8, 8, 'ru', 'Услуги', '<main><section class="information">\n<ul id="tabs" class="tabs">\n	<li data-tab="finance" class="active">Автокредитование</li>\n	<li data-tab="insurance">Страхование</li>\n	<li data-tab="tradein">Trade-in</li>\n</ul>\n<ul id="tabContent" class="tabs-content">\n	<li class="tab-li active" data-tab="finance">\n	<h2>Автокредитование</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                                Компания «Гедон Авто-Премиум» предлагает  Вам широкий спектр программ по автокредитованию совместно с ведущими кредитными организациями. <span style="background-color: initial;">Исходя из Ваших предпочтений, мы поможем Вам выбрать оптимальную кредитную программу и обеспечим оперативное оформление покупки.</span> <br>\n			 <br>\n			   После окончательного расчета банка с автоцентром Вы становитесь счастливым обладателем нового INFINITI. <span style="background-color: initial;">Для приобретения в кредит автомобилей Infiniti можно воспользоваться специальной программой Infiniti Finance. </span><span style="background-color: initial;">За более подробной информацией обращайтесь к нашему консультанту по автокредитованию и страхованию.</span>\n		</div>\n		<div class="column column-40">\n			                                Для оформления автокредита достаточно:\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">Выбрать автомобиль</span></li>\n				<li class="typical-li">Подобрать совместно с консультантом по автокредитованию и страхованию кредитную программу, заполнить заявление на кредит и приложить к нему необходимый пакет документов</li>\n				<li class="typical-li">При получении положительного решения внести первоначальный взнос в кассу автоцентра, оформить страховки (КАСКО и ОСАГО) и подписать с банком кредитный договор и договор залога</li>\n			</ul>\n		</div>\n	</div>\n	<h2>INFINITI FINANCE</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			 <span style="background-color: initial;">Программа INFINITI FINANCE является уникальной новаторской программой по приобретению автомобилей INFINITI в кредит. </span><span style="background-color: initial;">INFINITI FINANCE предлагает особый индивидуальный подход к каждому клиенту и гарантирует предоставление услуг на высоком уровне. </span><span style="background-color: initial;">При покупке автомобиля по кредитной программе INFINITI FINANCE полностью обеспечивается надежность, комфорт и безупречное оформление. К</span><span style="background-color: initial;">редитная программа INFINITI FINANCE предлагается совместно с ЗАО «ЮниКредит Банк». </span><span style="background-color: initial;">Вы можете быть уверены, что INFINITI FINANCE – это те же высокие качество и сервис, которые вы вправе ожидать от любой продукции компании INFINITI.<br>\n			 <br>\n			 </span>\n		</div>\n	</div>\n	<h3>Кредит по программе INFINITI FINANCE – это:</h3>\n	<div class="desc clearfix">\n		<div class="column column-60">\n			<strong>   Эксклюзивно</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">Решение о выдаче кредита – от 1 дня*; </span></li>\n				<li class="typical-li"><span style="background-color: initial;">Весь процесс, включая оформление кредитной сделки, происходит в дилерском центре; </span></li>\n				<li class="typical-li"><span style="background-color: initial;">Возможность ежемесячно выплачивать кредит только за часть автомобиля по программе с отсрочкой погашения.</span></li>\n			</ul>\n			<br>\n			<strong>  Выгодно</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li">Специальные кредитные предложения без скрытых комиссий на весь модельный ряд INFINITI; </li>\n				<li class="typical-li">Кредитные ставки не зависят от формы подтверждения дохода; </li>\n				<li class="typical-li">Отсутствует мораторий на досрочное погашение.</li>\n			</ul>\n			 <br>\n			<strong>  Удобно</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li">Программа кредитования по 2м документам**;</li>\n				<li class="typical-li">В сумму кредита могут быть включены страховые премии за 1-й год;</li>\n				<li class="typical-li">Гибкий подход банка к оценке дохода клиента.</li>\n			</ul>\n			 <br>\n			<strong>  Практично</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li">Решение о выдаче кредита действует 60 дней;</li>\n				<li class="typical-li">Сумма кредита от 100 тыс. до 6,5  млн. рублей;</li>\n				<li class="typical-li">Возможность чаще менять автомобиль с помощью программы рефинансирования.</li>\n			</ul>\n			<div class="dict">\n				       * ЗАО «ЮниКредит Банк» оставляет за собой право отказать в предоставлении кредита без объяснения причины.<br>\n				       ** При авансе более 30%. При авансе менее 30% необходимо предоставить копию трудовой книжки и справку о доходах по форме 2НДФЛ (на официальную или полную часть) и/или в свободной форме.<br>\n			</div>\n		</div>\n	</div>\n	</li>\n	<li class="tab-li" data-tab="insurance">\n	<h2>Автострахование</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			<span style="background-color: initial;"><span style="background-color: initial;">Автострахование – это надежная защита Вас, близких Вам людей и Вашего автомобиля. В современном мире каждый автовладелец понимает актуальность страхования. Факт обладания страховым полисом дает чувство уверенности в случае возникновения непредвиденных ситуаций на дорогах и помогает сохранить средства, вложенные в автомобиль. </span><span style="background-color: initial;">Специалисты нашего автоцентра помогут Вам разобраться во всем разнообразии страховых услуг, подобрать оптимальный вариант и оформить страховые договоры по продуктам: КАСКО, ОСАГО и ДоСАГО.<br>\n			<br>\n			</span><span style="background-color: initial;">Мы сотрудничаем с ведущими российскими страховыми компаниями. </span><span style="background-color: initial;">Широкий выбор пакетов предлагаемых ими услуг и форм оплаты полисов </span><span style="background-color: initial;">позволит выбрать наиболее выгодный для Вас вариант. <br>\n			 <br>\n			 </span><span style="background-color: initial;"><strong>Оформив полис в одной из наших компаний-партнеров, Вы можете быть уверены в: </strong>\n			<div>\n				<div>\n					<ul class="typical-ul">\n						<li class="typical-li">гарантированном направлении на ремонт в автоцентр «Гедон Авто-Премиум» застрахованных автомобилей;</li>\n						<li class="typical-li">выезде аварийного комиссара на место ДТП;</li>\n						<li class="typical-li">лояльности страховой компании при рассмотрении страхового случая;</li>\n						<li class="typical-li">возможности поэтапной оплаты страховой премии и др.</li>\n					</ul>\n				</div>\n			</div>\n			</span> </span>\n		</div>\n		<div>\n			 <span style="background-color: initial;">Получить подробную информацию по автострахованию, расчету тарифа КАСКО и подбору наиболее выгодных условий страхования Вы можете у консультанта  по автокредитованию и страхованию нашего автоцентра по телефону:<br>\n			 </span><br>\n			                    +7 (863) 292-88-92, <br>\n			   е-mail: <a href="mailto:infiniticredit@gedon.ru">infiniticredit@gedon.ru</a>\n		</div>\n	</div>\n	</li>\n	<li class="tab-li" data-tab="tradein">\n	<h2>Программа Trade-in</h2>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			                Компания «Гедон Авто-Премиум» предлагает воспользоваться оптимальной программой обмена Вашего автомобиля на новый автомобиль INFINITI — Trade-in. Trade-in — это система взаиморасчета, при которой Ваш автомобиль с пробегом принимается как частичный взнос за новый автомобиль (возможен кредит). Программа Trade-in создана специально для активных деловых людей, ценящих комфорт, оперативность и безопасность сделки. В современном мире система Trade-in стала востребованной услугой и заняла достойное место на рынке операций с транспортными средствами.\n		</div>\n		<div class="column column-40">\n			              Мы ответим на все интересующие Вас вопросы по телефону: <br>\n			 +7 (863) 292-88-92\n		</div>\n	</div>\n	<div class="clearfix margin-bottom-60">\n		<div class="column column-60">\n			<strong>     Схема Trade-in:</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">Вы приезжаете в автоцентр «Гедон Авто-Премиум»; </span></li>\n				<li class="typical-li"><span style="background-color: initial;">Наши специалисты проводят предварительную оценку Вашего автомобиля; </span></li>\n				<li class="typical-li"><span style="background-color: initial;">Специалисты сервисного центра «Гедон Авто-Премиум» осуществляют диагностику технического состояния Вашего автомобиля по 49 параметрам. По результатам диагностики выдается полный Акт осмотра (стоимость услуги – 2 300 руб.);</span></li>\n				<li class="typical-li"><span style="background-color: initial;">Определяется окончательная стоимость автомобиля;<br>\n				 </span></li>\n				<li class="typical-li"><span style="background-color: initial;">Оформляется покупка нового автомобиля INFINITI с зачетом стоимости сданного автомобиля.<br>\n				 </span></li>\n			</ul>\n			<br>\n			<strong> Документы, необходимые для оформления автомобиля по схеме Trade-in:</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">ПТС (с отметкой о снятии автомобиля с учета);</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Паспорт владельца;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Ген. доверенность нотариальная (в случае, если Вы не являетесь собственником автомобиля);</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Лист осмотра (рекомендации диагностики);</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Сервисная книжка и гарантийные документы;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Комплект ключей зажигания.</span></li>\n			</ul>\n			 <br>\n			<strong> Главные преимущества Trade-in в автоцентре «Гедон Авто-Премиум»:</strong><br>\n			<ul class="typical-ul">\n				<li class="typical-li"><span style="background-color: initial;">Оперативное оформление сделки. Зачет денежных средств за автомобиль в максимально короткий срок;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Квалифицированная оценка рыночной стоимости Вашего автомобиля;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Отсутствие обременительной и не всегда безопасной процедуры самостоятельной продажи автомобиля с пробегом;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Учет индивидуальных особенностей и преимуществ Вашего автомобиля;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Полная диагностика автомобиля с пробегом, сервисная история, рекомендации по ремонту и т.д;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">Экономия времени;</span></li>\n				<li class="typical-li"><span style="background-color: initial;"></span><span style="background-color: initial;">По желанию возможен безналичный расчет, а также кредит при покупке нового автомобиля INFINITI.</span></li>\n			</ul>\n			<br>\n		</div>\n		<div class="column column-40">\n			               Вы хотите купить новый автомобиль INFINITI в кредит, но у Вас не погашен кредит за автомобиль, который Вы планируете сдать по схеме Trade-in? Специально для Вас разработана новая услуга — рефинансирование.\n		</div>\n	</div>\n	 </li>\n</ul>\n</section></main>', 'uslugi', 'Услуги', '', '', '', '2014-08-01 08:51:06', '2014-08-12 13:41:50'),
(12, 12, 'ru', 'Контакты', '', 'kontakty', 'Контакты', '', '', '', '2014-08-01 08:55:41', '2014-08-01 10:45:35'),
(13, 13, 'ru', 'Сервис и запчасти. Аксессуары', '', 'servis-i-zapchasti-aksessuary', 'Сервис и запчасти. Аксессуары', '', '', '', '2014-08-01 14:28:24', '2014-08-01 14:28:24'),
(14, 14, 'ru', 'Автомобили с пробегом', '', 'avtomobili-s-probegom', 'Автомобили с пробегом', '', '', '', '2014-08-04 11:46:18', '2014-08-05 12:55:48'),
(15, 15, 'ru', 'Автомобили в наличии', '', 'avtomobili-v-nalichii', 'Автомобили в наличии', '', '', '', '2014-08-05 15:11:30', '2014-08-05 15:11:30');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_i18n_pages_table', 1),
('2014_01_01_100070_create_i18n_news_table', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_tags_table', 1),
('2014_06_19_133757_create_production_tables', 1),
('2014_07_14_124747_create_channels_tables', 1),
('2014_07_17_130340_create_session_table', 1),
('2014_07_23_150206_create_events_table', 1),
('2014_07_29_104336_create_production_video', 1),
('2014_07_30_111418_create_production_colors', 1),
('2014_07_30_142645_create_production_complections', 1),
('2014_07_31_081207_create_production_accessories', 1),
('2014_07_31_081802_create_production_accessories_categories', 1),
('2014_07_31_081809_create_production_accessories_accessibility', 1),
('2014_08_01_104650_create_related_production', 2),
('2014_08_05_142645_create_production_instock', 3),
('2014_08_06_081802_create_production_galleries', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'pages', 1, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'news', 1, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(3, 'galleries', 1, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:41'),
(4, 'tags', 0, 0, '2014-07-31 11:11:01', '2014-07-31 11:11:38'),
(5, 'production', 1, 0, '2014-07-31 11:11:39', '2014-07-31 11:11:39'),
(6, 'events', 1, 0, '2014-07-31 11:11:42', '2014-07-31 11:11:42'),
(7, 'channels', 1, 0, '2014-07-31 11:11:43', '2014-07-31 11:11:43');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=882 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(7, '1406813612_1701.jpg', '0', '2014-07-31 13:33:32', '2014-07-31 13:33:32'),
(8, '1406813643_1988.jpg', '0', '2014-07-31 13:34:03', '2014-07-31 13:34:03'),
(9, '1406813674_1020.jpg', '0', '2014-07-31 13:34:35', '2014-07-31 13:34:35'),
(10, '1406813696_1132.jpg', '0', '2014-07-31 13:34:56', '2014-07-31 13:34:56'),
(11, '1406813796_1658.jpg', '0', '2014-07-31 13:36:36', '2014-07-31 13:36:36'),
(12, '1406813829_1414.jpg', '0', '2014-07-31 13:37:09', '2014-07-31 13:37:09'),
(13, '1406813908_1137.jpg', '0', '2014-07-31 13:38:28', '2014-07-31 13:38:28'),
(14, '1406813929_1488.jpg', '0', '2014-07-31 13:38:49', '2014-07-31 13:38:49'),
(15, '1406813955_1440.jpg', '0', '2014-07-31 13:39:15', '2014-07-31 13:39:15'),
(16, '1406814004_1303.jpg', '0', '2014-07-31 13:40:04', '2014-07-31 13:40:04'),
(20, '1406815097_1047.png', '0', '2014-07-31 13:58:17', '2014-07-31 13:58:17'),
(21, '1406815978_1699.jpeg', '2', '2014-07-31 14:12:59', '2014-07-31 14:14:16'),
(22, '1406815980_1997.jpeg', '2', '2014-07-31 14:13:00', '2014-07-31 14:14:16'),
(23, '1406815980_1544.jpeg', '2', '2014-07-31 14:13:01', '2014-07-31 14:14:16'),
(24, '1406815981_1260.jpeg', '2', '2014-07-31 14:13:02', '2014-07-31 14:14:16'),
(25, '1406816046_1997.jpeg', '3', '2014-07-31 14:14:08', '2014-07-31 14:14:16'),
(26, '1406816047_1057.jpeg', '3', '2014-07-31 14:14:08', '2014-07-31 14:14:16'),
(27, '1406816049_1376.jpeg', '3', '2014-07-31 14:14:09', '2014-07-31 14:14:16'),
(34, '1406878667_1424.jpeg', '-1', '2014-08-01 07:37:47', '2014-08-01 07:37:50'),
(39, '1406879414_1100.jpeg', '-1', '2014-08-01 07:50:15', '2014-08-01 07:50:17'),
(56, '1407218569_1337.jpeg', '0', '2014-08-05 06:02:50', '2014-08-05 06:02:50'),
(57, '1407218634_1149.jpeg', '0', '2014-08-05 06:03:55', '2014-08-05 06:03:55'),
(58, '1407218673_1556.jpeg', '0', '2014-08-05 06:04:33', '2014-08-05 06:04:33'),
(59, '1407233792_1665.jpg', '0', '2014-08-05 10:16:32', '2014-08-05 10:16:32'),
(61, '1407233900_1760.jpg', '0', '2014-08-05 10:18:20', '2014-08-05 10:18:20'),
(62, '1407233920_1468.jpg', '0', '2014-08-05 10:18:40', '2014-08-05 10:18:40'),
(63, '1407233935_1239.jpg', '0', '2014-08-05 10:18:55', '2014-08-05 10:18:55'),
(64, '1407233957_1306.jpg', '0', '2014-08-05 10:19:17', '2014-08-05 10:19:17'),
(65, '1407233972_1959.jpg', '0', '2014-08-05 10:19:32', '2014-08-05 10:19:32'),
(66, '1407233987_1358.jpg', '0', '2014-08-05 10:19:47', '2014-08-05 10:19:47'),
(67, '1407234002_1892.jpg', '0', '2014-08-05 10:20:02', '2014-08-05 10:20:02'),
(68, '1407234150_1296.jpeg', '4', '2014-08-05 10:22:31', '2014-08-05 10:23:07'),
(69, '1407234181_1958.jpeg', '4', '2014-08-05 10:23:02', '2014-08-05 10:23:07'),
(70, '1407234184_1602.jpeg', '4', '2014-08-05 10:23:05', '2014-08-05 10:23:07'),
(71, '1407234227_1711.jpeg', '4', '2014-08-05 10:23:48', '2014-08-05 10:23:54'),
(72, '1407234230_1660.jpeg', '4', '2014-08-05 10:23:51', '2014-08-05 10:23:54'),
(76, '1407237411_1226.jpg', '5', '2014-08-05 11:16:52', '2014-08-05 11:17:00'),
(77, '1407237413_1011.jpg', '5', '2014-08-05 11:16:53', '2014-08-05 11:17:00'),
(78, '1407237416_1478.jpg', '5', '2014-08-05 11:16:56', '2014-08-05 11:17:00'),
(79, '1407242050_1271.jpg', '6', '2014-08-05 12:34:11', '2014-08-05 12:34:15'),
(80, '1407242050_1625.jpg', '6', '2014-08-05 12:34:11', '2014-08-05 12:34:15'),
(81, '1407242051_1540.jpg', '6', '2014-08-05 12:34:11', '2014-08-05 12:34:15'),
(82, '1407242051_1656.jpg', '6', '2014-08-05 12:34:12', '2014-08-05 12:34:15'),
(83, '1407242051_1693.jpg', '6', '2014-08-05 12:34:12', '2014-08-05 12:34:15'),
(84, '1407242052_1192.jpg', '6', '2014-08-05 12:34:13', '2014-08-05 12:34:15'),
(85, '1407242052_1582.jpg', '6', '2014-08-05 12:34:13', '2014-08-05 12:34:15'),
(87, '1407242524_1300.jpg', '7', '2014-08-05 12:42:04', '2014-08-05 12:42:21'),
(88, '1407242527_1105.jpg', '7', '2014-08-05 12:42:07', '2014-08-05 12:42:21'),
(92, '1407243121_1958.jpg', '0', '2014-08-05 12:52:01', '2014-08-05 12:52:01'),
(93, '1407243140_1522.jpg', '9', '2014-08-05 12:52:21', '2014-08-05 12:52:51'),
(94, '1407243144_1758.jpg', '9', '2014-08-05 12:52:25', '2014-08-05 12:52:51'),
(95, '1407243169_1821.jpg', '9', '2014-08-05 12:52:49', '2014-08-05 12:52:51'),
(96, '1407244179_1356.jpg', '10', '2014-08-05 13:09:39', '2014-08-05 13:09:44'),
(97, '1407244182_1212.jpg', '10', '2014-08-05 13:09:42', '2014-08-05 13:09:44'),
(98, '1407244183_1025.jpg', '10', '2014-08-05 13:09:43', '2014-08-05 13:09:44'),
(100, '1407244612_1644.jpg', '11', '2014-08-05 13:16:53', '2014-08-05 13:17:04'),
(101, '1407244615_1848.jpg', '11', '2014-08-05 13:16:55', '2014-08-05 13:17:04'),
(103, '1407246587_1376.jpeg', '0', '2014-08-05 13:49:48', '2014-08-05 13:49:48'),
(105, '1407254242_1649.jpeg', '0', '2014-08-05 15:57:23', '2014-08-05 15:57:23'),
(106, '1407266672_1916.jpg', '0', '2014-08-05 19:24:32', '2014-08-05 19:24:32'),
(118, '1407268228_1451.png', '0', '2014-08-05 19:50:28', '2014-08-05 19:50:28'),
(119, '1407268674_1799.png', '0', '2014-08-05 19:57:54', '2014-08-05 19:57:54'),
(120, '1407268763_1529.png', '0', '2014-08-05 19:59:23', '2014-08-05 19:59:23'),
(121, '1407268872_1565.png', '0', '2014-08-05 20:01:12', '2014-08-05 20:01:12'),
(122, '1407268970_1244.png', '0', '2014-08-05 20:02:50', '2014-08-05 20:02:50'),
(123, '1407269078_1211.png', '0', '2014-08-05 20:04:38', '2014-08-05 20:04:38'),
(124, '1407269270_1839.png', '0', '2014-08-05 20:07:50', '2014-08-05 20:07:50'),
(125, '1407269349_1604.png', '0', '2014-08-05 20:09:09', '2014-08-05 20:09:09'),
(126, '1407269648_1473.jpeg', '12', '2014-08-05 20:14:09', '2014-08-05 20:16:35'),
(127, '1407269648_1012.jpeg', '12', '2014-08-05 20:14:09', '2014-08-05 20:16:35'),
(128, '1407269649_1631.jpeg', '12', '2014-08-05 20:14:10', '2014-08-05 20:16:35'),
(129, '1407269650_1067.jpeg', '12', '2014-08-05 20:14:10', '2014-08-05 20:16:35'),
(130, '1407269650_1044.jpeg', '12', '2014-08-05 20:14:10', '2014-08-05 20:16:35'),
(131, '1407269650_1892.jpeg', '12', '2014-08-05 20:14:11', '2014-08-05 20:16:35'),
(132, '1407269651_1172.jpeg', '12', '2014-08-05 20:14:11', '2014-08-05 20:16:35'),
(133, '1407269651_1963.jpeg', '12', '2014-08-05 20:14:11', '2014-08-05 20:16:35'),
(134, '1407269651_1124.jpeg', '12', '2014-08-05 20:14:12', '2014-08-05 20:16:35'),
(135, '1407269652_1997.jpeg', '12', '2014-08-05 20:14:12', '2014-08-05 20:16:35'),
(136, '1407269652_1119.jpeg', '12', '2014-08-05 20:14:13', '2014-08-05 20:16:35'),
(137, '1407269653_1974.jpeg', '12', '2014-08-05 20:14:13', '2014-08-05 20:16:35'),
(138, '1407269653_1756.jpeg', '12', '2014-08-05 20:14:13', '2014-08-05 20:16:35'),
(139, '1407269654_1399.jpeg', '12', '2014-08-05 20:14:14', '2014-08-05 20:16:35'),
(140, '1407269654_1770.jpeg', '12', '2014-08-05 20:14:14', '2014-08-05 20:16:35'),
(141, '1407269784_1664.jpeg', '13', '2014-08-05 20:16:24', '2014-08-05 20:16:35'),
(142, '1407269784_1143.jpeg', '13', '2014-08-05 20:16:24', '2014-08-05 20:16:35'),
(143, '1407269785_1659.jpeg', '13', '2014-08-05 20:16:25', '2014-08-05 20:16:35'),
(144, '1407269785_1779.jpeg', '13', '2014-08-05 20:16:25', '2014-08-05 20:16:35'),
(145, '1407269786_1934.jpeg', '13', '2014-08-05 20:16:26', '2014-08-05 20:16:35'),
(146, '1407269786_1524.jpeg', '13', '2014-08-05 20:16:26', '2014-08-05 20:16:35'),
(147, '1407269787_1396.jpeg', '13', '2014-08-05 20:16:27', '2014-08-05 20:16:35'),
(148, '1407269787_1215.jpeg', '13', '2014-08-05 20:16:27', '2014-08-05 20:16:35'),
(149, '1407269788_1199.jpeg', '13', '2014-08-05 20:16:28', '2014-08-05 20:16:35'),
(150, '1407269788_1686.jpeg', '13', '2014-08-05 20:16:28', '2014-08-05 20:16:35'),
(151, '1407269788_1861.jpeg', '13', '2014-08-05 20:16:29', '2014-08-05 20:16:35'),
(152, '1407269789_1932.jpeg', '13', '2014-08-05 20:16:29', '2014-08-05 20:16:35'),
(153, '1407270543_1363.jpg', '0', '2014-08-05 20:29:03', '2014-08-05 20:29:03'),
(154, '1407270947_1465.jpeg', '0', '2014-08-05 20:35:47', '2014-08-05 20:35:47'),
(156, '1407273460_1871.png', '0', '2014-08-05 21:17:40', '2014-08-05 21:17:40'),
(157, '1407273528_1032.png', '0', '2014-08-05 21:18:48', '2014-08-05 21:18:48'),
(158, '1407308326_1301.jpg', '0', '2014-08-06 06:58:47', '2014-08-06 06:58:47'),
(159, '1407308355_1165.jpg', '0', '2014-08-06 06:59:15', '2014-08-06 06:59:15'),
(160, '1407308387_1977.jpg', '0', '2014-08-06 06:59:47', '2014-08-06 06:59:47'),
(161, '1407308409_1121.jpg', '0', '2014-08-06 07:00:09', '2014-08-06 07:00:09'),
(163, '1407308453_1833.jpg', '0', '2014-08-06 07:00:54', '2014-08-06 07:00:54'),
(164, '1407308479_1932.jpg', '0', '2014-08-06 07:01:19', '2014-08-06 07:01:19'),
(165, '1407308493_1909.jpg', '0', '2014-08-06 07:01:33', '2014-08-06 07:01:33'),
(169, '1407310573_1417.jpg', '0', '2014-08-06 07:36:13', '2014-08-06 07:36:13'),
(170, '1407310706_1319.jpg', '0', '2014-08-06 07:38:27', '2014-08-06 07:38:27'),
(176, '1407327853_1721.jpeg', '0', '2014-08-06 12:24:14', '2014-08-06 12:24:14'),
(177, '1407327853_1587.jpeg', '0', '2014-08-06 12:24:14', '2014-08-06 12:24:14'),
(178, '1407327854_1769.jpeg', '0', '2014-08-06 12:24:15', '2014-08-06 12:24:15'),
(179, '1407327855_1683.jpeg', '0', '2014-08-06 12:24:15', '2014-08-06 12:24:15'),
(180, '1407327855_1960.jpeg', '0', '2014-08-06 12:24:16', '2014-08-06 12:24:16'),
(190, '1407329529_1039.jpg', '0', '2014-08-06 12:52:10', '2014-08-06 12:52:10'),
(191, '1407329533_1425.jpg', '16', '2014-08-06 12:52:14', '2014-08-06 12:52:19'),
(192, '1407331685_1391.jpg', '0', '2014-08-06 13:28:06', '2014-08-06 13:28:06'),
(193, '1407331721_1073.jpg', '17', '2014-08-06 13:28:41', '2014-08-06 13:28:44'),
(194, '1407331825_1494.jpg', '18', '2014-08-06 13:30:25', '2014-08-06 13:30:29'),
(195, '1407331886_1035.jpg', '19', '2014-08-06 13:31:27', '2014-08-06 13:31:43'),
(196, '1407332017_1132.jpg', '20', '2014-08-06 13:33:38', '2014-08-06 13:33:42'),
(198, '1407332284_1312.jpg', '22', '2014-08-06 13:38:04', '2014-08-06 13:38:08'),
(199, '1407332308_1441.jpg', '23', '2014-08-06 13:38:28', '2014-08-06 13:38:36'),
(200, '1407332519_1345.jpg', '0', '2014-08-06 13:41:59', '2014-08-06 13:41:59'),
(201, '1407332636_1539.jpg', '24', '2014-08-06 13:43:56', '2014-08-06 13:43:59'),
(202, '1407333647_1612.jpg', '25', '2014-08-06 14:00:47', '2014-08-06 14:00:50'),
(203, '1407334787_1854.jpg', '26', '2014-08-06 14:19:48', '2014-08-06 14:19:51'),
(204, '1407335035_1434.png', '0', '2014-08-06 14:23:55', '2014-08-06 14:23:55'),
(205, '1407335153_1556.png', '0', '2014-08-06 14:25:53', '2014-08-06 14:25:53'),
(206, '1407335249_1914.png', '0', '2014-08-06 14:27:29', '2014-08-06 14:27:29'),
(207, '1407336869_1778.jpg', '0', '2014-08-06 14:54:30', '2014-08-06 14:54:30'),
(208, '1407337474_1203.png', '0', '2014-08-06 15:04:35', '2014-08-06 15:04:35'),
(209, '1407338422_1670.jpeg', '27', '2014-08-06 15:20:22', '2014-08-06 15:20:39'),
(210, '1407339632_1288.jpeg', '28', '2014-08-06 15:40:33', '2014-08-06 15:40:38'),
(211, '1407339633_1995.jpeg', '28', '2014-08-06 15:40:34', '2014-08-06 15:40:38'),
(212, '1407339634_1649.jpeg', '28', '2014-08-06 15:40:34', '2014-08-06 15:40:38'),
(213, '1407339635_1436.jpeg', '28', '2014-08-06 15:40:35', '2014-08-06 15:40:38'),
(227, '1407342136_1161.png', '0', '2014-08-06 16:22:16', '2014-08-06 16:22:16'),
(228, '1407342215_1483.png', '0', '2014-08-06 16:23:35', '2014-08-06 16:23:35'),
(229, '1407342348_1145.png', '0', '2014-08-06 16:25:48', '2014-08-06 16:25:48'),
(230, '1407342496_1143.png', '0', '2014-08-06 16:28:16', '2014-08-06 16:28:16'),
(231, '1407342581_1778.png', '0', '2014-08-06 16:29:41', '2014-08-06 16:29:41'),
(236, '1407343051_1684.jpeg', '0', '2014-08-06 16:37:31', '2014-08-06 16:37:31'),
(237, '1407343053_1321.jpeg', '0', '2014-08-06 16:37:33', '2014-08-06 16:37:33'),
(238, '1407343053_1325.jpeg', '0', '2014-08-06 16:37:34', '2014-08-06 16:37:34'),
(239, '1407343055_1135.jpeg', '0', '2014-08-06 16:37:35', '2014-08-06 16:37:35'),
(240, '1407343283_1527.jpeg', '0', '2014-08-06 16:41:23', '2014-08-06 16:41:23'),
(241, '1407343284_1569.jpeg', '0', '2014-08-06 16:41:25', '2014-08-06 16:41:25'),
(242, '1407343292_1006.jpeg', '0', '2014-08-06 16:41:33', '2014-08-06 16:41:33'),
(243, '1407343294_1141.jpeg', '0', '2014-08-06 16:41:34', '2014-08-06 16:41:34'),
(244, '1407343302_1968.jpeg', '0', '2014-08-06 16:41:42', '2014-08-06 16:41:42'),
(245, '1407343310_1817.jpeg', '0', '2014-08-06 16:41:50', '2014-08-06 16:41:50'),
(246, '1407343310_1770.jpeg', '0', '2014-08-06 16:41:51', '2014-08-06 16:41:51'),
(247, '1407343321_1491.jpeg', '0', '2014-08-06 16:42:02', '2014-08-06 16:42:02'),
(248, '1407343329_1006.jpeg', '0', '2014-08-06 16:42:09', '2014-08-06 16:42:09'),
(249, '1407343332_1532.jpeg', '0', '2014-08-06 16:42:12', '2014-08-06 16:42:12'),
(250, '1407343338_1219.jpg', '0', '2014-08-06 16:42:19', '2014-08-06 16:42:19'),
(251, '1407343340_1064.jpeg', '0', '2014-08-06 16:42:21', '2014-08-06 16:42:21'),
(252, '1407343341_1968.jpeg', '0', '2014-08-06 16:42:21', '2014-08-06 16:42:21'),
(273, '1407387678_1249.png', '0', '2014-08-07 05:01:19', '2014-08-07 05:01:19'),
(274, '1407388062_1705.png', '0', '2014-08-07 05:07:42', '2014-08-07 05:07:42'),
(275, '1407388481_1044.png', '0', '2014-08-07 05:14:41', '2014-08-07 05:14:41'),
(276, '1407388593_1774.png', '0', '2014-08-07 05:16:33', '2014-08-07 05:16:33'),
(277, '1407388690_1268.png', '0', '2014-08-07 05:18:10', '2014-08-07 05:18:10'),
(278, '1407388769_1660.png', '0', '2014-08-07 05:19:29', '2014-08-07 05:19:29'),
(279, '1407390250_1472.png', '0', '2014-08-07 05:44:10', '2014-08-07 05:44:10'),
(280, '1407390310_1795.png', '0', '2014-08-07 05:45:10', '2014-08-07 05:45:10'),
(281, '1407390540_1747.png', '0', '2014-08-07 05:49:00', '2014-08-07 05:49:00'),
(282, '1407390869_1930.jpg', '33', '2014-08-07 05:54:30', '2014-08-07 05:54:33'),
(283, '1407391161_1781.jpg', '34', '2014-08-07 05:59:21', '2014-08-07 05:59:24'),
(284, '1407391372_1663.png', '0', '2014-08-07 06:02:52', '2014-08-07 06:02:52'),
(285, '1407391426_1948.png', '0', '2014-08-07 06:03:46', '2014-08-07 06:03:46'),
(286, '1407391489_1875.png', '0', '2014-08-07 06:04:49', '2014-08-07 06:04:49'),
(287, '1407391542_1718.png', '0', '2014-08-07 06:05:42', '2014-08-07 06:05:42'),
(288, '1407391609_1826.png', '0', '2014-08-07 06:06:49', '2014-08-07 06:06:49'),
(289, '1407391665_1312.png', '0', '2014-08-07 06:07:45', '2014-08-07 06:07:45'),
(290, '1407391763_1023.png', '0', '2014-08-07 06:09:23', '2014-08-07 06:09:23'),
(291, '1407391836_1999.png', '0', '2014-08-07 06:10:36', '2014-08-07 06:10:36'),
(292, '1407391929_1119.png', '0', '2014-08-07 06:12:09', '2014-08-07 06:12:09'),
(293, '1407392009_1091.png', '0', '2014-08-07 06:13:29', '2014-08-07 06:13:29'),
(294, '1407392176_1025.png', '0', '2014-08-07 06:16:16', '2014-08-07 06:16:16'),
(295, '1407392238_1072.png', '0', '2014-08-07 06:17:18', '2014-08-07 06:17:18'),
(296, '1407392438_1365.png', '0', '2014-08-07 06:20:38', '2014-08-07 06:20:38'),
(297, '1407393097_1225.png', '0', '2014-08-07 06:31:37', '2014-08-07 06:31:37'),
(298, '1407393288_1643.png', '0', '2014-08-07 06:34:48', '2014-08-07 06:34:48'),
(299, '1407393441_1791.png', '0', '2014-08-07 06:37:21', '2014-08-07 06:37:21'),
(300, '1407393516_1466.png', '0', '2014-08-07 06:38:36', '2014-08-07 06:38:36'),
(301, '1407393570_1104.png', '0', '2014-08-07 06:39:30', '2014-08-07 06:39:30'),
(302, '1407393638_1549.png', '0', '2014-08-07 06:40:38', '2014-08-07 06:40:38'),
(309, '1407405561_1305.jpg', '35', '2014-08-07 09:59:22', '2014-08-07 09:59:22'),
(310, '1407405562_1178.jpg', '35', '2014-08-07 09:59:22', '2014-08-07 09:59:22'),
(311, '1407405564_1895.jpg', '35', '2014-08-07 09:59:24', '2014-08-07 09:59:24'),
(317, '1407408100_1195.jpg', '0', '2014-08-07 10:41:40', '2014-08-07 10:41:40'),
(318, '1407408213_1040.jpg', '0', '2014-08-07 10:43:33', '2014-08-07 10:43:33'),
(319, '1407408357_1876.jpg', '0', '2014-08-07 10:45:57', '2014-08-07 10:45:57'),
(320, '1407408449_1279.jpg', '0', '2014-08-07 10:47:29', '2014-08-07 10:47:29'),
(321, '1407408482_1650.jpg', '0', '2014-08-07 10:48:02', '2014-08-07 10:48:02'),
(322, '1407408525_1995.jpg', '0', '2014-08-07 10:48:45', '2014-08-07 10:48:45'),
(323, '1407408571_1313.jpg', '0', '2014-08-07 10:49:31', '2014-08-07 10:49:31'),
(324, '1407408596_1147.jpg', '0', '2014-08-07 10:49:56', '2014-08-07 10:49:56'),
(325, '1407408635_1591.jpg', '0', '2014-08-07 10:50:35', '2014-08-07 10:50:35'),
(326, '1407408667_1366.jpg', '0', '2014-08-07 10:51:07', '2014-08-07 10:51:07'),
(327, '1407408724_1618.jpg', '0', '2014-08-07 10:52:04', '2014-08-07 10:52:04'),
(328, '1407408758_1876.jpg', '0', '2014-08-07 10:52:38', '2014-08-07 10:52:38'),
(329, '1407408793_1363.jpg', '0', '2014-08-07 10:53:13', '2014-08-07 10:53:13'),
(330, '1407408827_1337.jpg', '0', '2014-08-07 10:53:47', '2014-08-07 10:53:47'),
(331, '1407409140_1392.jpg', '0', '2014-08-07 10:59:00', '2014-08-07 10:59:00'),
(332, '1407409164_1815.jpg', '0', '2014-08-07 10:59:24', '2014-08-07 10:59:24'),
(333, '1407409186_1147.jpg', '0', '2014-08-07 10:59:46', '2014-08-07 10:59:46'),
(334, '1407409216_1746.jpg', '0', '2014-08-07 11:00:16', '2014-08-07 11:00:16'),
(335, '1407409236_1029.jpg', '0', '2014-08-07 11:00:36', '2014-08-07 11:00:36'),
(336, '1407409261_1859.jpg', '0', '2014-08-07 11:01:01', '2014-08-07 11:01:01'),
(337, '1407409289_1383.jpg', '0', '2014-08-07 11:01:29', '2014-08-07 11:01:29'),
(338, '1407409326_1061.jpg', '0', '2014-08-07 11:02:06', '2014-08-07 11:02:06'),
(339, '1407409355_1786.jpg', '0', '2014-08-07 11:02:35', '2014-08-07 11:02:35'),
(340, '1407409388_1813.jpg', '0', '2014-08-07 11:03:08', '2014-08-07 11:03:08'),
(341, '1407409412_1319.jpg', '0', '2014-08-07 11:03:32', '2014-08-07 11:03:32'),
(342, '1407409433_1627.jpg', '0', '2014-08-07 11:03:53', '2014-08-07 11:03:53'),
(343, '1407409456_1895.jpg', '0', '2014-08-07 11:04:16', '2014-08-07 11:04:16'),
(344, '1407409625_1026.jpg', '0', '2014-08-07 11:07:05', '2014-08-07 11:07:05'),
(345, '1407409729_1914.jpg', '0', '2014-08-07 11:08:49', '2014-08-07 11:08:49'),
(346, '1407409751_1039.jpg', '0', '2014-08-07 11:09:11', '2014-08-07 11:09:11'),
(347, '1407409774_1517.jpg', '0', '2014-08-07 11:09:34', '2014-08-07 11:09:34'),
(348, '1407409837_1487.jpg', '0', '2014-08-07 11:10:37', '2014-08-07 11:10:37'),
(350, '1407409898_1608.jpg', '0', '2014-08-07 11:11:38', '2014-08-07 11:11:38'),
(351, '1407409919_1374.jpg', '0', '2014-08-07 11:11:59', '2014-08-07 11:11:59'),
(352, '1407409951_1717.jpg', '0', '2014-08-07 11:12:31', '2014-08-07 11:12:31'),
(353, '1407409981_1875.jpg', '0', '2014-08-07 11:13:01', '2014-08-07 11:13:01'),
(354, '1407410002_1643.jpg', '0', '2014-08-07 11:13:22', '2014-08-07 11:13:22'),
(355, '1407410040_1862.jpg', '0', '2014-08-07 11:14:00', '2014-08-07 11:14:00'),
(356, '1407410064_1436.jpg', '0', '2014-08-07 11:14:25', '2014-08-07 11:14:25'),
(357, '1407410090_1789.jpg', '0', '2014-08-07 11:14:50', '2014-08-07 11:14:50'),
(358, '1407410127_1512.jpg', '0', '2014-08-07 11:15:27', '2014-08-07 11:15:27'),
(359, '1407410162_1937.jpg', '0', '2014-08-07 11:16:02', '2014-08-07 11:16:02'),
(360, '1407410189_1004.jpg', '0', '2014-08-07 11:16:29', '2014-08-07 11:16:29'),
(361, '1407410210_1778.jpg', '0', '2014-08-07 11:16:50', '2014-08-07 11:16:50'),
(362, '1407410234_1085.jpg', '0', '2014-08-07 11:17:14', '2014-08-07 11:17:14'),
(363, '1407410254_1876.jpg', '0', '2014-08-07 11:17:34', '2014-08-07 11:17:34'),
(364, '1407410288_1598.jpg', '0', '2014-08-07 11:18:08', '2014-08-07 11:18:08'),
(365, '1407410542_1681.jpg', '0', '2014-08-07 11:22:22', '2014-08-07 11:22:22'),
(366, '1407410564_1279.jpg', '0', '2014-08-07 11:22:44', '2014-08-07 11:22:44'),
(367, '1407410584_1561.jpg', '0', '2014-08-07 11:23:04', '2014-08-07 11:23:04'),
(368, '1407410615_1966.jpg', '0', '2014-08-07 11:23:35', '2014-08-07 11:23:35'),
(369, '1407410836_1957.jpg', '0', '2014-08-07 11:27:16', '2014-08-07 11:27:16'),
(370, '1407410863_1002.jpg', '0', '2014-08-07 11:27:43', '2014-08-07 11:27:43'),
(371, '1407410895_1228.jpg', '0', '2014-08-07 11:28:15', '2014-08-07 11:28:15'),
(372, '1407410925_1255.jpg', '0', '2014-08-07 11:28:45', '2014-08-07 11:28:45'),
(373, '1407410970_1076.jpg', '0', '2014-08-07 11:29:30', '2014-08-07 11:29:30'),
(374, '1407410995_1639.jpg', '0', '2014-08-07 11:29:55', '2014-08-07 11:29:55'),
(375, '1407411066_1244.gif', '0', '2014-08-07 11:31:06', '2014-08-07 11:31:06'),
(376, '1407411097_1728.jpg', '0', '2014-08-07 11:31:37', '2014-08-07 11:31:37'),
(377, '1407411117_1700.jpg', '0', '2014-08-07 11:31:57', '2014-08-07 11:31:57'),
(378, '1407411144_1109.jpg', '0', '2014-08-07 11:32:24', '2014-08-07 11:32:24'),
(379, '1407411169_1469.jpg', '0', '2014-08-07 11:32:49', '2014-08-07 11:32:49'),
(380, '1407411220_1990.jpg', '0', '2014-08-07 11:33:40', '2014-08-07 11:33:40'),
(381, '1407411269_1855.jpg', '0', '2014-08-07 11:34:29', '2014-08-07 11:34:29'),
(382, '1407411297_1544.jpg', '0', '2014-08-07 11:34:57', '2014-08-07 11:34:57'),
(383, '1407411324_1249.jpg', '0', '2014-08-07 11:35:24', '2014-08-07 11:35:24'),
(384, '1407411350_1169.jpg', '0', '2014-08-07 11:35:50', '2014-08-07 11:35:50'),
(385, '1407411523_1821.jpg', '0', '2014-08-07 11:38:43', '2014-08-07 11:38:43'),
(386, '1407411548_1517.jpg', '0', '2014-08-07 11:39:08', '2014-08-07 11:39:08'),
(387, '1407411583_1968.jpg', '0', '2014-08-07 11:39:43', '2014-08-07 11:39:43'),
(388, '1407411602_1388.jpg', '0', '2014-08-07 11:40:02', '2014-08-07 11:40:02'),
(389, '1407411623_1913.jpg', '0', '2014-08-07 11:40:23', '2014-08-07 11:40:23'),
(390, '1407411988_1701.jpg', '0', '2014-08-07 11:46:28', '2014-08-07 11:46:28'),
(391, '1407412007_1451.jpg', '0', '2014-08-07 11:46:47', '2014-08-07 11:46:47'),
(392, '1407412044_1558.jpg', '0', '2014-08-07 11:47:24', '2014-08-07 11:47:24'),
(393, '1407412078_1496.jpg', '0', '2014-08-07 11:47:58', '2014-08-07 11:47:58'),
(394, '1407412111_1165.jpg', '0', '2014-08-07 11:48:31', '2014-08-07 11:48:31'),
(395, '1407412129_1731.jpg', '0', '2014-08-07 11:48:49', '2014-08-07 11:48:49'),
(396, '1407412179_1204.jpg', '0', '2014-08-07 11:49:39', '2014-08-07 11:49:39'),
(397, '1407412209_1084.jpg', '0', '2014-08-07 11:50:09', '2014-08-07 11:50:09'),
(398, '1407412466_1507.jpg', '0', '2014-08-07 11:54:26', '2014-08-07 11:54:26'),
(399, '1407412527_1647.jpg', '0', '2014-08-07 11:55:27', '2014-08-07 11:55:27'),
(400, '1407412565_1700.jpg', '0', '2014-08-07 11:56:05', '2014-08-07 11:56:05'),
(401, '1407413064_1945.jpg', '0', '2014-08-07 12:04:24', '2014-08-07 12:04:24'),
(402, '1407413094_1361.jpg', '0', '2014-08-07 12:04:54', '2014-08-07 12:04:54'),
(403, '1407413143_1913.jpg', '0', '2014-08-07 12:05:43', '2014-08-07 12:05:43'),
(404, '1407413189_1212.jpg', '0', '2014-08-07 12:06:29', '2014-08-07 12:06:29'),
(405, '1407413210_1471.jpg', '0', '2014-08-07 12:06:50', '2014-08-07 12:06:50'),
(406, '1407413774_1563.jpg', '0', '2014-08-07 12:16:14', '2014-08-07 12:16:14'),
(407, '1407413800_1179.jpg', '0', '2014-08-07 12:16:40', '2014-08-07 12:16:40'),
(408, '1407413946_1820.jpg', '0', '2014-08-07 12:19:06', '2014-08-07 12:19:06'),
(409, '1407413983_1844.jpg', '0', '2014-08-07 12:19:43', '2014-08-07 12:19:43'),
(410, '1407414025_1253.jpg', '0', '2014-08-07 12:20:25', '2014-08-07 12:20:25'),
(411, '1407414070_1968.jpg', '0', '2014-08-07 12:21:11', '2014-08-07 12:21:11'),
(412, '1407414092_1387.jpg', '0', '2014-08-07 12:21:32', '2014-08-07 12:21:32'),
(413, '1407414122_1349.jpg', '0', '2014-08-07 12:22:02', '2014-08-07 12:22:02'),
(414, '1407414151_1255.jpg', '0', '2014-08-07 12:22:31', '2014-08-07 12:22:31'),
(415, '1407414167_1992.jpg', '0', '2014-08-07 12:22:47', '2014-08-07 12:22:47'),
(416, '1407414196_1526.jpg', '0', '2014-08-07 12:23:16', '2014-08-07 12:23:16'),
(417, '1407414252_1131.jpg', '36', '2014-08-07 12:24:12', '2014-08-07 12:24:16'),
(418, '1407414395_1036.jpg', '0', '2014-08-07 12:26:35', '2014-08-07 12:26:35'),
(419, '1407414416_1272.jpg', '0', '2014-08-07 12:26:56', '2014-08-07 12:26:56'),
(420, '1407414434_1105.jpg', '0', '2014-08-07 12:27:14', '2014-08-07 12:27:14'),
(421, '1407414452_1626.jpg', '0', '2014-08-07 12:27:32', '2014-08-07 12:27:32'),
(422, '1407414476_1063.jpg', '0', '2014-08-07 12:27:56', '2014-08-07 12:27:56'),
(423, '1407414505_1851.jpg', '0', '2014-08-07 12:28:25', '2014-08-07 12:28:25'),
(424, '1407414523_1969.jpg', '0', '2014-08-07 12:28:43', '2014-08-07 12:28:43'),
(425, '1407414542_1090.jpg', '0', '2014-08-07 12:29:02', '2014-08-07 12:29:02'),
(426, '1407414560_1973.jpg', '0', '2014-08-07 12:29:20', '2014-08-07 12:29:20'),
(427, '1407414578_1832.jpg', '0', '2014-08-07 12:29:38', '2014-08-07 12:29:38'),
(428, '1407414596_1603.jpg', '0', '2014-08-07 12:29:56', '2014-08-07 12:29:56'),
(429, '1407414616_1170.jpg', '0', '2014-08-07 12:30:16', '2014-08-07 12:30:16'),
(430, '1407414635_1359.jpg', '0', '2014-08-07 12:30:35', '2014-08-07 12:30:35'),
(431, '1407414652_1547.jpg', '0', '2014-08-07 12:30:52', '2014-08-07 12:30:52'),
(432, '1407414671_1430.jpg', '0', '2014-08-07 12:31:11', '2014-08-07 12:31:11'),
(433, '1407414690_1861.jpg', '0', '2014-08-07 12:31:30', '2014-08-07 12:31:30'),
(434, '1407414715_1013.jpg', '0', '2014-08-07 12:31:55', '2014-08-07 12:31:55'),
(435, '1407414917_1112.jpg', '0', '2014-08-07 12:35:17', '2014-08-07 12:35:17'),
(437, '1407415065_1362.jpg', '0', '2014-08-07 12:37:45', '2014-08-07 12:37:45'),
(438, '1407415087_1506.jpg', '0', '2014-08-07 12:38:07', '2014-08-07 12:38:07'),
(439, '1407415119_1233.jpg', '0', '2014-08-07 12:38:39', '2014-08-07 12:38:39'),
(440, '1407415142_1181.jpg', '0', '2014-08-07 12:39:02', '2014-08-07 12:39:02'),
(441, '1407415161_1595.jpg', '0', '2014-08-07 12:39:22', '2014-08-07 12:39:22'),
(442, '1407415177_1706.jpg', '0', '2014-08-07 12:39:37', '2014-08-07 12:39:37'),
(443, '1407415194_1166.jpg', '0', '2014-08-07 12:39:54', '2014-08-07 12:39:54'),
(444, '1407415215_1550.jpg', '0', '2014-08-07 12:40:15', '2014-08-07 12:40:15'),
(445, '1407415240_1739.jpg', '0', '2014-08-07 12:40:40', '2014-08-07 12:40:40'),
(446, '1407415258_1529.jpg', '0', '2014-08-07 12:40:58', '2014-08-07 12:40:58'),
(447, '1407415278_1786.jpg', '0', '2014-08-07 12:41:18', '2014-08-07 12:41:18'),
(448, '1407415302_1617.jpg', '0', '2014-08-07 12:41:42', '2014-08-07 12:41:42'),
(449, '1407415319_1619.jpg', '0', '2014-08-07 12:41:59', '2014-08-07 12:41:59'),
(450, '1407415340_1763.jpg', '0', '2014-08-07 12:42:20', '2014-08-07 12:42:20'),
(451, '1407415360_1017.jpg', '0', '2014-08-07 12:42:40', '2014-08-07 12:42:40'),
(452, '1407415378_1522.jpg', '0', '2014-08-07 12:42:58', '2014-08-07 12:42:58'),
(453, '1407415399_1293.jpg', '0', '2014-08-07 12:43:19', '2014-08-07 12:43:19'),
(454, '1407415417_1311.jpg', '0', '2014-08-07 12:43:37', '2014-08-07 12:43:37'),
(602, '1407477334_1380.jpeg', '0', '2014-08-08 05:55:34', '2014-08-08 05:55:34'),
(603, '1407482318_1768.jpeg', '0', '2014-08-08 07:18:39', '2014-08-08 07:18:39'),
(605, '1407492142_1734.jpeg', '30', '2014-08-08 10:02:22', '2014-08-08 10:03:01'),
(606, '1407492142_1859.jpeg', '0', '2014-08-08 10:02:23', '2014-08-08 10:02:23'),
(607, '1407492146_1323.jpeg', '30', '2014-08-08 10:02:27', '2014-08-08 10:03:01'),
(609, '1407492157_1055.jpeg', '30', '2014-08-08 10:02:37', '2014-08-08 10:03:01'),
(610, '1407492178_1251.jpeg', '30', '2014-08-08 10:02:58', '2014-08-08 10:03:01'),
(611, '1407492555_1815.jpeg', '31', '2014-08-08 10:09:16', '2014-08-08 10:12:33'),
(612, '1407492556_1549.jpeg', '31', '2014-08-08 10:09:17', '2014-08-08 10:12:33'),
(613, '1407492558_1026.jpeg', '31', '2014-08-08 10:09:19', '2014-08-08 10:12:33'),
(614, '1407492558_1415.jpeg', '31', '2014-08-08 10:09:19', '2014-08-08 10:12:33'),
(615, '1407492560_1300.jpeg', '31', '2014-08-08 10:09:20', '2014-08-08 10:12:33'),
(616, '1407492561_1151.jpeg', '31', '2014-08-08 10:09:22', '2014-08-08 10:12:33'),
(617, '1407492561_1068.jpeg', '31', '2014-08-08 10:09:22', '2014-08-08 10:12:33'),
(618, '1407492564_1782.jpeg', '31', '2014-08-08 10:09:24', '2014-08-08 10:12:33'),
(619, '1407492580_1201.jpeg', '31', '2014-08-08 10:09:41', '2014-08-08 10:12:33'),
(620, '1407492583_1498.jpeg', '31', '2014-08-08 10:09:43', '2014-08-08 10:12:33'),
(621, '1407492583_1495.jpeg', '31', '2014-08-08 10:09:44', '2014-08-08 10:12:33'),
(622, '1407492585_1718.jpeg', '31', '2014-08-08 10:09:45', '2014-08-08 10:12:33'),
(623, '1407492585_1481.jpeg', '31', '2014-08-08 10:09:45', '2014-08-08 10:12:33'),
(624, '1407492586_1694.jpeg', '31', '2014-08-08 10:09:47', '2014-08-08 10:12:33'),
(627, '1407495980_1130.jpeg', '0', '2014-08-08 11:06:21', '2014-08-08 11:06:21'),
(629, '1407495983_1829.jpeg', '39', '2014-08-08 11:06:24', '2014-08-08 11:07:49'),
(630, '1407495998_1435.jpeg', '39', '2014-08-08 11:06:39', '2014-08-08 11:07:49'),
(631, '1407495998_1835.jpeg', '39', '2014-08-08 11:06:40', '2014-08-08 11:07:49'),
(632, '1407496001_1408.jpeg', '39', '2014-08-08 11:06:41', '2014-08-08 11:07:49'),
(633, '1407496001_1147.jpeg', '39', '2014-08-08 11:06:42', '2014-08-08 11:07:49'),
(634, '1407496048_1166.jpeg', '40', '2014-08-08 11:07:29', '2014-08-08 11:07:49'),
(635, '1407496058_1644.jpeg', '40', '2014-08-08 11:07:39', '2014-08-08 11:07:49'),
(636, '1407496059_1763.jpeg', '40', '2014-08-08 11:07:39', '2014-08-08 11:07:49'),
(637, '1407496060_1278.jpeg', '40', '2014-08-08 11:07:41', '2014-08-08 11:07:49'),
(638, '1407496061_1466.jpeg', '40', '2014-08-08 11:07:41', '2014-08-08 11:07:49'),
(639, '1407496062_1167.jpeg', '40', '2014-08-08 11:07:43', '2014-08-08 11:07:49'),
(640, '1407496062_1863.jpeg', '40', '2014-08-08 11:07:43', '2014-08-08 11:07:49'),
(641, '1407496064_1957.jpeg', '40', '2014-08-08 11:07:44', '2014-08-08 11:07:49'),
(642, '1407496063_1761.jpeg', '40', '2014-08-08 11:07:45', '2014-08-08 11:07:49'),
(643, '1407496066_1947.jpeg', '40', '2014-08-08 11:07:46', '2014-08-08 11:07:49'),
(644, '1407496206_1017.jpeg', '41', '2014-08-08 11:10:06', '2014-08-08 11:11:16'),
(645, '1407496213_1725.jpeg', '41', '2014-08-08 11:10:13', '2014-08-08 11:11:16'),
(646, '1407496217_1972.jpeg', '41', '2014-08-08 11:10:18', '2014-08-08 11:11:16'),
(647, '1407496219_1416.jpeg', '0', '2014-08-08 11:10:20', '2014-08-08 11:10:20'),
(648, '1407496228_1434.jpeg', '41', '2014-08-08 11:10:28', '2014-08-08 11:11:16'),
(649, '1407496239_1641.jpeg', '42', '2014-08-08 11:10:40', '2014-08-08 11:11:16'),
(650, '1407496256_1759.jpeg', '42', '2014-08-08 11:10:57', '2014-08-08 11:11:16'),
(651, '1407496257_1456.jpeg', '42', '2014-08-08 11:10:58', '2014-08-08 11:11:16'),
(653, '1407496259_1028.jpeg', '42', '2014-08-08 11:11:00', '2014-08-08 11:11:17'),
(654, '1407496259_1944.jpeg', '42', '2014-08-08 11:11:00', '2014-08-08 11:11:17'),
(655, '1407496261_1160.jpeg', '42', '2014-08-08 11:11:01', '2014-08-08 11:11:17'),
(656, '1407496261_1480.jpeg', '42', '2014-08-08 11:11:02', '2014-08-08 11:11:17'),
(657, '1407496262_1562.jpeg', '42', '2014-08-08 11:11:03', '2014-08-08 11:11:17'),
(658, '1407496262_1671.jpeg', '42', '2014-08-08 11:11:03', '2014-08-08 11:11:17'),
(659, '1407496264_1741.jpeg', '42', '2014-08-08 11:11:05', '2014-08-08 11:11:17'),
(660, '1407496264_1515.jpeg', '42', '2014-08-08 11:11:05', '2014-08-08 11:11:17'),
(661, '1407496272_1021.jpeg', '42', '2014-08-08 11:11:12', '2014-08-08 11:11:17'),
(662, '1407496514_1836.jpeg', '37', '2014-08-08 11:15:15', '2014-08-08 11:17:14'),
(663, '1407496545_1417.jpeg', '37', '2014-08-08 11:15:46', '2014-08-08 11:17:14'),
(664, '1407496545_1403.jpeg', '37', '2014-08-08 11:15:46', '2014-08-08 11:17:14'),
(665, '1407496546_1369.jpeg', '37', '2014-08-08 11:15:47', '2014-08-08 11:17:14'),
(666, '1407496547_1148.jpeg', '37', '2014-08-08 11:15:47', '2014-08-08 11:17:14'),
(667, '1407496549_1750.jpeg', '37', '2014-08-08 11:15:49', '2014-08-08 11:17:14'),
(668, '1407496550_1460.jpeg', '37', '2014-08-08 11:15:50', '2014-08-08 11:17:14'),
(669, '1407496551_1493.jpeg', '37', '2014-08-08 11:15:51', '2014-08-08 11:17:14'),
(670, '1407496551_1371.jpeg', '37', '2014-08-08 11:15:51', '2014-08-08 11:17:14'),
(671, '1407496552_1942.jpeg', '37', '2014-08-08 11:15:53', '2014-08-08 11:17:14'),
(672, '1407496553_1013.jpeg', '37', '2014-08-08 11:15:53', '2014-08-08 11:17:14'),
(673, '1407496554_1761.jpeg', '37', '2014-08-08 11:15:54', '2014-08-08 11:17:14'),
(674, '1407496601_1478.jpeg', '38', '2014-08-08 11:16:41', '2014-08-08 11:17:14'),
(675, '1407496613_1685.jpeg', '38', '2014-08-08 11:16:53', '2014-08-08 11:17:14'),
(676, '1407496613_1837.jpeg', '38', '2014-08-08 11:16:54', '2014-08-08 11:17:14'),
(677, '1407496615_1529.jpeg', '38', '2014-08-08 11:16:55', '2014-08-08 11:17:14'),
(678, '1407496615_1151.jpeg', '38', '2014-08-08 11:16:55', '2014-08-08 11:17:14'),
(679, '1407496618_1531.jpeg', '38', '2014-08-08 11:16:59', '2014-08-08 11:17:14'),
(680, '1407496618_1374.jpeg', '38', '2014-08-08 11:16:59', '2014-08-08 11:17:14'),
(681, '1407496622_1848.jpeg', '38', '2014-08-08 11:17:02', '2014-08-08 11:17:14'),
(682, '1407496624_1312.jpeg', '38', '2014-08-08 11:17:04', '2014-08-08 11:17:14'),
(683, '1407496625_1672.jpeg', '38', '2014-08-08 11:17:05', '2014-08-08 11:17:14'),
(684, '1407496626_1298.jpeg', '38', '2014-08-08 11:17:07', '2014-08-08 11:17:14'),
(685, '1407496627_1768.jpeg', '38', '2014-08-08 11:17:07', '2014-08-08 11:17:14'),
(686, '1407496629_1294.jpeg', '38', '2014-08-08 11:17:10', '2014-08-08 11:17:14'),
(687, '1407496629_1181.jpeg', '38', '2014-08-08 11:17:10', '2014-08-08 11:17:14'),
(688, '1407496631_1035.jpeg', '38', '2014-08-08 11:17:11', '2014-08-08 11:17:14'),
(689, '1407496984_1287.jpg', '0', '2014-08-08 11:23:05', '2014-08-08 11:23:05'),
(690, '1407496999_1578.jpg', '0', '2014-08-08 11:23:19', '2014-08-08 11:23:19'),
(691, '1407497012_1979.jpg', '0', '2014-08-08 11:23:33', '2014-08-08 11:23:33'),
(692, '1407497026_1594.jpg', '0', '2014-08-08 11:23:47', '2014-08-08 11:23:47'),
(693, '1407497041_1136.jpg', '0', '2014-08-08 11:24:01', '2014-08-08 11:24:01'),
(694, '1407497052_1235.jpg', '0', '2014-08-08 11:24:13', '2014-08-08 11:24:13'),
(695, '1407497291_1603.jpg', '0', '2014-08-08 11:28:12', '2014-08-08 11:28:12'),
(696, '1407497336_1276.jpg', '0', '2014-08-08 11:28:57', '2014-08-08 11:28:57'),
(697, '1407497420_1904.jpg', '0', '2014-08-08 11:30:20', '2014-08-08 11:30:20'),
(698, '1407497451_1499.jpg', '0', '2014-08-08 11:30:51', '2014-08-08 11:30:51'),
(699, '1407497488_1389.jpg', '0', '2014-08-08 11:31:29', '2014-08-08 11:31:29'),
(700, '1407497499_1106.jpg', '0', '2014-08-08 11:31:39', '2014-08-08 11:31:39'),
(701, '1407497671_1897.jpg', '0', '2014-08-08 11:34:31', '2014-08-08 11:34:31'),
(702, '1407497681_1582.jpg', '0', '2014-08-08 11:34:42', '2014-08-08 11:34:42'),
(703, '1407497694_1265.jpg', '0', '2014-08-08 11:34:54', '2014-08-08 11:34:54'),
(704, '1407497722_1874.jpg', '0', '2014-08-08 11:35:22', '2014-08-08 11:35:22'),
(707, '1407497797_1073.jpg', '0', '2014-08-08 11:36:37', '2014-08-08 11:36:37'),
(708, '1407498019_1758.jpg', '0', '2014-08-08 11:40:20', '2014-08-08 11:40:20'),
(709, '1407498051_1324.jpg', '0', '2014-08-08 11:40:52', '2014-08-08 11:40:52'),
(710, '1407499073_1395.jpg', '0', '2014-08-08 11:57:54', '2014-08-08 11:57:54'),
(713, '1407499136_1566.jpg', '0', '2014-08-08 11:58:56', '2014-08-08 11:58:56'),
(714, '1407499173_1843.jpg', '0', '2014-08-08 11:59:33', '2014-08-08 11:59:33'),
(715, '1407499184_1744.jpg', '0', '2014-08-08 11:59:45', '2014-08-08 11:59:45'),
(716, '1407499198_1725.jpg', '0', '2014-08-08 11:59:58', '2014-08-08 11:59:58'),
(717, '1407499215_1495.jpg', '0', '2014-08-08 12:00:15', '2014-08-08 12:00:15'),
(718, '1407499348_1867.jpg', '0', '2014-08-08 12:02:29', '2014-08-08 12:02:29'),
(719, '1407499358_1503.jpg', '0', '2014-08-08 12:02:38', '2014-08-08 12:02:38'),
(720, '1407499368_1468.jpg', '0', '2014-08-08 12:02:48', '2014-08-08 12:02:48'),
(721, '1407499410_1747.jpg', '0', '2014-08-08 12:03:30', '2014-08-08 12:03:30'),
(722, '1407499426_1996.jpg', '0', '2014-08-08 12:03:47', '2014-08-08 12:03:47'),
(723, '1407499439_1819.jpg', '0', '2014-08-08 12:04:00', '2014-08-08 12:04:00'),
(724, '1407499453_1689.jpg', '0', '2014-08-08 12:04:14', '2014-08-08 12:04:14'),
(725, '1407499481_1573.jpg', '0', '2014-08-08 12:04:41', '2014-08-08 12:04:41'),
(726, '1407499816_1623.jpeg', '0', '2014-08-08 12:10:16', '2014-08-08 12:10:16'),
(727, '1407499827_1292.jpeg', '0', '2014-08-08 12:10:27', '2014-08-08 12:10:27'),
(728, '1407499855_1910.jpeg', '0', '2014-08-08 12:10:55', '2014-08-08 12:10:55'),
(729, '1407499864_1590.jpeg', '0', '2014-08-08 12:11:04', '2014-08-08 12:11:04'),
(730, '1407499874_1983.jpeg', '0', '2014-08-08 12:11:14', '2014-08-08 12:11:14'),
(732, '1407499893_1747.jpeg', '0', '2014-08-08 12:11:33', '2014-08-08 12:11:33'),
(733, '1407500092_1989.jpeg', '0', '2014-08-08 12:14:52', '2014-08-08 12:14:52'),
(734, '1407500110_1899.jpeg', '0', '2014-08-08 12:15:11', '2014-08-08 12:15:11'),
(735, '1407500121_1571.jpeg', '0', '2014-08-08 12:15:22', '2014-08-08 12:15:22'),
(736, '1407500139_1866.jpeg', '0', '2014-08-08 12:15:39', '2014-08-08 12:15:39'),
(737, '1407500159_1479.jpeg', '0', '2014-08-08 12:15:59', '2014-08-08 12:15:59'),
(738, '1407500183_1579.jpeg', '0', '2014-08-08 12:16:23', '2014-08-08 12:16:23'),
(739, '1407500196_1735.jpeg', '0', '2014-08-08 12:16:36', '2014-08-08 12:16:36'),
(740, '1407743744_1483.jpeg', '0', '2014-08-11 07:55:45', '2014-08-11 07:55:45'),
(741, '1407743752_1159.jpeg', '0', '2014-08-11 07:55:53', '2014-08-11 07:55:53'),
(742, '1407743753_1427.jpeg', '0', '2014-08-11 07:55:53', '2014-08-11 07:55:53'),
(743, '1407743754_1120.jpeg', '0', '2014-08-11 07:55:54', '2014-08-11 07:55:54'),
(744, '1407743758_1133.jpeg', '0', '2014-08-11 07:55:59', '2014-08-11 07:55:59'),
(745, '1407743760_1815.jpeg', '0', '2014-08-11 07:56:01', '2014-08-11 07:56:01'),
(746, '1407743791_1222.jpeg', '0', '2014-08-11 07:56:32', '2014-08-11 07:56:32'),
(751, '1407743810_1385.jpeg', '0', '2014-08-11 07:56:51', '2014-08-11 07:56:51'),
(752, '1407743810_1042.jpeg', '0', '2014-08-11 07:56:51', '2014-08-11 07:56:51'),
(753, '1407743813_1036.jpeg', '0', '2014-08-11 07:56:54', '2014-08-11 07:56:54'),
(754, '1407743813_1423.jpeg', '0', '2014-08-11 07:56:54', '2014-08-11 07:56:54'),
(755, '1407743815_1913.jpeg', '0', '2014-08-11 07:56:56', '2014-08-11 07:56:56'),
(756, '1407743816_1488.jpeg', '0', '2014-08-11 07:56:57', '2014-08-11 07:56:57'),
(757, '1407743817_1858.jpeg', '0', '2014-08-11 07:56:58', '2014-08-11 07:56:58'),
(758, '1407743818_1159.jpeg', '0', '2014-08-11 07:56:58', '2014-08-11 07:56:58'),
(759, '1407743818_1624.jpeg', '0', '2014-08-11 07:56:59', '2014-08-11 07:56:59'),
(760, '1407743821_1165.jpeg', '0', '2014-08-11 07:57:01', '2014-08-11 07:57:01'),
(761, '1407743827_1872.jpeg', '0', '2014-08-11 07:57:07', '2014-08-11 07:57:07'),
(762, '1407743827_1527.jpeg', '0', '2014-08-11 07:57:08', '2014-08-11 07:57:08'),
(763, '1407743830_1261.jpeg', '0', '2014-08-11 07:57:11', '2014-08-11 07:57:11'),
(764, '1407743830_1926.jpeg', '0', '2014-08-11 07:57:11', '2014-08-11 07:57:11'),
(765, '1407743922_1412.jpeg', '44', '2014-08-11 07:58:42', '2014-08-11 07:59:39'),
(766, '1407743930_1646.jpeg', '44', '2014-08-11 07:58:51', '2014-08-11 07:59:39'),
(767, '1407743930_1753.jpeg', '44', '2014-08-11 07:58:51', '2014-08-11 07:59:39'),
(768, '1407743932_1196.jpeg', '44', '2014-08-11 07:58:53', '2014-08-11 07:59:39'),
(769, '1407743932_1420.jpeg', '44', '2014-08-11 07:58:53', '2014-08-11 07:59:39'),
(770, '1407743933_1633.jpeg', '44', '2014-08-11 07:58:54', '2014-08-11 07:59:39'),
(771, '1407743933_1896.jpeg', '44', '2014-08-11 07:58:54', '2014-08-11 07:59:39'),
(772, '1407743934_1257.jpeg', '44', '2014-08-11 07:58:55', '2014-08-11 07:59:39'),
(773, '1407743934_1098.jpeg', '44', '2014-08-11 07:58:55', '2014-08-11 07:59:39'),
(774, '1407743937_1942.jpeg', '44', '2014-08-11 07:58:58', '2014-08-11 07:59:39'),
(775, '1407743938_1280.jpeg', '44', '2014-08-11 07:58:58', '2014-08-11 07:59:40'),
(776, '1407743940_1446.jpeg', '44', '2014-08-11 07:59:01', '2014-08-11 07:59:40'),
(777, '1407743940_1540.jpeg', '44', '2014-08-11 07:59:01', '2014-08-11 07:59:40'),
(778, '1407743942_1024.jpeg', '44', '2014-08-11 07:59:03', '2014-08-11 07:59:40'),
(779, '1407743942_1014.jpeg', '44', '2014-08-11 07:59:03', '2014-08-11 07:59:40'),
(780, '1407743961_1597.jpeg', '43', '2014-08-11 07:59:22', '2014-08-11 07:59:39'),
(781, '1407743967_1731.jpeg', '43', '2014-08-11 07:59:28', '2014-08-11 07:59:39'),
(782, '1407743967_1617.jpeg', '43', '2014-08-11 07:59:28', '2014-08-11 07:59:39'),
(783, '1407743968_1993.jpeg', '43', '2014-08-11 07:59:29', '2014-08-11 07:59:39'),
(784, '1407743969_1929.jpeg', '43', '2014-08-11 07:59:29', '2014-08-11 07:59:39'),
(785, '1407743970_1559.jpeg', '43', '2014-08-11 07:59:31', '2014-08-11 07:59:39'),
(786, '1407747584_1967.jpeg', '45', '2014-08-11 08:59:44', '2014-08-11 09:00:59'),
(787, '1407747590_1382.jpeg', '45', '2014-08-11 08:59:51', '2014-08-11 09:00:59'),
(788, '1407747591_1898.jpeg', '45', '2014-08-11 08:59:51', '2014-08-11 09:00:59'),
(789, '1407747593_1578.jpeg', '45', '2014-08-11 08:59:54', '2014-08-11 09:00:59'),
(790, '1407747594_1687.jpeg', '45', '2014-08-11 08:59:55', '2014-08-11 09:00:59'),
(791, '1407747596_1640.jpeg', '45', '2014-08-11 08:59:57', '2014-08-11 09:00:59'),
(792, '1407747597_1211.jpeg', '45', '2014-08-11 08:59:57', '2014-08-11 09:00:59'),
(793, '1407747598_1651.jpeg', '45', '2014-08-11 08:59:58', '2014-08-11 09:00:59'),
(794, '1407747600_1273.jpeg', '45', '2014-08-11 09:00:01', '2014-08-11 09:00:59'),
(795, '1407747600_1083.jpeg', '45', '2014-08-11 09:00:01', '2014-08-11 09:00:59'),
(796, '1407747602_1629.jpeg', '45', '2014-08-11 09:00:02', '2014-08-11 09:00:59'),
(797, '1407747618_1152.jpeg', '46', '2014-08-11 09:00:18', '2014-08-11 09:00:59'),
(806, '1407747628_1777.jpeg', '46', '2014-08-11 09:00:28', '2014-08-11 09:00:59'),
(807, '1407747629_1316.jpeg', '46', '2014-08-11 09:00:29', '2014-08-11 09:00:59'),
(808, '1407747629_1248.jpeg', '46', '2014-08-11 09:00:29', '2014-08-11 09:00:59'),
(809, '1407747630_1302.jpeg', '46', '2014-08-11 09:00:30', '2014-08-11 09:00:59'),
(810, '1407747630_1341.jpeg', '46', '2014-08-11 09:00:31', '2014-08-11 09:00:59'),
(812, '1407747632_1815.jpeg', '46', '2014-08-11 09:00:33', '2014-08-11 09:00:59'),
(813, '1407747634_1422.jpeg', '46', '2014-08-11 09:00:35', '2014-08-11 09:00:59'),
(814, '1407747634_1160.jpeg', '46', '2014-08-11 09:00:35', '2014-08-11 09:00:59'),
(815, '1407747636_1342.jpeg', '46', '2014-08-11 09:00:37', '2014-08-11 09:00:59'),
(816, '1407747637_1416.jpeg', '46', '2014-08-11 09:00:37', '2014-08-11 09:00:59'),
(817, '1407747649_1578.jpeg', '46', '2014-08-11 09:00:50', '2014-08-11 09:00:59'),
(818, '1407747649_1973.jpeg', '46', '2014-08-11 09:00:50', '2014-08-11 09:00:59'),
(819, '1407747650_1104.jpeg', '46', '2014-08-11 09:00:51', '2014-08-11 09:00:59'),
(820, '1407747651_1355.jpeg', '46', '2014-08-11 09:00:52', '2014-08-11 09:00:59'),
(821, '1407747652_1162.jpeg', '46', '2014-08-11 09:00:53', '2014-08-11 09:00:59'),
(822, '1407747653_1416.jpeg', '46', '2014-08-11 09:00:53', '2014-08-11 09:00:59'),
(823, '1407747653_1808.jpeg', '46', '2014-08-11 09:00:54', '2014-08-11 09:00:59'),
(824, '1407747654_1507.jpeg', '46', '2014-08-11 09:00:55', '2014-08-11 09:00:59'),
(825, '1407753510_1189.jpg', '47', '2014-08-11 10:38:30', '2014-08-11 10:40:02'),
(826, '1407753517_1325.jpg', '47', '2014-08-11 10:38:37', '2014-08-11 10:40:02'),
(827, '1407753521_1779.jpg', '47', '2014-08-11 10:38:41', '2014-08-11 10:40:02'),
(828, '1407753523_1219.jpg', '47', '2014-08-11 10:38:44', '2014-08-11 10:40:02'),
(829, '1407753525_1037.jpg', '47', '2014-08-11 10:38:46', '2014-08-11 10:40:02'),
(830, '1407753528_1461.jpg', '47', '2014-08-11 10:38:49', '2014-08-11 10:40:02'),
(831, '1407753528_1102.jpg', '47', '2014-08-11 10:38:49', '2014-08-11 10:40:02'),
(832, '1407753569_1977.jpeg', '48', '2014-08-11 10:39:30', '2014-08-11 10:40:02'),
(833, '1407753582_1857.jpeg', '48', '2014-08-11 10:39:43', '2014-08-11 10:40:02'),
(834, '1407753583_1483.jpeg', '48', '2014-08-11 10:39:43', '2014-08-11 10:40:02'),
(835, '1407753584_1852.jpeg', '48', '2014-08-11 10:39:45', '2014-08-11 10:40:02'),
(836, '1407753584_1118.jpeg', '48', '2014-08-11 10:39:45', '2014-08-11 10:40:02'),
(837, '1407753586_1921.jpeg', '48', '2014-08-11 10:39:47', '2014-08-11 10:40:02'),
(838, '1407753587_1634.jpeg', '48', '2014-08-11 10:39:47', '2014-08-11 10:40:02'),
(839, '1407753588_1404.jpeg', '48', '2014-08-11 10:39:48', '2014-08-11 10:40:02'),
(840, '1407753589_1658.jpeg', '48', '2014-08-11 10:39:50', '2014-08-11 10:40:02'),
(841, '1407753590_1464.jpeg', '48', '2014-08-11 10:39:50', '2014-08-11 10:40:02'),
(842, '1407753591_1535.jpeg', '48', '2014-08-11 10:39:52', '2014-08-11 10:40:02'),
(843, '1407753591_1958.jpeg', '48', '2014-08-11 10:39:52', '2014-08-11 10:40:02'),
(844, '1407753593_1351.jpeg', '48', '2014-08-11 10:39:54', '2014-08-11 10:40:02'),
(845, '1407753593_1659.jpeg', '48', '2014-08-11 10:39:54', '2014-08-11 10:40:02'),
(846, '1407753595_1069.jpeg', '48', '2014-08-11 10:39:56', '2014-08-11 10:40:02'),
(847, '1407753595_1330.jpeg', '48', '2014-08-11 10:39:56', '2014-08-11 10:40:02'),
(848, '1407754872_1721.jpeg', '49', '2014-08-11 11:01:13', '2014-08-11 11:02:11'),
(849, '1407754880_1759.jpeg', '49', '2014-08-11 11:01:21', '2014-08-11 11:02:11'),
(850, '1407754881_1749.jpeg', '49', '2014-08-11 11:01:22', '2014-08-11 11:02:11'),
(851, '1407754883_1868.jpeg', '49', '2014-08-11 11:01:23', '2014-08-11 11:02:11'),
(852, '1407754885_1907.jpeg', '49', '2014-08-11 11:01:26', '2014-08-11 11:02:11'),
(853, '1407754885_1145.jpeg', '49', '2014-08-11 11:01:26', '2014-08-11 11:02:11'),
(854, '1407754887_1418.jpeg', '49', '2014-08-11 11:01:28', '2014-08-11 11:02:11'),
(855, '1407754887_1889.jpeg', '49', '2014-08-11 11:01:28', '2014-08-11 11:02:11'),
(856, '1407754889_1135.jpeg', '49', '2014-08-11 11:01:30', '2014-08-11 11:02:11'),
(857, '1407754889_1012.jpeg', '49', '2014-08-11 11:01:30', '2014-08-11 11:02:11'),
(858, '1407754890_1345.jpeg', '49', '2014-08-11 11:01:31', '2014-08-11 11:02:11'),
(859, '1407754891_1689.jpeg', '49', '2014-08-11 11:01:32', '2014-08-11 11:02:11'),
(860, '1407754892_1325.jpeg', '49', '2014-08-11 11:01:32', '2014-08-11 11:02:11'),
(861, '1407754892_1247.jpeg', '49', '2014-08-11 11:01:33', '2014-08-11 11:02:11'),
(862, '1407754893_1879.jpeg', '49', '2014-08-11 11:01:33', '2014-08-11 11:02:11'),
(863, '1407754894_1877.jpeg', '49', '2014-08-11 11:01:34', '2014-08-11 11:02:11'),
(864, '1407754901_1738.jpeg', '50', '2014-08-11 11:01:42', '2014-08-11 11:02:11'),
(865, '1407754915_1588.jpeg', '50', '2014-08-11 11:01:56', '2014-08-11 11:02:11'),
(866, '1407754916_1744.jpeg', '50', '2014-08-11 11:01:56', '2014-08-11 11:02:11'),
(867, '1407754917_1270.jpeg', '50', '2014-08-11 11:01:58', '2014-08-11 11:02:11'),
(868, '1407754917_1614.jpeg', '50', '2014-08-11 11:01:58', '2014-08-11 11:02:11'),
(869, '1407754918_1219.jpeg', '50', '2014-08-11 11:01:59', '2014-08-11 11:02:11'),
(870, '1407754919_1553.jpeg', '50', '2014-08-11 11:01:59', '2014-08-11 11:02:11'),
(871, '1407754919_1772.jpeg', '50', '2014-08-11 11:02:00', '2014-08-11 11:02:11'),
(872, '1407754920_1769.jpeg', '50', '2014-08-11 11:02:00', '2014-08-11 11:02:11'),
(873, '1407754921_1564.jpeg', '50', '2014-08-11 11:02:01', '2014-08-11 11:02:11'),
(874, '1407754921_1863.jpeg', '50', '2014-08-11 11:02:01', '2014-08-11 11:02:11'),
(875, '1407754922_1579.jpeg', '50', '2014-08-11 11:02:02', '2014-08-11 11:02:11'),
(876, '1407754922_1807.jpeg', '50', '2014-08-11 11:02:03', '2014-08-11 11:02:11'),
(877, '1407754923_1400.jpeg', '50', '2014-08-11 11:02:04', '2014-08-11 11:02:11'),
(878, '1407754924_1855.jpeg', '50', '2014-08-11 11:02:04', '2014-08-11 11:02:11'),
(879, '1407754925_1873.jpeg', '50', '2014-08-11 11:02:06', '2014-08-11 11:02:11'),
(881, '1408353879_1720.jpg', '29', '2014-08-18 09:24:40', '2014-08-18 09:24:42');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `publication` tinyint(1) unsigned DEFAULT '1',
  `brochure` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `image_menu_id` int(10) unsigned DEFAULT NULL,
  `gallery_color_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_publication_index` (`publication`),
  KEY `image_menu_id` (`image_menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `category_id`, `publication`, `brochure`, `in_menu`, `image_id`, `image_menu_id`, `gallery_color_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '/uploads/1407268018_1255.pdf', 1, 190, 59, 0, 29, '2014-07-31 12:08:41', '2014-08-18 09:24:42'),
(2, 1, 1, '/uploads/1407500863_1667.pdf', 1, 154, 61, 0, 23, '2014-08-01 08:50:25', '2014-08-11 13:57:44'),
(3, 1, 1, '/uploads/1407502500_1373.pdf', NULL, 200, 62, 0, 25, '2014-08-01 09:09:02', '2014-08-11 14:20:55'),
(4, 1, 1, '/uploads/1407500720_1069.pdf', 1, 0, 63, 0, 26, '2014-08-01 09:20:12', '2014-08-12 06:42:16'),
(5, 2, 1, '/uploads/1407501662_1722.pdf', 1, 0, 64, 0, 36, '2014-08-01 09:26:55', '2014-08-12 08:03:07'),
(6, 2, 1, '/uploads/1407501825_1491.pdf', 1, 0, 65, 0, 34, '2014-08-01 09:37:33', '2014-08-08 12:43:45'),
(7, 2, 1, '/uploads/1407501942_1451.pdf', 1, 0, 66, 0, 18, '2014-08-01 10:10:34', '2014-08-08 12:45:42'),
(8, 2, 1, '/uploads/1407502186_1245.pdf', 1, 192, 67, 0, 17, '2014-08-01 10:17:05', '2014-08-08 12:49:46');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessories`
--

DROP TABLE IF EXISTS `products_accessories`;
CREATE TABLE IF NOT EXISTS `products_accessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `category_id` int(10) unsigned DEFAULT '0',
  `accessibility_id` int(10) unsigned DEFAULT '0',
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=152 ;

--
-- Дамп данных таблицы `products_accessories`
--

INSERT INTO `products_accessories` (`id`, `title`, `price`, `description`, `category_id`, `accessibility_id`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 'Резиновые коврики', '0', '<p>\n	 <span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 153, 1, '2014-07-31 13:32:52', '2014-08-05 20:29:05'),
(2, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 7, 1, '2014-07-31 13:33:45', '2014-07-31 13:33:45'),
(3, 'Полиуретановые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное полиуретановые покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 8, 1, '2014-07-31 13:34:20', '2014-07-31 13:34:20'),
(4, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 9, 1, '2014-07-31 13:34:42', '2014-07-31 13:34:42'),
(5, 'Спортивная радиаторная решетка', '0', '<p>\n	<span style="background-color: initial;">Стильная радиаторная решетка придает спортивный характер Вашему автомобилю.</span>\n</p>', 2, 1, 10, 1, '2014-07-31 13:35:05', '2014-08-07 12:10:27'),
(6, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид. На брызговиках имеются рельефные контуры, благодаря которым они точно устанавливаются в колесные арки.</span>\n</p>', 2, 1, 11, 1, '2014-07-31 13:36:52', '2014-07-31 13:36:52'),
(7, 'Спойлер на крышку багажника', '0', '<p>\n	<span style="background-color: initial;">Стильный спойлер придает агрессивный вид Вашему Infiniti.</span>\n</p>', 2, 1, 12, 1, '2014-07-31 13:37:17', '2014-07-31 13:37:17'),
(8, 'Внешняя подсветка порогов', '0', '<p>\n	<span style="background-color: initial;">Отлично подчеркивает внешний вид спортивного автомобиля. Помогает при парковке в темное время суток.</span>\n</p>', 2, 1, 13, 1, '2014-07-31 13:38:32', '2014-07-31 13:38:33'),
(9, 'Легкосплавный диск R17', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti.</span>\n</p>', 2, 1, 14, 1, '2014-07-31 13:38:57', '2014-07-31 13:38:57'),
(10, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 15, 1, '2014-07-31 13:39:21', '2014-07-31 13:39:21'),
(11, 'Багажник на крышу', '0', '<p>\n	 <span style="background-color: initial;">Специально разработанная система для крепления багажника на крыше автомобиля идеально вписывается в экстерьер и гармонично сочетается с формой крыши. Устанавливается с помощью надежных крепежей. Грузоподъемность 75кг.</span>\n</p>', 2, 1, 16, 1, '2014-07-31 13:40:17', '2014-08-07 12:17:21'),
(18, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы пластикового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 318, 1, '2014-08-07 10:43:40', '2014-08-07 10:43:40'),
(19, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 319, 2, '2014-08-07 10:46:05', '2014-08-07 10:46:05'),
(20, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 320, 2, '2014-08-07 10:47:30', '2014-08-07 10:47:30'),
(21, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 321, 2, '2014-08-07 10:48:09', '2014-08-07 10:48:09'),
(22, 'Велюровый коврик в багажник', '0', '<p>\n	 <span style="background-color: initial;">Придает багажнику Infiniti Q60 Coupe опрятный вид, защищает от грязи, долговечен. Изготовлен из скрученных нейлоновых нитей с окантовкой из нейлона. Нижняя сторона покрыта нескользящей влагостойкой вулканизированной резиной</span>\n</p>', 4, 1, 322, 2, '2014-08-07 10:48:47', '2014-08-07 10:49:03'),
(23, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Оригинальный аксессуар Infiniti. Высокий борт и специальные выступы пластикового поддона защищает багажник вашего Q60 Coupe от грязи. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 323, 2, '2014-08-07 10:49:33', '2014-08-07 10:49:33'),
(24, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 324, 2, '2014-08-07 10:50:02', '2014-08-07 10:50:02'),
(25, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 325, 2, '2014-08-07 10:50:36', '2014-08-07 10:50:36'),
(26, 'Спутниковая поисковая система ITS', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система, адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все функции ITS (Infiniti Tracking System), пожалуйста, уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 326, 2, '2014-08-07 10:51:18', '2014-08-07 10:51:18'),
(27, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 327, 2, '2014-08-07 10:52:14', '2014-08-07 10:52:14'),
(28, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид. На брызговиках имеются рельефные контуры, благодаря которым они точно устанавливаются в колесные арки.</span>\n</p>', 2, 1, 328, 2, '2014-08-07 10:52:46', '2014-08-07 10:52:46'),
(29, 'Легкосплавные диски R19', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид Вашему автомобилю.</span>\n</p>', 2, 1, 329, 2, '2014-08-07 10:53:21', '2014-08-07 10:53:21'),
(30, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 330, 2, '2014-08-07 10:53:54', '2014-08-07 10:53:54'),
(31, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 331, 3, '2014-08-07 10:59:10', '2014-08-07 10:59:10'),
(32, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 332, 3, '2014-08-07 10:59:33', '2014-08-07 10:59:33'),
(33, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 333, 3, '2014-08-07 10:59:55', '2014-08-07 10:59:55'),
(34, 'Легкосплавные диски R19', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид Вашему Infiniti Q60 Cabrio.</span>\n</p>', 2, 1, 334, 3, '2014-08-07 11:00:22', '2014-08-07 11:00:22'),
(35, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид. На брызговиках имеются рельефные контуры, благодаря которым они точно устанавливаются в колесные арки.</span>\n</p>', 2, 1, 335, 3, '2014-08-07 11:00:42', '2014-08-07 11:00:42'),
(36, 'Спойлер на крышку багажника', '0', '<p>\n	<span style="background-color: initial;">Стильный спойлер придает агрессивный вид Вашему Infiniti Q60 Cabrio.</span>\n</p>', 2, 1, 336, 3, '2014-08-07 11:01:10', '2014-08-07 11:01:10'),
(37, 'Велюровый коврик в багажник', '0', '<p>\n	<span style="background-color: initial;">Придает багажнику Infiniti Q60 Cabrio опрятный вид, защищает от грязи, долговечен. Изготовлен из скрученных нейлоновых нитей с окантовкой из нейлона. Нижняя сторона покрыта нескользящей влагостойкой вулканизированной резиной.</span>\n</p>', 4, 1, 337, 3, '2014-08-07 11:01:49', '2014-08-07 11:01:49'),
(38, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Оригинальный аксессуар Infiniti. Высокий борт и специальные выступы пластикового поддона защищает багажник вашего Q60 Cabrio от грязи. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 338, 3, '2014-08-07 11:02:14', '2014-08-07 11:02:14'),
(39, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 339, 3, '2014-08-07 11:02:42', '2014-08-07 11:02:42'),
(40, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 340, 3, '2014-08-07 11:03:16', '2014-08-07 11:03:16'),
(41, 'Спутниковая поисковая система ITS', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система, адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все функции ITS (Infiniti Tracking System), пожалуйста, уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 341, 3, '2014-08-07 11:03:37', '2014-08-07 11:03:37'),
(42, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 342, 3, '2014-08-07 11:04:00', '2014-08-07 11:04:00'),
(43, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 343, 3, '2014-08-07 11:04:24', '2014-08-07 11:04:24'),
(44, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 344, 4, '2014-08-07 11:07:15', '2014-08-07 11:07:15'),
(45, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 345, 4, '2014-08-07 11:08:57', '2014-08-07 11:08:57'),
(46, 'Полиуретановые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное полиуретановые покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 346, 4, '2014-08-07 11:09:18', '2014-08-07 11:09:18'),
(47, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 347, 4, '2014-08-07 11:09:45', '2014-08-07 11:09:45'),
(48, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид. На брызговиках имеются рельефные контуры, благодаря которым они точно устанавливаются в колесные арки.</span>\n</p>', 2, 1, 348, 4, '2014-08-07 11:10:46', '2014-08-07 11:10:46'),
(49, 'Спойлер на крышку багажника', '0', '<p>\n	<span style="background-color: initial;">Стильный спойлер придает агрессивный вид Вашему Infiniti Q70.</span>\n</p>', 2, 1, 350, 4, '2014-08-07 11:11:42', '2014-08-07 11:11:42'),
(50, 'Багажник на крышу', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система для крепления багажника на крыше автомобиля идеально вписывается в экстерьер и гармонично сочетается с формой крыши. Устанавливается с помощью надежных крепежей. Грузоподъемность 75кг</span>\n</p>', 2, 1, 351, 4, '2014-08-07 11:12:13', '2014-08-07 11:12:13'),
(51, 'Легкосплавный диск R18', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti Q70.</span>\n</p>', 2, 1, 352, 4, '2014-08-07 11:12:42', '2014-08-07 11:12:42'),
(52, 'Легкосплавный диск R20', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti Q70.</span>\n</p>', 2, 1, 353, 4, '2014-08-07 11:13:08', '2014-08-07 11:13:08'),
(53, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 354, 4, '2014-08-07 11:13:33', '2014-08-07 11:13:33'),
(54, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Оригинальный аксессуар Infiniti. Высокий борт и специальные выступы пластикового поддона защищает багажник вашего Q70 от грязи. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 355, 4, '2014-08-07 11:14:08', '2014-08-07 11:14:08'),
(55, 'Мягкий коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное велюровое покрытие багажника, разработанное специально для автомобилей Infiniti.</span>\n</p>', 4, 1, 356, 4, '2014-08-07 11:14:31', '2014-08-07 11:14:31'),
(56, 'Полиуретановый коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы полиуретанового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 357, 4, '2014-08-07 11:14:58', '2014-08-07 11:14:58'),
(57, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 358, 4, '2014-08-07 11:15:29', '2014-08-07 11:15:29'),
(58, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 359, 4, '2014-08-07 11:16:09', '2014-08-07 11:16:09'),
(59, 'Спутниковая поисковая система ITS', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система, адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все функции ITS (Infiniti Tracking System), пожалуйста, уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 360, 4, '2014-08-07 11:16:37', '2014-08-07 11:16:37'),
(60, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 361, 4, '2014-08-07 11:16:56', '2014-08-07 11:16:56'),
(61, 'Тягово-сцепное устройство', '0', '<p>\n	<span style="background-color: initial;">Съемное тягово-сцепное устройство грузоподъемностью до 3 тонн.</span>\n</p>', 6, 1, 362, 4, '2014-08-07 11:17:20', '2014-08-07 11:17:20'),
(62, 'Проводка для тягово-сцепного устройства', '0', '<p>\n	<span style="background-color: initial;">Комплект дополнительной проводки с 13 -штырьковым разъемом.</span>\n</p>', 6, 1, 363, 4, '2014-08-07 11:17:43', '2014-08-07 11:17:43'),
(63, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 364, 4, '2014-08-07 11:18:17', '2014-08-07 11:18:17'),
(64, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 365, 5, '2014-08-07 11:22:30', '2014-08-07 11:22:30'),
(65, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 366, 5, '2014-08-07 11:22:51', '2014-08-07 11:22:51'),
(66, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 367, 5, '2014-08-07 11:23:20', '2014-08-07 11:23:20'),
(67, 'Информационно-развлекательный центр', '0', '<p>\n	<span style="background-color: initial;">Встроенная в подголовники двухканальная видеосистема с семидюймовым экраном, LCD дисплеем с DVD плеером, регулируемым углом поворота, наушниками, подключенными через инфракрасный порт и дистанционным управлением. Мультимедийный плеер распознает все основные форматы записи, включая DVD, DVD±R, DVD±RW, HDCD, CD Digital Audio, CD TEXT, CD-Recordable, CD-Re-Writable, MP3 Playback (ID3 TAG), WMA, MPEG-4/Divx ASP (дополнительно). Система также имеет датчик света, дополнительный вход для игр и аудиовыход.</span>\n</p>', 1, 1, 368, 5, '2014-08-07 11:23:44', '2014-08-07 11:23:44'),
(68, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид. На брызговиках имеются рельефные контуры, благодаря которым они точно устанавливаются в колесные арки.</span>\n</p>', 2, 1, 369, 5, '2014-08-07 11:27:23', '2014-08-07 11:27:23'),
(69, 'Порог с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Отлично подчеркивает внешний вид спортивного полноприводного автомобиля. Помогает при парковке в темное время суток.</span>\n</p>', 2, 1, 370, 5, '2014-08-07 11:27:51', '2014-08-07 11:27:51'),
(70, 'Поперечины рейлингов', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система для крепления багажника на крыше автомобиля идеально вписывается в экстерьер и гармонично сочетается с формой крыши. Устанавливается с помощью надежных крепежей на рейлингах. Грузоподъемность 75кг</span>\n</p>', 2, 1, 371, 5, '2014-08-07 11:28:23', '2014-08-07 11:28:23'),
(71, 'Накладка заднего бампера', '0', '<p>\n	<span style="background-color: initial;">Стильная алюминиевая накладка защищает окрашенный бампер от царапин и ударов при погрузке вещей в багажник.</span>\n</p>', 2, 1, 372, 5, '2014-08-07 11:28:47', '2014-08-07 11:28:47'),
(72, 'Передние и задние декоративные накладки на бампер', '0', '<p>\n	<span style="background-color: initial;">Придают стилю автомобиля своеобразную динамику и защищают внутренние детали кузова от попадания камней с дорожного покрытия.</span>\n</p>', 2, 1, 373, 5, '2014-08-07 11:29:36', '2014-08-07 11:29:36'),
(73, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 374, 5, '2014-08-07 11:30:06', '2014-08-07 11:30:06'),
(74, 'Дефлектор капота', '0', '<p>\n	<span style="background-color: initial;">Данный аксессуар защищает капот от сколов при движении на больших скоростях.</span>\n</p>', 2, 1, 375, 5, '2014-08-07 11:31:11', '2014-08-07 11:31:11'),
(75, 'Легкосплавный диск R18', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti QX50.</span>\n</p>', 2, 1, 376, 5, '2014-08-07 11:31:43', '2014-08-07 11:31:43'),
(76, 'Спортивная радиаторная решетка', '0', '<p>\n	<span style="background-color: initial;">Придает спортивный характер Вашему автомобилю</span>\n</p>', 2, 1, 377, 5, '2014-08-07 11:32:03', '2014-08-07 11:32:03'),
(77, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 378, 5, '2014-08-07 11:32:29', '2014-08-07 11:32:29'),
(78, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы пластикового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 379, 5, '2014-08-07 11:33:14', '2014-08-07 11:33:14'),
(79, 'Мягкий коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное велюровое покрытие багажника, разработанное специально для автомобилей Infiniti.</span>\n</p>', 4, 1, 380, 5, '2014-08-07 11:33:55', '2014-08-07 11:33:55'),
(80, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 381, 5, '2014-08-07 11:34:34', '2014-08-07 11:34:34'),
(81, 'Спутниковая поисковая система ITS', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система, адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все функции ITS (Infiniti Tracking System), пожалуйста, уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 382, 5, '2014-08-07 11:35:04', '2014-08-07 11:35:04'),
(82, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 383, 5, '2014-08-07 11:35:30', '2014-08-07 11:35:30'),
(83, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 384, 5, '2014-08-07 11:35:55', '2014-08-07 11:35:55'),
(84, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 385, 6, '2014-08-07 11:38:51', '2014-08-07 11:38:51'),
(85, 'Подсветка для ног пассажиров', '0', '<p>\n	<span style="background-color: initial;">Подсветка для ног пассажиров, придаст уют салону и в темное время суток поможет пассажиру с комфортом сесть и выйти из вашего Infiniti.</span>\n</p>', 1, 1, 386, 6, '2014-08-07 11:39:15', '2014-08-07 11:39:15'),
(86, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 387, 6, '2014-08-07 11:39:44', '2014-08-07 11:39:44'),
(87, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 388, 6, '2014-08-07 11:40:11', '2014-08-07 11:40:11'),
(88, 'Полиуретановые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное полиуретановое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 389, 6, '2014-08-07 11:40:31', '2014-08-07 11:40:31'),
(89, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид.</span>\n</p>', 2, 1, 390, 6, '2014-08-07 11:46:30', '2014-08-07 11:46:30'),
(90, 'Продольные рейлинги', '0', '<p>\n	<span style="background-color: initial;">Стильный элемент крыши, они точно повторяют ее контуры, подчеркивая индивидуальность Infiniti QX60. Рейлинги крепятся с помощью надежных крепежей к элементам крыши и поставляются во всех цветовых решениях кузова. Они могут быть использованы для установки поперечин, с грузоподъемностью не более 75кг.</span>\n</p>', 2, 1, 391, 6, '2014-08-07 11:46:56', '2014-08-07 11:46:56'),
(91, 'Накладка заднего бампера', '0', '<p>\n	<span style="background-color: initial;">Стильная алюминиевая накладка защищает окрашенный бампер от царапин и ударов при погрузке вещей в багажник.</span>\n</p>', 2, 1, 392, 6, '2014-08-07 11:47:37', '2014-08-07 11:47:37'),
(92, 'Поперечины рейлингов', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система, которая идеально подходит к форме крыши и уменьшает шум от встречного ветра. Они крепится с помощью надежных крепежей на рейлингах. Грузоподъемность: 75кг</span>\n</p>', 2, 1, 393, 6, '2014-08-07 11:48:07', '2014-08-07 11:48:07'),
(93, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 394, 6, '2014-08-07 11:48:33', '2014-08-07 11:48:33'),
(94, 'Полиуретановый коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы полиуретанового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 395, 6, '2014-08-07 11:48:57', '2014-08-07 11:48:57'),
(95, 'Мягкий коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Придает багажнику опрятный вид, защищает от грязи. Это долговечный плотный коврик из скрученных нейлоновых нитей и с окантовкой из нейлона, нижняя сторона покрыта нескользящей влагостойкой вулканизированной резиной.</span>\n</p>', 4, 1, 396, 6, '2014-08-07 11:49:46', '2014-08-07 11:49:46'),
(96, 'Защитная шторка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 397, 6, '2014-08-07 11:50:11', '2014-08-07 11:50:11'),
(97, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 398, 6, '2014-08-07 11:54:33', '2014-08-07 11:54:33'),
(98, 'Органайзер в багажник', '0', '<p>\n	<span style="background-color: initial;">Оригинальный аксессуар Infiniti – специальный ящик в багажник, позволяющий организовывать пространство в багажнике вашего автомобиля.</span>\n</p>', 4, 1, 399, 6, '2014-08-07 11:55:33', '2014-08-07 11:55:33'),
(99, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 400, 6, '2014-08-07 11:56:15', '2014-08-07 11:56:15'),
(100, 'Спутниковая поисковая система Infiniti Tracking System (ITS)', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все возможности ITS пожалуйста уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 401, 6, '2014-08-07 12:04:34', '2014-08-07 12:04:34'),
(101, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 402, 6, '2014-08-07 12:05:01', '2014-08-07 12:05:01'),
(102, 'Тягово-сцепное устройство', '0', '<p>\n	<span style="background-color: initial;">Съемное тягово-сцепное устройство грузоподъемностью до 3 тонн.</span>\n</p>', 6, 1, 403, 6, '2014-08-07 12:05:52', '2014-08-07 12:05:52'),
(103, 'Проводка 7-пиновая для тягово-сцепного устройства', '0', '<p>\n	<span style="background-color: initial;">Комплект дополнительной проводки с 7-штырьковым разъемом.</span>\n</p>', 6, 1, 404, 6, '2014-08-07 12:06:36', '2014-08-07 12:06:36'),
(104, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 405, 6, '2014-08-07 12:06:56', '2014-08-07 12:06:56'),
(105, 'Легкосплавный диск R18', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti.</span>\n</p>', 2, 1, 406, 1, '2014-08-07 12:16:21', '2014-08-07 12:16:21'),
(106, 'Легкосплавный диск R19', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti.</span>\n</p>', 2, 1, 407, 1, '2014-08-07 12:16:45', '2014-08-07 12:16:45'),
(107, 'Мягкий коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное велюровое покрытие багажника, разработанное специально для автомобилей Infiniti.</span>\n</p>', 4, 1, 408, 1, '2014-08-07 12:19:15', '2014-08-07 12:19:15');
INSERT INTO `products_accessories` (`id`, `title`, `price`, `description`, `category_id`, `accessibility_id`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(108, 'Полиуретановый коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы полиуретанового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 409, 1, '2014-08-07 12:19:53', '2014-08-07 12:19:53'),
(109, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 410, 1, '2014-08-07 12:20:33', '2014-08-07 12:20:33'),
(110, 'Органайзер в багажник', '0', '<p>\n	<span style="background-color: initial;">Оригинальный аксессуар Infiniti – специальный ящик в багажник, позволяющий организовывать пространство в багажнике вашего автомобиля.</span>\n</p>', 4, 1, 411, 1, '2014-08-07 12:21:12', '2014-08-07 12:21:12'),
(111, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 412, 1, '2014-08-07 12:21:40', '2014-08-07 12:21:40'),
(112, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 413, 1, '2014-08-07 12:22:07', '2014-08-07 12:22:07'),
(113, 'Тягово-сцепное устройство', '0', '<p>\n	<span style="background-color: initial;">Съемное тягово-сцепное устройство грузоподъемностью до 3 тонн.</span>\n</p>', 6, 1, 414, 1, '2014-08-07 12:22:35', '2014-08-07 12:22:35'),
(114, 'Проводка для тягово-сцепного устройства', '0', '<p>\n	<span style="background-color: initial;">Комплект дополнительной проводки с 13 -штырьковым разъемом.</span>\n</p>', 6, 1, 415, 1, '2014-08-07 12:23:02', '2014-08-07 12:23:02'),
(115, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 416, 1, '2014-08-07 12:23:23', '2014-08-07 12:23:23'),
(116, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Четыре эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях</span>\n</p>', 1, 1, 418, 7, '2014-08-07 12:26:40', '2014-08-07 12:26:40'),
(117, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 419, 7, '2014-08-07 12:27:01', '2014-08-07 12:27:01'),
(118, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 420, 7, '2014-08-07 12:27:20', '2014-08-07 12:27:20'),
(119, 'Информационно развлекательный центр', '0', '<p>\n	<span style="background-color: initial;">Встроенная в подголовники двухканальная видеосистема с семидюймовым экраном, LCD дисплеем с DVD плеером, регулируемым углом поворота, наушниками, подключенными через инфракрасный порт и дистанционным управлением. Мультимедийный плеер распознает все основные форматы записи, включая DVD, DVD±R, DVD±RW, HDCD, CD Digital Audio, CD TEXT, CD-Recordable, CD-Re-Writable, MP3 Playback (ID3 TAG), WMA, MPEG-4/Divx ASP (дополнительно). Система также имеет датчик света и дополнительный вход для игр и аудиовыход.</span>\n</p>', 1, 1, 421, 7, '2014-08-07 12:27:37', '2014-08-07 12:27:37'),
(120, 'Брызговики передние и задние', '0', '<p>\n	<span style="background-color: initial;">Комплект передних и задних брызговиков защищают кузов от грязи, воды и мелких камней, придают автомобилю солидный и стильный вид.</span>\n</p>', 2, 1, 422, 7, '2014-08-07 12:28:01', '2014-08-07 12:28:01'),
(121, 'Поперечины рейлингов', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система, которая идеально подходит к форме крыши и уменьшает шум от встречного ветра. Они крепится с помощью надежных крепежей на рейлингах. Грузоподьемность: 75кг</span>\n</p>', 2, 1, 423, 7, '2014-08-07 12:28:30', '2014-08-07 12:28:30'),
(122, 'Накладка заднего бампера', '0', '<p>\n	<span style="background-color: initial;">Стильная алюминиевая накладка защищает окрашенный бампер от царапин и ударов при погрузке вещей в багажник.</span>\n</p>', 2, 1, 424, 7, '2014-08-07 12:28:48', '2014-08-07 12:28:48'),
(123, 'Передние и задние декоративные накладки на бампер', '0', '<p>\n	<span style="background-color: initial;">Придают стилю автомобиля своеобразную динамику и защищают внутренние детали кузова от попадания камней с дорожного покрытия.</span>\n</p>', 2, 1, 425, 7, '2014-08-07 12:29:07', '2014-08-07 12:29:07'),
(124, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 426, 7, '2014-08-07 12:29:26', '2014-08-07 12:29:26'),
(125, 'Дефлектор капота', '0', '<p>\n	<span style="background-color: initial;">Данный аксессуар, защищает капот от сколов при движении на больших скоростях.</span>\n</p>', 2, 1, 427, 7, '2014-08-07 12:29:43', '2014-08-07 12:29:43'),
(126, 'Легкосплавный диск R 21 и R 20', '0', '<p>\n	<span style="background-color: initial;">Легкосплавные колесные диски, придают элегантный вид вашему Infiniti QX70.</span>\n</p>', 2, 1, 428, 7, '2014-08-07 12:30:01', '2014-08-07 12:30:01'),
(127, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 429, 7, '2014-08-07 12:30:22', '2014-08-07 12:30:22'),
(128, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Оригинальный аксессуар Infiniti. Высокий борт и специальные выступы пластикового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 430, 7, '2014-08-07 12:30:41', '2014-08-07 12:30:41'),
(129, 'Мягкий коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Придает багажнику опрятный вид, защищает от грязи. Это долговечный плотный коврик из скрученных нейлоновых нитей и с окантовкой из нейлона, нижняя сторона покрыта нескользящей влагостойкой вулканизированной резиной.</span>\n</p>', 4, 1, 431, 7, '2014-08-07 12:30:57', '2014-08-07 12:30:57'),
(130, 'Колесные гайки-"секретки"', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 432, 7, '2014-08-07 12:31:16', '2014-08-07 12:31:16'),
(131, 'Спутниковая поисковая система ITS', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система, адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все функции ITS (Infiniti Tracking System), пожалуйста, уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 433, 7, '2014-08-07 12:31:35', '2014-08-07 12:31:35'),
(132, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 434, 7, '2014-08-07 12:31:56', '2014-08-07 12:31:56'),
(133, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 435, 7, '2014-08-07 12:35:26', '2014-08-07 12:35:26'),
(134, 'Полиуретановые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное полиуретановые покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 437, 8, '2014-08-07 12:37:52', '2014-08-07 12:37:52'),
(135, 'Резиновые коврики', '0', '<p>\n	<span style="background-color: initial;">Эксклюзивное резиновое покрытие с глубоким узором защищает пол с ковровым покрытием от влаги. Легко моется, выдерживает высокое давление.</span>\n</p>', 1, 1, 438, 8, '2014-08-07 12:38:14', '2014-08-07 12:38:14'),
(136, 'Велюровые коврики', '0', '<p>\n	<span style="background-color: initial;">Пять эксклюзивных велюровых коврика из высококачественного материала. Коврики представлены во всех цветовых решениях внутренней отделки салона.</span>\n</p>', 1, 1, 439, 8, '2014-08-07 12:38:42', '2014-08-07 12:38:42'),
(137, 'Накладки на пороги с подсветкой', '0', '<p>\n	<span style="background-color: initial;">Накладки на пороги передних дверей с уникальной системой подсветки, разработанной специально для автомобилей Infiniti, обеспечивают дополнительную защиту кузова, комфорт при посадке и являются стильным элементом интерьера.</span>\n</p>', 1, 1, 440, 8, '2014-08-07 12:39:03', '2014-08-07 12:39:03'),
(138, 'Поперечины релингов', '0', '<p>\n	<span style="background-color: initial;">Специально разработанная система, которая идеально подходит к форме крыши и уменьшает шум от встречного ветра. Они крепится с помощью надежных крепежей на рейлингах. Грузоподьемность: 75кг</span>\n</p>', 2, 1, 441, 8, '2014-08-07 12:39:26', '2014-08-07 12:39:26'),
(139, 'Накладка заднего бампера', '0', '<p>\n	<span style="background-color: initial;">Стильная алюминиевая накладка защищает окрашенный бампер от царапин и ударов при погрузке вещей в багажник.</span>\n</p>', 2, 1, 442, 8, '2014-08-07 12:39:42', '2014-08-07 12:39:42'),
(140, 'Дефлекторы дверей', '0', '<p>\n	<span style="background-color: initial;">Дефлекторы дверей придают законченный вид и защитят вас от встречного ветра и капель дождя.</span>\n</p>', 2, 1, 443, 8, '2014-08-07 12:40:00', '2014-08-07 12:40:00'),
(141, 'Дефлектор капота', '0', '<p>\n	<span style="background-color: initial;">Данный аксессуар, защищает капот от сколов при движении на больших скоростях.</span>\n</p>', 2, 1, 444, 8, '2014-08-07 12:40:21', '2014-08-07 12:40:21'),
(142, 'Полиуретановый коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы полиуретанового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 445, 8, '2014-08-07 12:40:42', '2014-08-07 12:40:42'),
(143, 'Мягкий коврик для багажника', '0', '<p>\n	<span style="background-color: initial;">Придает багажнику опрятный вид, защищает от грязи. Это долговечный плотный коврик из скрученных нейлоновых нитей и с окантовкой из нейлона, нижняя сторона покрыта нескользящей влагостойкой вулканизированной резиной.</span>\n</p>', 4, 1, 446, 8, '2014-08-07 12:41:05', '2014-08-07 12:41:05'),
(144, 'Поддон в багажник пластиковый', '0', '<p>\n	<span style="background-color: initial;">Высокий борт и специальные выступы пластикового поддона позволяют поддерживать порядок в багажнике. Поддон легко устанавливается, вынимается и моется.</span>\n</p>', 4, 1, 447, 8, '2014-08-07 12:41:23', '2014-08-07 12:41:23'),
(145, 'Защитная сетка для багажника', '0', '<p>\n	<span style="background-color: initial;">Благодаря защитной сетке в вашем багажнике всегда порядок, и мелкие предметы всегда лежат на местах. Защитная сетка крепится в багажнике с помощью крюков.</span>\n</p>', 4, 1, 448, 8, '2014-08-07 12:41:45', '2014-08-07 12:41:45'),
(146, 'Спутниковая поисковая система ITS', '0', '<p>\n	<span style="background-color: initial;">Спутниковая поисковая система, адаптированная для установки только для автомобилей Infiniti, защитит Ваш автомобиль от угона и позволит почувствовать себя защищенным в своем Infiniti. Все функции ITS (Infiniti Tracking System), пожалуйста, уточняйте у продавца – консультанта.</span>\n</p>', 5, 1, 449, 8, '2014-08-07 12:42:05', '2014-08-07 12:42:05'),
(147, 'Гайки-секретки', '0', '<p>\n	<span style="background-color: initial;">Средство защиты колес от кражи. Комплект для крепления колес состоит из четырех секреток и одной специальной секретной насадки. Изготовлены из хромированной и никелированной стали для лучшей защиты от коррозии и повышения износостойкости. Устанавливаются просто и быстро.</span>\n</p>', 5, 1, 450, 8, '2014-08-07 12:42:26', '2014-08-07 12:42:26'),
(148, 'Механический противоугонный замок коробки переключения передач', '0', '<p>\n	<span style="background-color: initial;">Механический замок блокирует движущиеся части механизма или рычаг переключения передач при помощи массивной защитной металлической конструкции и является дополнительной защитой от угона.</span>\n</p>', 5, 1, 451, 8, '2014-08-07 12:42:45', '2014-08-07 12:42:45'),
(149, 'Предпусковой подогреватель', '0', '<p>\n	<span style="background-color: initial;">Предпусковой подогреватель, обеспечит безупречный запуск двигателя, прогрев салона, отсутствие наледи на окнах в холодное время года. Совокупность этих качеств предпускового подогревателя поможет Вам сэкономить время и получить больший комфорт от безопасного управления Вашего Infiniti.</span>\n</p>', 6, 1, 452, 8, '2014-08-07 12:43:03', '2014-08-07 12:43:03'),
(150, 'Проводка для тягово-сцепного устройства', '0', '<p>\n	<span style="background-color: initial;">Комплект дополнительной проводки с 7-штырьковым разъемом.</span>\n</p>', 6, 1, 453, 8, '2014-08-07 12:43:24', '2014-08-07 12:43:24'),
(151, 'Тягово-сцепное устройство', '0', '<p>\n	<span style="background-color: initial;">Съемное тягово-сцепное устройство грузоподъемностью до 3 тонн.</span>\n</p>', 6, 1, 454, 8, '2014-08-07 12:43:43', '2014-08-07 12:43:43');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessory_accessibility`
--

DROP TABLE IF EXISTS `products_accessory_accessibility`;
CREATE TABLE IF NOT EXISTS `products_accessory_accessibility` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `products_accessory_accessibility`
--

INSERT INTO `products_accessory_accessibility` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'в наличии', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'под заказ', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessory_categories`
--

DROP TABLE IF EXISTS `products_accessory_categories`;
CREATE TABLE IF NOT EXISTS `products_accessory_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `products_accessory_categories`
--

INSERT INTO `products_accessory_categories` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'интерьер', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(2, 'аксессуары внешнего дизайна', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(3, 'для багажа', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(4, 'аксессуары в багажник', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(5, 'противоугонные системы', '2014-07-31 11:11:01', '2014-07-31 11:11:01'),
(6, 'другие аксессуары', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `products_category`
--

DROP TABLE IF EXISTS `products_category`;
CREATE TABLE IF NOT EXISTS `products_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `products_category`
--

INSERT INTO `products_category` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Седаны и купе', NULL, '2014-07-31 11:49:17', '2014-07-31 11:49:17'),
(2, 'Кроссоверы и внедорожники', NULL, '2014-07-31 11:49:30', '2014-07-31 11:49:30');

-- --------------------------------------------------------

--
-- Структура таблицы `products_colors`
--

DROP TABLE IF EXISTS `products_colors`;
CREATE TABLE IF NOT EXISTS `products_colors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=59 ;

--
-- Дамп данных таблицы `products_colors`
--

INSERT INTO `products_colors` (`id`, `title`, `color`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 'Серый', '#747474', 158, 1, '2014-07-31 12:16:25', '2014-08-06 06:58:49'),
(2, 'Гранатовый', '#2b171e', 159, 1, '2014-08-05 19:29:12', '2014-08-06 06:59:18'),
(3, 'Серо-коричневый', '#645547', 160, 1, '2014-08-05 19:30:02', '2014-08-06 06:59:49'),
(4, 'Красный', '#8d0512', 161, 1, '2014-08-05 19:30:43', '2014-08-06 07:00:11'),
(5, 'Серебристый', '#c9c9c8', 207, 1, '2014-08-05 19:32:19', '2014-08-06 14:54:32'),
(6, 'Серо-голубой', '#6b808d', 163, 1, '2014-08-05 19:33:02', '2014-08-06 07:00:55'),
(7, 'Кремовый', '#fffef7', 164, 1, '2014-08-05 19:33:38', '2014-08-06 07:01:21'),
(8, 'Черный', '#242323', 165, 1, '2014-08-05 19:34:17', '2014-08-06 07:01:34'),
(9, 'Серебристый', '#8e8c8f', 0, 2, '2014-08-06 06:17:48', '2014-08-06 06:17:48'),
(10, 'Черный', '#000000', 690, 2, '2014-08-06 06:18:10', '2014-08-08 11:23:21'),
(11, 'Гранатовый', '#2b171e', 692, 2, '2014-08-06 06:18:36', '2014-08-08 11:23:51'),
(12, 'Красный', '#a53736', 691, 2, '2014-08-06 06:18:57', '2014-08-08 11:23:34'),
(13, 'Cеро-голубой', '#4972a0', 0, 2, '2014-08-06 06:19:18', '2014-08-06 06:19:18'),
(14, 'Темно-синий', '#394462', 693, 2, '2014-08-06 06:19:56', '2014-08-08 11:24:04'),
(15, 'Серый', '#747378', 689, 2, '2014-08-06 06:20:31', '2014-08-08 11:23:07'),
(16, 'Кремовый', '#d8d8d8', 694, 2, '2014-08-06 06:20:50', '2014-08-08 11:24:14'),
(17, 'Черный', '#222222', 695, 3, '2014-08-07 13:10:32', '2014-08-08 11:28:14'),
(18, 'Красный', '#a53736', 696, 3, '2014-08-07 13:11:17', '2014-08-08 11:28:58'),
(19, 'Гранатовый', '#2b171e', 697, 3, '2014-08-07 13:11:38', '2014-08-08 11:30:21'),
(20, 'Кремовый', '#d7d3cf', 698, 3, '2014-08-07 13:12:40', '2014-08-08 11:30:55'),
(21, 'Серебристый', '#999495', 699, 3, '2014-08-07 13:13:02', '2014-08-08 11:31:30'),
(22, 'Серый', '#737576', 700, 3, '2014-08-07 13:13:35', '2014-08-08 11:31:41'),
(23, 'Серо-голубой', '#adb4cc', 0, 3, '2014-08-07 13:13:57', '2014-08-07 13:13:57'),
(24, 'Кремовый ', '#ffffff', 701, 4, '2014-08-07 13:15:08', '2014-08-08 11:34:33'),
(25, 'Черный', '#000000', 702, 4, '2014-08-07 13:15:23', '2014-08-08 11:34:43'),
(26, 'Гранатовый ', '#2b171e', 703, 4, '2014-08-07 13:15:52', '2014-08-08 11:34:57'),
(27, 'Серебристый', '#d9d9d8', 0, 4, '2014-08-07 13:16:21', '2014-08-07 13:16:21'),
(28, 'Серо-голубой', '#7d808b', 704, 4, '2014-08-07 13:16:39', '2014-08-08 11:35:23'),
(29, 'Серо-зеленый', '#817776', 0, 4, '2014-08-07 13:17:01', '2014-08-08 11:37:02'),
(30, 'Серый', '#6d6c6c', 709, 4, '2014-08-07 13:17:27', '2014-08-08 11:40:53'),
(31, 'Темно-синий', '#434c5b', 707, 4, '2014-08-07 13:17:51', '2014-08-08 11:36:38'),
(32, 'Черный', '#0d0d0d', 710, 5, '2014-08-07 13:18:35', '2014-08-08 11:57:55'),
(33, 'Гранатовый ', '#2b171e', 714, 5, '2014-08-07 13:18:51', '2014-08-08 11:59:35'),
(34, 'Темно-бордовый', '#44302e', 713, 5, '2014-08-07 13:19:23', '2014-08-08 11:58:57'),
(35, 'Серебристый', '#ababad', 715, 5, '2014-08-07 13:19:43', '2014-08-08 11:59:48'),
(36, 'Кремовый', '#dfdfd5', 716, 5, '2014-08-07 13:20:04', '2014-08-08 12:00:00'),
(37, 'Серый ', '#6d6c6c', 717, 5, '2014-08-07 13:20:26', '2014-08-08 12:00:17'),
(38, 'Кремовый', '#f2f2f2', 726, 6, '2014-08-07 13:22:37', '2014-08-08 12:10:17'),
(39, 'Серебристый', '#9f9f9f', 727, 6, '2014-08-07 13:23:01', '2014-08-08 12:10:29'),
(40, 'Дымчато-серый', '#4b4b4e', 732, 6, '2014-08-07 13:23:30', '2014-08-08 12:11:35'),
(41, 'Изумрудный графит', '#292c20', 728, 6, '2014-08-07 13:24:05', '2014-08-08 12:10:56'),
(42, 'Ледяной серый', '#bac6c4', 729, 6, '2014-08-07 13:24:28', '2014-08-08 12:11:05'),
(43, 'Темно-бордовый', '#530312', 730, 6, '2014-08-07 13:24:50', '2014-08-08 12:11:15'),
(44, 'Черный', '#262626', 733, 6, '2014-08-07 13:25:07', '2014-08-08 12:14:53'),
(45, 'Черный', '#0d0d0d', 718, 7, '2014-08-07 13:25:53', '2014-08-08 12:02:29'),
(46, 'Серый', '#848889', 719, 7, '2014-08-07 13:26:10', '2014-08-08 12:02:40'),
(47, 'Платиновый синий', '#243da0', 720, 7, '2014-08-07 13:26:27', '2014-08-08 12:02:50'),
(48, 'Гранатовый', '#2b171e', 721, 7, '2014-08-07 13:26:49', '2014-08-08 12:03:37'),
(49, 'Кремовый', '#eef2f3', 722, 7, '2014-08-07 13:27:22', '2014-08-08 12:03:48'),
(50, 'Серебристый', '#939393', 723, 7, '2014-08-07 13:27:39', '2014-08-08 12:04:01'),
(51, 'Темно-коричневый', '#312323', 724, 7, '2014-08-07 13:28:05', '2014-08-08 12:04:15'),
(52, 'Серо-зеленый', '#2f322b', 725, 7, '2014-08-07 13:28:35', '2014-08-08 12:04:43'),
(53, 'Черный', '#171314', 734, 8, '2014-08-07 13:29:11', '2014-08-08 12:15:13'),
(54, 'Кремовый', '#d4d0d1', 735, 8, '2014-08-07 13:29:31', '2014-08-08 12:15:23'),
(55, 'Серебристый', '#97948f', 736, 8, '2014-08-07 13:29:52', '2014-08-08 12:15:41'),
(56, 'Серо-зеленый', '#3a4547', 737, 8, '2014-08-07 13:30:09', '2014-08-08 12:16:01'),
(57, 'Серый', '#656565', 738, 8, '2014-08-07 13:30:23', '2014-08-08 12:16:24'),
(58, 'Темно-бордовый', '#412e2a', 739, 8, '2014-08-07 13:30:44', '2014-08-08 12:16:37');

-- --------------------------------------------------------

--
-- Структура таблицы `products_complections`
--

DROP TABLE IF EXISTS `products_complections`;
CREATE TABLE IF NOT EXISTS `products_complections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brochure` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `dynamics` text COLLATE utf8_unicode_ci,
  `exterior` text COLLATE utf8_unicode_ci,
  `interior` text COLLATE utf8_unicode_ci,
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Дамп данных таблицы `products_complections`
--

INSERT INTO `products_complections` (`id`, `title`, `price`, `brochure`, `description`, `dynamics`, `exterior`, `interior`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 'Q50 2.0 RWD Base', '1 450 000 руб', NULL, '<ul>\r\n	<li>2,0-литровый бензиновый двигатель с турбонаддувом мощностью 211л.с.</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения</li>\r\n	<li>17" легкосплавные колесные диски, летние шины размерности 225/55R17</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>17" легкосплавные колесные диски, летние шины размерности 225/55R17</li>\r\n	<li>Хромированная декоративная решетка радиатора</li>\r\n	<li>Задний спойлер интегрированный в крышку багажника</li>\r\n	<li>Окрашенные в цвет кузова ручки дверей</li>\r\n	<li>Бамперы, окрашенные в цвет кузова</li>\r\n	<li>Боковые молдинги, окрашенные в цвет кузова</li>\r\n	<li>Две хромированные насадки на выпускные трубы</li>\r\n	<li>Стеклоочиститель с прерывистым режимом работы, зависящим от скорости движения автомобиля</li>\r\n	<li>(ASAP) Краска сопротивляющаяся мелким царапинам</li>\r\n</ul>', '<ul>\r\n	<li>5-местный салон</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>Подогрев лобового стекла в районе дворников</li>\r\n	<li>Автоматический двузонный климат-контроль</li>\r\n	<li>Датчик наружной температуры</li>\r\n	<li>Вентиляционные отверстия в задней части центральной консоли и воздуховоды отопителя на полу</li>\r\n	<li>Электрические стеклоподъемники двери водителя с режимом однократного нажатия для подъема/опускания и автореверсом</li>\r\n	<li>Замки дверей с электроприводом</li>\r\n	<li>Электрический привод открывания крышки багажника</li>\r\n	<li>Сохраняющееся в течение 45 секунд после остановки двигателя питание привода стекол дверей</li>\r\n	<li>Ключ для обслуживающего персонала с функцией блокировки багажника</li>\r\n	<li>Удлинители передних солнцезащитных козырьков</li>\r\n	<li>Футляр для солнечных очков</li>\r\n	<li>Двойные передние и задние подстаканники</li>\r\n	<li>Передний подлокотник с емкостью для хранения вещей и электрической розеткой напряжением 12В</li>\r\n	<li>Откидной центральный подлокотник заднего сиденья с емкостью для хранения вещей</li>\r\n	<li>Зуммер предупреждения о забытых в автомобиле ключах</li>\r\n	<li>Зуммер предупреждения о невыключенных фарах</li>\r\n	<li>Световой индикатор предупреждения о незакрытой двери багажника</li>\r\n	<li>Солнцезащитные козырьки с зеркалом и подсветкой (для водителя и переднего пассажира)</li>\r\n	<li>Два подголовника задних сидений</li>\r\n	<li>Система давления в шинах (TPMS)</li>\r\n	<li>Cветодиодная подсветка салона спереди</li>\r\n</ul>', 118, 1, '2014-07-31 13:49:51', '2014-08-05 19:50:42'),
(2, 'Q50 2.0 RWD Elegance', '1 530 000 руб', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Base</li>\r\n	<li>Кожаный салон</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Base</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Base</li>\r\n	<li>Кожаный салон</li>\r\n</ul>', 20, 1, '2014-07-31 13:58:29', '2014-07-31 13:59:28'),
(3, 'Q50 2.0 RWD Elegance + NAVI', '1 664 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elegance</li>\r\n	<li>Интерактивная навигация нового поколения In Touch + информация о ситуациях на дорогах RDS TMC</li>\r\n	<li>Полностью светодиодное переднее освещение (LED) с авторегулировкой уровня наклона фар</li>\r\n	<li>Датчик света</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elegance</li>\r\n	<li>Полностью светодиодное переднее освещение (LED) с авторегулировкой уровня наклона фар</li>\r\n	<li>Датчик света</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elegance</li>\r\n	<li>Интерактивная навигация нового поколения In Touch + информация о ситуациях на дорогах RDS TMC</li>\r\n</ul>', 119, 1, '2014-08-05 19:58:55', '2014-08-05 19:58:55'),
(4, 'Q50 2.0 RWD Premium', '1 685 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elegance</li>\r\n	<li>Полностью светодиодное переднее освещение (LED) с авторегулировкой уровня наклона фар</li>\r\n	<li>Европейская сигнализация Infiniti с датчиком объема</li>\r\n	<li>Задние сиденья, складываемые в пропорции 40/60</li>\r\n	<li>Датчик дождя+ датчик света</li>\r\n	<li>Двухзонный климат-контроль Plasma Cluster с микрофильтрацией и угольным салонным фильтром для уменьшения попадания посторонних запахов и дыма</li>\r\n	<li>Парктроники спереди и сзади</li>\r\n	<li>Алюминиевая декоративная отделка Kacchu центральной консоли и панели проборов</li>\r\n	<li>18" легкосплавные колесные диски, летние шины размерности 225/50R18</li>\r\n	<li>Двойные складывающиеся наружные зеркала заднего вида с электрическим приводом регулировки</li>\r\n	<li>Чип-ключ "Intelligent key", кнопка включения зажигания</li>\r\n	<li>Память настроек двух вариантов положения сиденья водителя, рулевой колонки и наружных зеркал заднего вида, навигации и аудиосистемы с индивидуальными брелками системы “Intelligent key”</li>\r\n	<li>Сиденья водителя и переднего пассажира с электрорегулировкой положения</li>\r\n	<li>Спортивный передний бампер и пороги</li>\r\n	<li>Подрулевые переключатели передач из магниевого сплава</li>\r\n	<li>Алюминиевые накладки на педали</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение"), равномерно подсвечивающая автомобиль и пространство вокруг него при приближении и удалении от автомобиля.</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elegance</li>\r\n	<li>Полностью светодиодное переднее освещение (LED) с авторегулировкой уровня наклона фар</li>\r\n	<li>Европейская сигнализация Infiniti с датчиком объема</li>\r\n	<li>Датчик дождя+ датчик света</li>\r\n	<li>Парктроники спереди и сзади</li>\r\n	<li>18" легкосплавные колесные диски, летние шины размерности 225/50R18</li>\r\n	<li>Двойные складывающиеся наружные зеркала заднего вида с электрическим приводом регулировки</li>\r\n	<li>Спортивный передний бампер и пороги</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение"), равномерно подсвечивающая автомобиль и пространство вокруг него при приближении и удалении от автомобиля.</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elegance</li>\r\n	<li>Европейская сигнализация Infiniti с датчиком объема</li>\r\n	<li>Задние сиденья, складываемые в пропорции 40/60</li>\r\n	<li>Двухзонный климат-контроль Plasma Cluster с микрофильтрацией и угольным салонным фильтром для уменьшения попадания посторонних запахов и дыма</li>\r\n	<li>Алюминиевая декоративная отделка Kacchu центральной консоли и панели проборов</li>\r\n	<li>Двойные складывающиеся наружные зеркала заднего вида с электрическим приводом регулировки</li>\r\n	<li>Чип-ключ "Intelligent key", кнопка включения зажигания</li>\r\n	<li>Память настроек двух вариантов положения сиденья водителя, рулевой колонки и наружных зеркал заднего вида, навигации и аудиосистемы с индивидуальными брелками системы “Intelligent key”</li>\r\n	<li>Сиденья водителя и переднего пассажира с электрорегулировкой положения</li>\r\n	<li>Подрулевые переключатели передач из магниевого сплава</li>\r\n	<li>Алюминиевые накладки на педали</li>\r\n</ul>', 120, 1, '2014-08-05 20:00:46', '2014-08-05 20:00:46'),
(5, 'Q50 2.0 RWD Premium + NAVI', '1 810 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Premium</li>\r\n	<li>Интерактивная навигация нового поколения In Touch + информация о ситуациях на дорогах RDS TMC</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi HDD Bose с диапазонами AM/FM и RDS, 6CD-чейнджер в центральной консоли и возможностью проигрывания файлов в формате MP3 и WMA, 14 динамиками и управлением на руле</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Premium</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Premium</li>\r\n	<li>Интерактивная навигация нового поколения In Touch + информация о ситуациях на дорогах RDS TMC</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi HDD Bose с диапазонами AM/FM и RDS, 6CD-чейнджер в центральной консоли и возможностью проигрывания файлов в формате MP3 и WMA, 14 динамиками и управлением на руле</li>\r\n</ul>', 121, 1, '2014-08-05 20:02:01', '2014-08-05 20:02:01'),
(6, 'Q50 2.0 RWD Elite', '1 865 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Premium + NAVI</li>\r\n	<li>Отделка салона и центральной консоли вставками из натурального дерева</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n	<li>Система кругового обзора AVM+ Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Салонное зеркало заднего вида с автоматическим затемнением</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Premium + NAVI</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Premium + NAVI</li>\r\n	<li>Отделка салона и центральной консоли вставками из натурального дерева</li>\r\n	<li>Система кругового обзора AVM+ Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Салонное зеркало заднего вида с автоматическим затемнением</li>\r\n</ul>', 122, 1, '2014-08-05 20:03:42', '2014-08-05 20:03:42'),
(7, 'Q50 2.0 RWD GT', '1 945 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elite</li>\r\n	<li>Алюминиевая декоративная отделка Kacchu центральной консоли и панели проборов</li>\r\n	<li>19" легкосплавные колесные диски, летние шины размерности 245/40R19 Run Flat</li>\r\n	<li>Адаптивная электронная система рулевого управления STEER BY WIRE</li>\r\n	<li>Система контроля движения и удержания автомобиля на полосе ACTIVE LANE CONTROL</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elite</li>\r\n	<li>19" легкосплавные колесные диски, летние шины размерности 245/40R19 Run Flat</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Elite</li>\r\n	<li>Алюминиевая декоративная отделка Kacchu центральной консоли и панели проборов</li>\r\n	<li>Адаптивная электронная система рулевого управления STEER BY WIRE</li>\r\n	<li>Система контроля движения и удержания автомобиля на полосе ACTIVE LANE CONTROL</li>\r\n</ul>', 123, 1, '2014-08-05 20:07:12', '2014-08-05 20:07:12'),
(8, 'Q50 2.0 RWD Hi-Tech', '1 995 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD GT</li>\r\n	<li>Люк в крыше с электроприводом наклона и сдвига, с функцией антизащемления</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD GT</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD GT</li>\r\n	<li>Люк в крыше с электроприводом наклона и сдвига, с функцией антизащемления</li>\r\n</ul>', 124, 1, '2014-08-05 20:08:35', '2014-08-05 20:08:35'),
(9, 'Q50 2.0 RWD Hi-Tech+', '2 100 000 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Hi-Tech</li>\r\n	<li>Системы активной безопасности Safety Shield</li>\r\n	<li>Интеллектуальная система круиз-контроля (ICC), система поддержания дистанции до впереди идущего транспортного средства Distance Control Assist (DCA)</li>\r\n	<li>Cистема предупреждения о выходе из полосы движения Lane Departure Warning (LDW)</li>\r\n	<li>Cистема предотвращения выхода из полосы движения Lane Departure Prevention (LDP)</li>\r\n	<li>Система предупреждения о возможном столкновении Forward Collision Warning (FCW)</li>\r\n	<li>Система предотвращения возможного столкновения Forward Collision Avoidance (FCA) (30 км/ч)</li>\r\n	<li>Cистема предупреждения о присутствии объекта в «мертвой зоне» Blind Spot Warning (BSW)</li>\r\n	<li>Система предотвращения столкновения в «мертвых» зонах (BSI)</li>\r\n	<li>Интеллектуальная система помощи при экстренном торможении Intelligent Brake Assist (IBA)</li>\r\n	<li>Система предотвращения наезда на препятствия при движении задним ходом Backup Collision Intervention (BCI)</li>\r\n	<li>Эко-педаль</li>\r\n	<li>Ремни безопасности с функцией предаварийного натяжения при экстренном торможении</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 7,3</li>\r\n	<li>Максимальная скорость: 245 км/ч</li>\r\n	<li>Расход топлива: 9,3/5,7/7,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Hi-Tech</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q50 2.0 RWD Hi-Tech</li>\r\n	<li>Системы активной безопасности Safety Shield</li>\r\n	<li>Интеллектуальная система круиз-контроля (ICC), система поддержания дистанции до впереди идущего транспортного средства Distance Control Assist (DCA)</li>\r\n	<li>Cистема предупреждения о выходе из полосы движения Lane Departure Warning (LDW)</li>\r\n	<li>Cистема предотвращения выхода из полосы движения Lane Departure Prevention (LDP)</li>\r\n	<li>Система предупреждения о возможном столкновении Forward Collision Warning (FCW)</li>\r\n	<li>Система предотвращения возможного столкновения Forward Collision Avoidance (FCA) (30 км/ч)</li>\r\n	<li>Cистема предупреждения о присутствии объекта в «мертвой зоне» Blind Spot Warning (BSW)</li>\r\n	<li>Система предотвращения столкновения в «мертвых» зонах (BSI)</li>\r\n	<li>Интеллектуальная система помощи при экстренном торможении Intelligent Brake Assist (IBA)</li>\r\n	<li>Система предотвращения наезда на препятствия при движении задним ходом Backup Collision Intervention (BCI)</li>\r\n	<li>Эко-педаль</li>\r\n	<li>Ремни безопасности с функцией предаварийного натяжения при экстренном торможении</li>\r\n</ul>', 125, 1, '2014-08-05 20:10:00', '2014-08-05 20:10:00'),
(10, 'Q60 3.7 Coupe Sport', '2 249 000 руб.', NULL, '<ul>\r\n	<li>333 л.с. V6</li>\r\n	<li>Задний привод</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с функцией ручного переключения, спортивным режимом DS и функцией Downshift Rev Matching</li>\r\n	<li>19” легкосплавные колесные диски</li>\r\n	<li>Активная система подруливания всех четырех колес (4WAS)</li>\r\n	<li>Самозатягивающееся лакокрасочное покрытие</li>\r\n</ul>', '<ul>\r\n	<li>Разгон, 0-100 км/ч, с: 5,9</li>\r\n	<li>Максимальная скорость: 250 км/ч</li>\r\n	<li>Расход топлива: 15,3/8,9/11,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Самозатягивающееся лакокрасочное покрытие</li>\r\n	<li>Колеса из легкого сплава размером 19”</li>\r\n	<li>Би-ксеноновые фары с автоматической регулировкой угла наклона и омывателем</li>\r\n	<li>Две выхлопные трубы с хромированными насадками</li>\r\n	<li>Задний спортивный спойлер</li>\r\n	<li>Люк с электроприводом наклона и сдвига, с функцией антизащемления</li>\r\n	<li>Спортивный передний бампер и пороги</li>\r\n</ul>', '<ul>\r\n	<li>Двухзонный климат-контроль</li>\r\n	<li>Двухканальная аудиосистема Bose</li>\r\n	<li>Подогрев лобового стекла</li>\r\n	<li>Чип-ключ с кнопкой включения зажигания</li>\r\n	<li>Спортивные руль и сиденья с усиленной боковой поддержкой</li>\r\n	<li>Отделка салона алюминием Sekitai</li>\r\n	<li>Электропривод складывания боковых зеркал</li>\r\n</ul>', 156, 2, '2014-08-05 21:17:51', '2014-08-05 21:17:51'),
(11, 'Q60 3.7 Coupe Hi-tech', '2 352 500 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование G37 Sport</li>\r\n	<li>Российская навигационная система + информация о ситуации на дорогах RDS -TMC</li>\r\n	<li>Интегрированная система Bluetooth</li>\r\n</ul>', '<ul>\r\n	<li>Разгон, 0-100 км/ч, с: 5,9</li>\r\n	<li>Максимальная скорость: 250 км/ч</li>\r\n	<li>Расход топлива: 15,3/8,9/11,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование G37 Sport</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование G37 Sport</li>\r\n	<li>Российская навигационная система</li>\r\n	<li>Интегрированная система Bluetooth</li>\r\n</ul>', 157, 2, '2014-08-05 21:19:32', '2014-08-05 21:19:32'),
(12, 'Q60 3.7 Cabrio Hi-tech', '2 502 500 руб.', NULL, '<ul>\r\n	<li>3,7 л, 333 л.с., V6</li>\r\n	<li>Задний привод</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и спортивным режимом DS</li>\r\n	<li>Адаптивный климат-контроль с системой Plasma Cluster</li>\r\n	<li>Двухканальная аудиосистема Bose</li>\r\n	<li>19’’ легкосплавные колесные диски</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,4</li>\r\n	<li>Максимальная скорость: 250 км/ч</li>\r\n	<li>Расход топлива: 16,2/8,9/11,6 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>19’’ легкосплавные колесные диски</li>\r\n	<li>Две хромированные насадки на выхлопные трубы</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Краска, сопротивляющаяся мелким царапинам</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n</ul>', '<ul>\r\n	<li>Адаптивный климат-контроль с системой Plasma Cluster</li>\r\n	<li>Двухканальная аудиосистема Bose</li>\r\n	<li>Чип-ключ с кнопкой включения зажигания</li>\r\n	<li>Отделка салона вставками из дерева</li>\r\n	<li>Датчик наружной температуры</li>\r\n	<li>Ветрозащитный экран</li>\r\n</ul>', 204, 3, '2014-08-06 14:24:40', '2014-08-06 14:24:40'),
(13, 'Q60 3.7 Cabrio Hi-tech + allum', '2 527 500 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti G Cabrio Hi-tech</li>\r\n	<li>Отделка салона серо-голубой кожей и алюминием с текстурой Silk Obi (японский шелк)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,4</li>\r\n	<li>Максимальная скорость: 250 км/ч</li>\r\n	<li>Расход топлива: 16,2/8,9/11,6 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti G Cabrio Hi-tech</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti G Cabrio Hi-tech</li>\r\n	<li>Отделка салона серо-голубой кожей и алюминием с текстурой Silk Obi (японский шелк)</li>\r\n</ul>', 205, 3, '2014-08-06 14:26:57', '2014-08-06 14:26:57'),
(14, 'Q60 3.7 Cabrio Hi-tech + wood', '2 527 500 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti G Cabrio Hi-tech</li>\r\n	<li>Отделка салона красной кожей Monaco red и красным кленовым деревом</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,4</li>\r\n	<li>Максимальная скорость: 250 км/ч</li>\r\n	<li>Расход топлива: 16,2/8,9/11,6 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti G Cabrio Hi-tech</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti G Cabrio Hi-tech</li>\r\n	<li>Отделка салона красной кожей Monaco red и красным кленовым деревом</li>\r\n</ul>', 206, 3, '2014-08-06 14:28:03', '2014-08-06 14:28:03'),
(15, 'Q70 2.5 Premium', '1 808 200 руб.', NULL, '<ul>\r\n	<li>222 л.с., V6</li>\r\n	<li>7-ступенчатая автоматическая коробка передач со спортивным режимом DS</li>\r\n	<li>18” легкосплавные диски</li>\r\n</ul>', '<ul>\r\n	<li>Разгон от 0-100 км/ч, с: 9,2</li>\r\n	<li>Максимальная скорость: 231 км/ч</li>\r\n	<li>13,3/7,9/9,9 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>18” легкосплавные диски</li>\r\n	<li>Хромированная декоративная решетка радиатора и ручки дверей</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Датчик света</li>\r\n	<li>Парковочный дисплей и камера заднего вида</li>\r\n	<li>Краска, сопротивляющаяся мелким царапинам</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение")</li>\r\n</ul>', '<ul>\r\n	<li>Двухзонный климат-контроль</li>\r\n	<li>Чип-ключ с кнопкой включения зажигания</li>\r\n	<li>Алюминиевая декоративная отделка центральной консоли и панели проборов</li>\r\n	<li>Отделка салона натуральной кожей и деревом (японский ясень)</li>\r\n	<li>Сиденье переднего пассажира с электроприводом регулировки в 8 направлениях</li>\r\n	<li>Контроллер режимов работы трансмиссии, двигателя и акселератора Infiniti Drive</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose 2.0 с диапазонами</li>\r\n</ul>', 208, 4, '2014-08-06 15:05:16', '2014-08-06 15:05:16'),
(16, 'Q70 2.5 Elite', '1 914 800 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Premium</li>\r\n	<li>Российская навигационная система</li>\r\n	<li>Двухзонный климат-контроль нового поколения с автоматическим режимом рециркуляции воздуха и cистемой Forest A/C (ионизатором и очистителем воздуха)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон от 0-100 км/ч, с: 9,2</li>\r\n	<li>Максимальная скорость: 231 км/ч</li>\r\n	<li>13,3/7,9/9,9 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Premium</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Premium</li>\r\n	<li>Двухзонный климат-контроль нового поколения с автоматическим режимом рециркуляции воздуха и cистемой Forest A/C (ионизатором и очистителем воздуха) </li>\r\n	<li>Аудиосистема высшего класса Bose 5.1 со встроенным жестким диском на 10 ГБ</li>\r\n</ul>', 227, 4, '2014-08-06 16:22:58', '2014-08-06 16:22:58'),
(17, 'Q70 3.7 Premium', '2 054 400 руб.', NULL, '<ul>\r\n	<li>333 л.с., V6</li>\r\n	<li>Полный привод</li>\r\n	<li>7-ступенчатая автоматическая коробка передач со спортивным режимом DS</li>\r\n	<li>18” легкосплавные диски</li>\r\n</ul>', '<ul>\r\n	<li>Разгон от 0-100 км/ч, с: 6,3</li>\r\n	<li>Максимальная скорость: 246 км/ч</li>\r\n	<li>15,3/8,4/10,9 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Premium</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Premium</li>\r\n</ul>', 228, 4, '2014-08-06 16:24:20', '2014-08-06 16:24:20'),
(18, 'Q70 3.7 Elite', '2 189 300 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q70 AWD Premium</li>\r\n	<li>Российская навигационная система</li>\r\n	<li>Адаптивный круиз-контроль</li>\r\n</ul>', '<ul>\r\n	<li>Разгон от 0-100 км/ч, с: 6,3</li>\r\n	<li>Максимальная скорость: 246 км/ч</li>\r\n	<li>15,3/8,4/10,9 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Premium</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Elite</li>\r\n	<li>Информационно-развлекательный центр Infiniti</li>\r\n	<li>Задние сиденья с подогревом и электроприводом регулировки наклона спинок</li>\r\n	<li>Задняя шторка с электроприводом</li>\r\n</ul>', 229, 4, '2014-08-06 16:27:30', '2014-08-06 16:27:30'),
(19, 'Q70 3.7 Hi-tech', '2 353 900 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q70 AWD Elite</li>\r\n	<li>Пакет систем активной без-ти (Safety shield)</li>\r\n	<li>Аудиосистема высшего класса Bose 5.1 с диапазонами AM/FM, RDS, встроенным в переднюю панель жестким диском на 10 ГБ</li>\r\n	<li>Информационно-развлекательный центр Infiniti с установленным в подголовниках передних сидений 2-мя 7-дюймовыми цветными экранами.</li>\r\n</ul>', '<ul>\r\n	<li>Разгон от 0-100 км/ч, с: 6,3</li>\r\n	<li>Максимальная скорость: 246 км/ч</li>\r\n	<li>15,3/8,4/10,9 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Elite</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Elite</li>\r\n</ul>', 230, 4, '2014-08-06 16:29:18', '2014-08-06 16:29:18'),
(20, 'Q70 3.7 Sport', '2 338 700 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Q70 AWD Elite</li>\r\n	<li>Спортивные тормоза</li>\r\n	<li>Системы активной без-ти (Safety shield)</li>\r\n	<li>Аудиосистема высшего класса Bose 5.1 с диапазонами AM/FM, RDS, встроенным в переднюю панель жестким диском на 10 ГБ и возможностью проигрывания файлов в формате MP3 и WMA с 16 динамиками мощностью 391 Ватт</li>\r\n</ul>', '<ul>\r\n	<li>Разгон от 0-100 км/ч, с: 6,3</li>\r\n	<li>Максимальная скорость: 240 км/ч</li>\r\n	<li>15,3/8,4/10,9 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 Elite</li>\r\n	<li>Новые 5-спицевые 20'''' колесные диски из алюминиевого сплава, 245/40R20</li>\r\n	<li> Тонированные передние фары</li>\r\n	<li>Cпортивный передний бампер и пороги</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Q70 AWD Elite</li>\r\n	<li>Спортивные передние сиденья с боковой поддержкой</li>\r\n	<li>Спортивное рулевое колесо</li>\r\n	<li>Отделка интерьера вставками из черного лака Piano Black</li>\r\n	<li>Алюминиевые накладки на педали</li>\r\n	<li>Подрулевые переключатели</li>\r\n</ul>', 231, 4, '2014-08-06 16:30:40', '2014-08-06 16:30:40'),
(23, 'QX50 2.5 Elite AWD', '1 760 000 руб.', NULL, '<ul>\r\n	<li>222 л.с. V6</li>\r\n	<li>Интеллектуальная система полного привода ATTESA-ETS</li>\r\n	<li>7-ступенчатая АКП с режимом ручного переключения и функцией Downshift Rev Matching</li>\r\n	<li>Двухзонный климат-контроль и cистема Plasma Cluster</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>18'''' легкосплавные диски</li>\r\n</ul>', '<ul>\r\n	<li>Разгон: 0-100 км/ч, с: 9,4</li>\r\n	<li>Максимальная скорость: 210 км/ч</li>\r\n	<li>Расход топлива: 14,3/8,4/10,6 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Парковочный дисплей</li>\r\n	<li>18'''' легкосплавные колесные диски, низкопрофильные летние шины размерности 225/55R18</li>\r\n	<li>Система Welcome Lighting ("интуитивное освещение"), равномерно подсвечивающая автомобиль и пространство вокруг него при приближении и удалении от автомобиля</li>\r\n	<li>Парковочные датчики спереди и сзади</li>\r\n	<li>Краска, сопротивляющаяся мелким царапинам</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n</ul>', '<ul>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Центральная консоль: отделение для ПК</li>\r\n	<li>Оптитронные приборы с бело-фиолетовой подсветкой Fine vision</li>\r\n	<li>Рулевое колесо с отделкой из кожи + дерева с подогревом </li>\r\n	<li>Двери с отделкой из натуральной кожи/дерева с алюминиевыми ручками</li>\r\n</ul>', 273, 5, '2014-08-07 05:05:30', '2014-08-07 05:05:30'),
(24, 'QX50 2.5 Hi-Tech AWD', '1 872 100 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti QX50 2.5 AWD Elite</li>\r\n	<li>Российская навигационная система + информация о ситуации на дорогах RDS -TMC</li>\r\n	<li>Активный круиз-контроль</li>\r\n	<li>Система AVM (4 камеры обзора, проецирующие объемную 360 картинку автомобиля на мониторе при парковке)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон: 0-100 км/ч, с: 9,4</li>\r\n	<li>Максимальная скорость: 210 км/ч</li>\r\n	<li>Расход топлива: 14,3/8,4/10,6 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti QX50 2.5 AWD Elite</li>\r\n</ul>', '<ul>\r\n	<li>Включает все стандартное оборудование Infiniti QX50 2.5 AWD Elite</li>\r\n	<li>Российская навигационная система + информация о ситуации на дорогах RDS -TMC</li>\r\n	<li>Активный круиз-контроль</li>\r\n	<li>Отделка салона вставками из кленового дерева</li>\r\n</ul>', 274, 5, '2014-08-07 05:08:36', '2014-08-07 05:08:36'),
(25, 'QX60 3.5 Elegance', '2 225 000 руб.', NULL, '<ul>\r\n	<li>3,5-литровый 24-клапанный двигатель V6 мощностью 262 л.с.</li>\r\n	<li>Cистема полного привода All-mode 4WD</li>\r\n	<li>СVT Вариатор нового поколения Xtronic</li>\r\n	<li>7-местный салон</li>\r\n	<li>Парковочный дисплей + камера заднего вида</li>\r\n	<li>Емкость топливного бака 74 л.</li>\r\n	<li>18” легкосплавные колесные диски (235/65R18)</li>\r\n</ul>', '<div>\r\n	<p>\r\n		Безопасность\r\n	</p>\r\n</div>\r\n<ul>\r\n	<li>Электронная система распределения тормозных усилий (EBD)</li>\r\n	<li>Система помощи при экстренном торможении (BA)</li>\r\n	<li>4-канальная антиблокировочная система (ABS)</li>\r\n	<li>Система динамической стабилизации автомобиля (VDC)</li>\r\n	<li>Противобуксовочная система (TCS)</li>\r\n	<li>Сигнализация Infiniti с иммобилайзером с закодированной микросхемой в чип-ключе</li>\r\n	<li>Система улучшеных надувных подушек безопасности Infiniti (AABS)</li>\r\n	<li>Сдвижной блок педали тормоза<br>\r\n	 «Ломающийся» карданный вал, помогает сохранить целостность пассажирского отсека<br>\r\n	 при серьезных столкновениях</li>\r\n	<li>Система ISOFIX (более низкое размещение креплений и ремней для ребенка)</li>\r\n	<li>Устройство дистанционного открывания крышки багажника в экстренных случаях</li>\r\n	<li>Система давления воздуха в шинах (TPMS) с индикацией давления в каждом колесе</li>\r\n	<li>Контроллер режимов работы трансмиссии, двигателя и акселератора Infiniti Drive</li>\r\n	<li>Парковочный дисплей + камера заднего вида</li>\r\n</ul>', '<ul>\r\n	<li>Хромированные декоративные решетка радиатора и ручки дверей</li>\r\n	<li>Бамперы, окрашенные в цвет кузова</li>\r\n	<li>Боковые молдинги, окрашенные в цвет кузова</li>\r\n	<li>Электропривод регулировки и складывания боковых зеркал</li>\r\n	<li>Обогрев боковых зеркал</li>\r\n	<li>Задний спойлер</li>\r\n	<li>Стеклоочиститель с прерывистым режимом работы, зависящим от скорости движения автомобиля</li>\r\n	<li>Освещаемые плафоны подсветки боковых зеркал</li>\r\n	<li>Освещаемые алюминиевые накладки порогов дверей</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение"), равномерно подсвечивающая автомобиль и пространство вокруг него при приближении и удалении от автомобиля.</li>\r\n	<li>Алюминиевый капот с газовыми амортизаторами и двойным замком</li>\r\n	<li>Электропривод двери багажника</li>\r\n	<li>18” легкосплавные колесные диски (235/65R18)</li>\r\n</ul>', '<ul>\r\n	<li>7-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Отделка салона лакированными вставками</li>\r\n	<li>Монитор заднего вида</li>\r\n	<li>Трех-зонный климат-контроль с автоматическим режимом рециркуляции воздуха</li>\r\n	<li>Вентиляционные отверстия в задней части центральной консоли и воздуховоды отопителя на полу</li>\r\n	<li>Центральный дисплей с маршрутным компьютером на приборном щитке</li>\r\n	<li>Электрические стеклоподъемники дверей с режимом однократного нажатия для подъема/опускания передних стекол и автореверсом</li>\r\n	<li>Замки дверей с электроприводом</li>\r\n	<li>Сохраняющееся в течение 45 секунд после остановки двигателя питание привода стекол дверей и прозрачного люка</li>\r\n	<li>Освещение при посадке в автомобиль с задержкой выключения</li>\r\n	<li>Кармашек над ветровым стеклом для хранения очков</li>\r\n	<li>Двойной верхний плафон для чтения дорожных карт спереди, фонари для чтения сзади</li>\r\n	<li>Карманы для хранения дорожных карт на спинках задних сидений</li>\r\n	<li>Двойные передние и задние подстаканники</li>\r\n	<li>Передний подлокотник с емкостью для хранения вещей и электрической розеткой напряжением 12В</li>\r\n	<li>Откидной центральный подлокотник заднего сиденья с емкостью для хранения вещей</li>\r\n	<li>Зуммер предупреждения о забытых в автомобиле ключах</li>\r\n	<li>Зуммер предупреждения о не выключенных фарах</li>\r\n	<li>Световой индикатор предупреждения о незакрытой двери багажника</li>\r\n	<li>Салонное зеркало заднего вида с функцией автоматического затемнения.</li>\r\n	<li>Солнцезащитные козырьки с зеркалом и подсветкой (для водителя и переднего пассажира)</li>\r\n	<li>Ручка на внутренней стороне задней двери</li>\r\n	<li>Три подголовника задних сидений</li>\r\n	<li>Алюминиевые накладки на педали</li>\r\n	<li>Русифицированный маршрутный компьютер</li>\r\n	<li>Белые стрелки и новый экран маршрутного компьютера</li>\r\n</ul>', 275, 6, '2014-08-07 05:15:43', '2014-08-07 05:50:25');
INSERT INTO `products_complections` (`id`, `title`, `price`, `brochure`, `description`, `dynamics`, `exterior`, `interior`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(26, 'QX60 3.5 Elegance + Roof rail', '2 240 170 руб.', NULL, '<ul>\r\n	<li>3,5-литровый 24-клапанный двигатель V6 мощностью 262 л.с.</li>\r\n	<li>Cистема полного привода All-mode 4WD</li>\r\n	<li>СVT Вариатор нового поколения Xtronic</li>\r\n	<li>7-местный салон</li>\r\n	<li>Парковочный дисплей + камера заднего вида</li>\r\n	<li>Емкость топливного бака 74 л.</li>\r\n	<li>18” легкосплавные колесные диски (235/65R18)</li>\r\n</ul>', '<div>\r\n	<p>\r\n		 Безопасность\r\n	</p>\r\n</div>\r\n<ul>\r\n	<li>Электронная система распределения тормозных усилий (EBD)</li>\r\n	<li>Система помощи при экстренном торможении (BA)</li>\r\n	<li>4-канальная антиблокировочная система (ABS)</li>\r\n	<li>Система динамической стабилизации автомобиля (VDC)</li>\r\n	<li>Противобуксовочная система (TCS)</li>\r\n	<li>Сигнализация Infiniti с иммобилайзером с закодированной микросхемой в чип-ключе</li>\r\n	<li>Система улучшеных надувных подушек безопасности Infiniti (AABS)</li>\r\n	<li>Сдвижной блок педали тормоза<br>\r\n	  «Ломающийся» карданный вал, помогает сохранить целостность пассажирского отсека<br>\r\n	  при серьезных столкновениях</li>\r\n	<li>Система ISOFIX (более низкое размещение креплений и ремней для ребенка)</li>\r\n	<li>Устройство дистанционного открывания крышки багажника в экстренных случаях</li>\r\n	<li>Система давления воздуха в шинах (TPMS) с индикацией давления в каждом колесе</li>\r\n	<li>Контроллер режимов работы трансмиссии, двигателя и акселератора Infiniti Drive</li>\r\n	<li>Парковочный дисплей + камера заднего вида</li>\r\n</ul>', '<ul>\r\n	<li>Хромированные декоративные решетка радиатора и ручки дверей</li>\r\n	<li>Бамперы, окрашенные в цвет кузова</li>\r\n	<li>Боковые молдинги, окрашенные в цвет кузова</li>\r\n	<li>Электропривод регулировки и складывания боковых зеркал</li>\r\n	<li>Обогрев боковых зеркал</li>\r\n	<li>Задний спойлер</li>\r\n	<li>Стеклоочиститель с прерывистым режимом работы, зависящим от скорости движения автомобиля</li>\r\n	<li>Освещаемые плафоны подсветки боковых зеркал</li>\r\n	<li>Освещаемые алюминиевые накладки порогов дверей</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение"), равномерно подсвечивающая автомобиль и пространство вокруг него при приближении и удалении от автомобиля.</li>\r\n	<li>Алюминиевый капот с газовыми амортизаторами и двойным замком</li>\r\n	<li>Электропривод двери багажника</li>\r\n	<li>18” легкосплавные колесные диски (235/65R18)</li>\r\n</ul>', '<ul>\r\n	<li>7-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Отделка салона лакированными вставками</li>\r\n	<li>Монитор заднего вида</li>\r\n	<li>Трех-зонный климат-контроль с автоматическим режимом рециркуляции воздуха</li>\r\n	<li>Вентиляционные отверстия в задней части центральной консоли и воздуховоды отопителя на полу</li>\r\n	<li>Центральный дисплей с маршрутным компьютером на приборном щитке</li>\r\n	<li>Электрические стеклоподъемники дверей с режимом однократного нажатия для подъема/опускания передних стекол и автореверсом</li>\r\n	<li>Замки дверей с электроприводом</li>\r\n	<li>Сохраняющееся в течение 45 секунд после остановки двигателя питание привода стекол дверей и прозрачного люка</li>\r\n	<li>Освещение при посадке в автомобиль с задержкой выключения</li>\r\n	<li>Кармашек над ветровым стеклом для хранения очков</li>\r\n	<li>Двойной верхний плафон для чтения дорожных карт спереди, фонари для чтения сзади</li>\r\n	<li>Карманы для хранения дорожных карт на спинках задних сидений</li>\r\n	<li>Двойные передние и задние подстаканники</li>\r\n	<li>Передний подлокотник с емкостью для хранения вещей и электрической розеткой напряжением 12В</li>\r\n	<li>Откидной центральный подлокотник заднего сиденья с емкостью для хранения вещей</li>\r\n	<li>Зуммер предупреждения о забытых в автомобиле ключах</li>\r\n	<li>Зуммер предупреждения о не выключенных фарах</li>\r\n	<li>Световой индикатор предупреждения о незакрытой двери багажника</li>\r\n	<li>Салонное зеркало заднего вида с функцией автоматического затемнения.</li>\r\n	<li>Солнцезащитные козырьки с зеркалом и подсветкой (для водителя и переднего пассажира)</li>\r\n	<li>Ручка на внутренней стороне задней двери</li>\r\n	<li>Три подголовника задних сидений</li>\r\n	<li>Алюминиевые накладки на педали</li>\r\n	<li>Русифицированный маршрутный компьютер</li>\r\n	<li>Белые стрелки и новый экран маршрутного компьютера</li>\r\n</ul>', 276, 6, '2014-08-07 05:17:26', '2014-08-07 05:52:23'),
(27, 'QX60 3.5 Premium', '2 365 600 руб.', NULL, '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD +</li>\r\n	<li>Российская навигационная система 08IT с HDD</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose с 12 колонками мощностью 358 Ватт и сабвуфером и жестким диском 10 ГБ</li>\r\n	<li>Рулевое колесо с обогревом</li>\r\n	<li>Сиденья водителя с регулируемой в 2 направлениях поясничной опорой</li>\r\n	<li>Устройство запоминания регулировок положения сиденья водителя</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем</li>\r\n	<li>Внутреннее зеркало заднего вида с автоматическим затемнением</li>\r\n	<li>Система кругового обзора AVM + датчики парковки спереди и сзади</li>\r\n	<li>Отделка салона деревом</li>\r\n</ul>', '<div>\r\n	<p>\r\n		Безопасность\r\n	</p>\r\n</div>\r\n<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD +</li>\r\n	<li>Система кругового обзора AVM + датчики парковки спереди и сзади</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD +</li>\r\n	<li>Российская навигационная система 08IT с HDD</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose с 12 колонками мощностью 358 Ватт и сабвуфером и жестким диском 10 ГБ</li>\r\n	<li>Рулевое колесо с обогревом</li>\r\n	<li>Сиденья водителя с регулируемой в 2 направлениях поясничной опорой</li>\r\n	<li>Устройство запоминания регулировок положения сиденья водителя</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем</li>\r\n	<li>Внутреннее зеркало заднего вида с автоматическим затемнением</li>\r\n	<li>Отделка салона деревом</li>\r\n</ul>', 277, 6, '2014-08-07 05:18:58', '2014-08-07 05:50:59'),
(28, 'QX60 3.5 Premium + Roof rail', '2 380 770 руб.', NULL, '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD +</li>\r\n	<li>Российская навигационная система 08IT с HDD</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose с 12 колонками мощностью 358 Ватт и сабвуфером и жестким диском 10 ГБ</li>\r\n	<li>Рулевое колесо с обогревом</li>\r\n	<li>Сиденья водителя с регулируемой в 2 направлениях поясничной опорой</li>\r\n	<li>Устройство запоминания регулировок положения сиденья водителя</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем</li>\r\n	<li>Внутреннее зеркало заднего вида с автоматическим затемнением</li>\r\n	<li>Система кругового обзора AVM + датчики парковки спереди и сзади</li>\r\n	<li>Отделка салона деревом</li>\r\n</ul>', '<div>\r\n	<p>\r\n		 Безопасность\r\n	</p>\r\n</div>\r\n<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD +</li>\r\n	<li>Система кругового обзора AVM + датчики парковки спереди и сзади</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elegance AWD +</li>\r\n	<li>Российская навигационная система 08IT с HDD</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose с 12 колонками мощностью 358 Ватт и сабвуфером и жестким диском 10 ГБ</li>\r\n	<li>Рулевое колесо с обогревом</li>\r\n	<li>Сиденья водителя с регулируемой в 2 направлениях поясничной опорой</li>\r\n	<li>Устройство запоминания регулировок положения сиденья водителя</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем</li>\r\n	<li>Внутреннее зеркало заднего вида с автоматическим затемнением</li>\r\n	<li>Отделка салона деревом</li>\r\n</ul>', 279, 6, '2014-08-07 05:44:54', '2014-08-07 05:52:32'),
(29, 'QX60 3.5 Elite + Roof rail', '2 573 940 руб.', NULL, '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Premium + NAVI AWD +</li>\r\n	<li>Прозрачная панорамная крыша с солнцезащитной шторкой</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20'''' легкосплавные колесные диски с летними шинами 235/55R20</li>\r\n	<li>Задние сиденья с подогревом</li>\r\n	<li>Усовершенствованная система климат-контроля Plasma Cluster с ионизатором и очистителем воздуха Clean Air Vehicle ( CAV)</li>\r\n	<li>Аудиосистема Bose 5.1 Surround Sound с 14 динамиками мощностью 372 Ватт</li>\r\n	<li>Вентилируемые передние сиденья</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Информационно-развлекательный центр Infiniti с установленными в подголовниках передних сидений двумя 7-дюймовыми цветными экранами.</li>\r\n</ul>', '<div>\r\n	<p>\r\n		 Безопасность\r\n	</p>\r\n</div>\r\n<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Premium +</li>\r\n	<li>Датчик дождя</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Premium + NAVI AWD +</li>\r\n	<li>Прозрачная панорамная крыша с солнцезащитной шторкой</li>\r\n	<li>20'''' легкосплавные колесные диски с летними шинами 235/55R20</li>\r\n	<li>Датчик дождя</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Premium + NAVI AWD +</li>\r\n	<li>Задние сиденья с подогревом</li>\r\n	<li>Усовершенствованная система климат-контроля Plasma Cluster с ионизатором и очистителем воздуха Clean Air Vehicle ( CAV)</li>\r\n	<li>Аудиосистема Bose 5.1 Surround Sound с 14 динамиками мощностью 372 Ватт</li>\r\n	<li>Вентилируемые передние сиденья</li>\r\n	<li>Информационно-развлекательный центр Infiniti с установленными в подголовниках передних сидений двумя 7-дюймовыми цветными экранами, вмонтированным в центральную консоль DVD проигрывателем с пультом дистанционного управления и двумя парами беспроводных наушников</li>\r\n</ul>', 280, 6, '2014-08-07 05:47:38', '2014-08-07 05:52:40'),
(30, 'QX60 3.5 Hi-tech + Roof rail', '2 745 870 руб.', NULL, '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elite AWD +</li>\r\n	<li>Cистема предупреждения о присутствии объекта в «мертвой зоне» Blind Spot Warning (BSW) и система предотвращения столкновения с объектом в «мертвой зоне» Blind Spot Intervention (BSI)</li>\r\n	<li>Система предупреждения о возможном столкновении Forward Collision Warning (FCW)</li>\r\n	<li>Интеллектуальная система круиз-контроля (ICC), система поддержания дистанции до впереди идущего транспортного средства Distance Control Assist (DCA)</li>\r\n	<li>Cистема предотвращения выхода из полосы движения Lane Departure Prevention (LDP)</li>\r\n	<li>Ремни безопасности с функцией предаварийного натяжения при экстренном торможении</li>\r\n	<li>Интеллектуальная система помощи при экстренном торможении Intelligent Brake Assist (IBA)</li>\r\n	<li>Система предотвращения наезда на препятствия при движении задним ходом Backup Collision Prevention (BCP)</li>\r\n	<li>Эко-педаль</li>\r\n</ul>', '<p>\r\n	 Безопасность\r\n</p>\r\n<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elite AWD +</li>\r\n	<li>Пакет систем активной без-ти Safety shield</li>\r\n	<li>Cистема поддержания дистанции до впереди идущего транспортного средства Distance Control Assist (DCA)</li>\r\n	<li>Cистема предотвращения выхода из полосы движения Lane Departure Prevention (LDP).</li>\r\n	<li>Система предупреждения о возможном столкновении Forward Collision Warning (FCW)</li>\r\n	<li>Cистема предупреждения о присутствии объекта в «мертвой зоне» Blind Spot Warning (BSW)</li>\r\n	<li>Интеллектуальная система помощи при экстренном торможении Intelligent Brake Assist (IBA)</li>\r\n	<li>Интеллектуальная система круиз-контроля (ICC)</li>\r\n	<li>Система следящая за мертвыми зонами - Blind Spot Intervention (BSI)</li>\r\n	<li>Cистема предотвращения наезда на препятствия при движении задним ходом Backup Collision Prevention (BCP).</li>\r\n	<li>Ремни безопасности с функцией предаварийного натяжения при экстренном торможении</li>\r\n	<li>Эко-педаль</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elite AWD</li>\r\n</ul>', '<ul>\r\n	<li>Имеет все стандартное оборудование QX60 Elite AWD</li>\r\n</ul>', 281, 6, '2014-08-07 05:50:12', '2014-08-07 05:52:48'),
(31, 'QX70 3.0d AWD Elegance', '2 448 600 руб.', NULL, '<ul>\r\n	<li>Дизельный двигатель V6 мощностью 238 л.с</li>\r\n	<li>Интеллектуальная система полного привода ATTESA-ETS</li>\r\n	<li>Электронная система распределения тормозных усилий (EBD)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 8,3</li>\r\n	<li>Максимальная скорость:  212 км/ч</li>\r\n	<li>11,2/7,8/9,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и функцией</li>\r\n	<li>Downshift Rev Matching</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n</ul>', 284, 7, '2014-08-07 06:03:28', '2014-08-07 06:03:28'),
(32, 'QX70 3.0d AWD Elegance + NAVI', '2 619 850 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Elegance +</li>\r\n	<li>Система кругового обзора AVM + Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем для аудиосистемы, климат-контроля и напоминания о необходимости проведения технического обслуживания</li>\r\n	<li>Российская навигация 08IT с HDD и 8-ми дюймовым монитором + встроенным в переднюю панель жестким диском объемом 10 ГБ для проигрывания музыкальных файлов + Активный круиз-контроль (ACC) + Информация о ситуации на дорогах RDS-TMC</li>\r\n	<li>Адаптивный круиз-контроль + система предотвращающая наезд на препятствие (Forward collision warning)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 8,3</li>\r\n	<li>Максимальная скорость: 212 км/ч</li>\r\n	<li>11,2/7,8/9,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и функцией</li>\r\n	<li>Downshift Rev Matching</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n</ul>', 285, 7, '2014-08-07 06:04:32', '2014-08-07 06:04:32'),
(33, 'QX70 3.0d AWD Sport', '2 653 100 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Elegance +</li>\r\n	<li>Спортивное переднее сиденье водителя с регулировкой в 8 направлениях + ручной регулировкой в области плеч и бедер, а также ручными регулировками поясничной поддержки и выдвижного валика подушки.</li>\r\n	<li>Спортивное сиденье переднего пассажира с регулировкой в 8 направлениях + ручными регулировками поясничной поддержки и выдвижного валика подушки</li>\r\n	<li>Дополнительные хромированные молдинги на кузове</li>\r\n	<li>21'''' легкосплавные колесные диски со спортивной резиной 265/45 R21</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 8,3</li>\r\n	<li>Максимальная скорость:  212 км/ч</li>\r\n	<li>11,2/7,8/9,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и функцией</li>\r\n	<li>Downshift Rev Matching</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n</ul>', 286, 7, '2014-08-07 06:05:23', '2014-08-07 06:05:23'),
(34, 'QX70 3.0d AWD Sport + NAVI', '2 824 350 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Sport +</li>\r\n	<li>Система кругового обзора AVM + Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем для аудиосистемы, климат-контроля и напоминания о необходимости проведения технического обслуживания</li>\r\n	<li>Российская навигация 08IT с HDD и 8-ми дюймовым монитором + встроенным в переднюю панель жестким диском объемом 10 ГБ для проигрывания музыкальных файлов + Активный круиз-контроль (ACC) + Информация о ситуации на дорогах RDS-TMC</li>\r\n	<li>Адаптивный круиз-контроль + система предотвращающая наезд на препятствие (Forward collision warning)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 8,3</li>\r\n	<li>Максимальная скорость:  212 км/ч</li>\r\n	<li>11,2/7,8/9,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и функцией</li>\r\n	<li>Downshift Rev Matching</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n</ul>', 287, 7, '2014-08-07 06:06:29', '2014-08-07 06:06:29'),
(35, 'QX70 3.0d AWD Sport (Black)', '2 653 100 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Sport +</li>\r\n	<li>Отделка салона Black Quartz</li>\r\n	<li>Отделка внутр. панелей крыши и потолка черным цветом (только с цветом салона G/P)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 8,3</li>\r\n	<li>Максимальная скорость:  212 км/ч</li>\r\n	<li>11,2/7,8/9,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида         </li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и функцией</li>\r\n	<li>Downshift Rev Matching</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n</ul>', 288, 7, '2014-08-07 06:07:31', '2014-08-07 06:07:31'),
(36, 'QX70 3.0d AWD Sport (Black) + Navi', '2 824 350 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Sport(Black) +</li>\r\n	<li>Система кругового обзора AVM + Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем для аудиосистемы, климат-контроля и напоминания о необходимости проведения технического обслуживания</li>\r\n	<li>Российская навигация 08IT с HDD и 8-ми дюймовым монитором + встроенным в переднюю панель жестким диском объемом 10 ГБ для проигрывания музыкальных файлов + Активный круиз-контроль (ACC) + Информация о ситуации на дорогах RDS-TMC</li>\r\n	<li>Адаптивный круиз-контроль + система предотвращающая наезд на препятствие (Forward collision warning)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 8,3</li>\r\n	<li>Максимальная скорость:  212 км/ч</li>\r\n	<li>11,2/7,8/9,0 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения и функцией</li>\r\n	<li>Downshift Rev Matching</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n</ul>', 289, 7, '2014-08-07 06:08:37', '2014-08-07 06:08:46'),
(37, 'QX70 3.7 AWD Premium', '2 402 200 руб.', NULL, '<ul>\r\n	<li>333 л.с., V6</li>\r\n	<li>Интеллектуальная система полного привода ATTESA-ETS</li>\r\n	<li>Двухканальная аудиосистема высшего класса Bose мощностью 329 Вт</li>\r\n	<li>Двухзонный климат-контроль и система Plasma Cluster</li>\r\n	<li>Чип-ключ Infiniti</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,8</li>\r\n	<li>Максимальная скорость:  233 км/ч</li>\r\n	<li>17,1/9,4/12,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой</li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 290, 7, '2014-08-07 06:10:04', '2014-08-07 06:10:04'),
(38, 'QX70 3.7 AWD Premium + NAVI', '2 548 950 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Premium +</li>\r\n	<li>Система кругового обзора AVM + Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем для аудиосистемы, климат-контроля и напоминания о необходимости проведения технического обслуживания</li>\r\n	<li>Российская навигация 08IT с HDD и 8-ми дюймовым монитором + встроенным в переднюю панель жестким диском объемом 10 ГБ для проигрывания музыкальных файлов + Активный круиз-контроль (ACC)+ Информация о ситуации на дорогах RDS-TMC</li>\r\n	<li>Адаптивный круиз-контроль</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,8</li>\r\n	<li>Максимальная скорость:  233 км/ч</li>\r\n	<li>17,1/9,4/12,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой</li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 291, 7, '2014-08-07 06:11:30', '2014-08-07 06:11:30'),
(39, 'QX70 3.7 AWD Sport', '2 606 700 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Premium +</li>\r\n	<li>Спортивное переднее сиденье водителя с регулировкой в 8 направлениях + ручной регулировкой в области плеч и бедер, а также ручными регулировками поясничной поддержки и выдвижного валика подушки.</li>\r\n	<li>Спортивное сиденье переднего пассажира с регулировкой в 8 направлениях + ручными регулировками поясничной поддержки и выдвижного валика подушки</li>\r\n	<li>21'''' легкосплавные колесные диски со спортивной резиной 265/45 R21</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,8</li>\r\n	<li>Максимальная скорость:  233 км/ч</li>\r\n	<li>17,1/9,4/12,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр             </li>\r\n	<li>5-местный салон             </li>\r\n	<li>Кожаная отделка салона             </li>\r\n	<li>Камера заднего вида             </li>\r\n	<li>Чип-ключ с кнопочным включением зажигания             </li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой             </li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 292, 7, '2014-08-07 06:13:05', '2014-08-07 06:13:05'),
(40, 'QX70 3.7 AWD Sport + NAVI', '2 753 450 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Sport +</li>\r\n	<li>Система кругового обзора AVM + Система обнаружения приближающихся объектов (AOD), Система определения свободного места для парковки (PSM), Система управления парковкой</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым дисплеем для аудиосистемы, климат-контроля и напоминания о необходимости проведения технического обслуживания</li>\r\n	<li>Российская навигация 08IT с HDD и 8-ми дюймовым монитором + встроенным в переднюю панель жестким диском объемом 10 ГБ для проигрывания музыкальных файлов + Активный круиз-контроль (ACC)+ Информация о ситуации на дорогах RDS-TMC</li>\r\n	<li>Адаптивный круиз-контроль</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,8</li>\r\n	<li>Максимальная скорость:  233 км/ч</li>\r\n	<li>17,1/9,4/12,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр;</li>\r\n	<li>5-местный салон</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой</li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 293, 7, '2014-08-07 06:14:13', '2014-08-07 06:14:13'),
(41, 'QX70 3.7 AWD Hi-tech', '2 804 550 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Sport + Navi</li>\r\n	<li>Информационно-развлекательный центр Infiniti с установленным на потолке откидным 9-дюймовым цветным экраном, вмонтированным в центральную консоль проигрывателем DVD-дисков с пультом ДУ и двумя цифровыми беспроводными наушниками</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,8</li>\r\n	<li>Максимальная скорость:  233 км/ч</li>\r\n	<li>17,1/9,4/12,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр             </li>\r\n	<li>5-местный салон             </li>\r\n	<li>Кожаная отделка салона             </li>\r\n	<li>Камера заднего вида             </li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой</li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 295, 7, '2014-08-07 06:17:30', '2014-08-07 06:17:30'),
(42, 'QX70 3.7 AWD Hi-tech (Black quartz)', '2 804 550 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Hi-tech +</li>\r\n	<li>Отделка салона Black Quartz</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 6,8</li>\r\n	<li>Максимальная скорость:  233 км/ч</li>\r\n	<li>17,1/9,4/12,2 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр             </li>\r\n	<li>5-местный салон             </li>\r\n	<li>Кожаная отделка салона             </li>\r\n	<li>Камера заднего вида             </li>\r\n	<li>Чип-ключ с кнопочным включением зажигания             </li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой             </li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 296, 7, '2014-08-07 06:21:20', '2014-08-07 06:21:20'),
(43, 'QX70 5.0 AWD Hi-tech', '3 349 750 руб.', NULL, '<ul>\r\n	<li>400 л.с., V8</li>\r\n	<li>Интеллектуальная система полного привода ATTESA-ETS</li>\r\n	<li>Двухканальная аудиосистема высшего класса Bose мощностью 329 Вт</li>\r\n	<li>Двухзонный климат-контроль и система Plasma Cluster</li>\r\n	<li>Система активного подруливания задних колес RAS</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 5,8</li>\r\n	<li>Максимальная скорость:  250 км/ч</li>\r\n	<li>18,8/9,8/13,1 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой</li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 297, 7, '2014-08-07 06:32:18', '2014-08-07 06:32:18'),
(44, 'QX70 5.0 AWD Hi-tech (Black quartz)', '3 349 750 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование Hi-tech +</li>\r\n	<li>Отделка салона Black Quartz</li>\r\n</ul>', '<ul>\r\n	<li>Разгон 0-100 км/ч, с: 5,8</li>\r\n	<li>Максимальная скорость:  250 км/ч</li>\r\n	<li>18,8/9,8/13,1 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>Задняя дверь с электроприводом</li>\r\n	<li>Реллинги багажника на крыше</li>\r\n	<li>20" литые колесные диски нового дизайна, со всесезонными шинами</li>\r\n	<li>Дополнительные воздухозаборники в передних крыльях</li>\r\n	<li>Хромированная решетка радиатора и ручки дверей</li>\r\n</ul>', '<ul>\r\n	<li>Отделка салона натуральным деревом палисандр</li>\r\n	<li>Кожаная отделка салона</li>\r\n	<li>Камера заднего вида</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой</li>\r\n	<li>Plasma Cluster (ионизатором и очистителем воздуха)</li>\r\n</ul>', 298, 7, '2014-08-07 06:35:50', '2014-08-07 06:35:50');
INSERT INTO `products_complections` (`id`, `title`, `price`, `brochure`, `description`, `dynamics`, `exterior`, `interior`, `image_id`, `product_id`, `created_at`, `updated_at`) VALUES
(45, 'QX80 5.6 4WD (7-местный)', '3 535 200 руб.', NULL, '<ul>\r\n	<li>Новый 5,6-литровый 32-клапанный двигатель V8 мощностью 405 л.с.</li>\r\n	<li>7-ступенчатая автоматическая коробка с функцией Downshift Rev Matching</li>\r\n	<li>Усовершенственная система полного привода All-Mode (AWD)</li>\r\n	<li>4-х зонный климат-контроль  c cистемой Plasma Cluster</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose 2.0 c функцией объемного звучания Driver audio stage</li>\r\n	<li>IPOD/USB разъем + Bluetooth</li>\r\n	<li>22” легкосплавные диски</li>\r\n	<li>Тонированные стекла (задние боковые)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон, 0-100 км/ч, с: 6,5</li>\r\n	<li>Максимальная скорость: 210 км/ч</li>\r\n	<li>20,6/11/14,5 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>22” легкосплавные диски</li>\r\n	<li>Хромированная декоративная решетка радиатора и ручки дверей</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Датчик света</li>\r\n	<li>Система кругового обзора AVM</li>\r\n	<li>Система обнаружения приближающихся объектов (AOD)</li>\r\n	<li>Система определения свободного места для парковки (PSM)</li>\r\n	<li>Система управления парковкой</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение")</li>\r\n	<li>Люк в крыше с функцией автоматического открывания</li>\r\n</ul>', '<ul>\r\n	<li>7-местный салон</li>\r\n	<li>Второй ряд «капитанских сидений» с индивидуальными подлокотниками</li>\r\n	<li>Кожаная обивка сидений</li>\r\n	<li>Четырехзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой Plasma Cluster (ионизатор и очиститель воздуха)</li>\r\n	<li>Рулевое колесо с отделкой из кожи и дерева с подогревом</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi Bose 2.0</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым VGA дисплеем</li>\r\n	<li>Навигация нового поколения с жестким диском</li>\r\n</ul>', 299, 8, '2014-08-07 06:37:53', '2014-08-07 06:37:53'),
(46, 'QX80 5.6 4WD (8-местный)', '3 535 200 руб.', NULL, '<ul>\r\n	<li>Новый 5,6-литровый 32-клапанный двигатель V8 мощностью 405 л.с.</li>\r\n	<li>7-ступенчатая автоматическая коробка с функцией Downshift Rev Matching</li>\r\n	<li>Усовершенственная система полного привода All-Mode (AWD)</li>\r\n	<li>4-х зонный климат-контроль  c cистемой Plasma Cluster</li>\r\n	<li>Чип-ключ с кнопочным включением зажигания</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi 08IT Bose 2.0 c функцией объемного звучания Driver audio stage</li>\r\n	<li>IPOD/USB разъем + Bluetooth</li>\r\n	<li>22” легкосплавные диски</li>\r\n	<li>Тонированные стекла (задние боковые)</li>\r\n</ul>', '<ul>\r\n	<li>Разгон, 0-100 км/ч, с: 6,5</li>\r\n	<li>Максимальная скорость: 210 км/ч</li>\r\n	<li>20,6/11/14,5 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>22” легкосплавные диски</li>\r\n	<li>Хромированная декоративная решетка радиатора и ручки дверей</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Датчик света</li>\r\n	<li>Система кругового обзора AVM</li>\r\n	<li>Система обнаружения приближающихся объектов (AOD)</li>\r\n	<li>Система определения свободного места для парковки (PSM)</li>\r\n	<li>Система управления парковкой</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение")</li>\r\n	<li>Люк в крыше с функцией автоматического открывания</li>\r\n</ul>', '<ul>\r\n	<li>8-местный салон</li>\r\n	<li>Второй ряд «капитанских сидений» с индивидуальными подлокотниками</li>\r\n	<li>Кожаная обивка сидений</li>\r\n	<li>Четырехзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой Plasma Cluster (ионизатор и очиститель воздуха)</li>\r\n	<li>Рулевое колесо с отделкой из кожи и дерева с подогревом</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi Bose 2.0</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым VGA дисплеем</li>\r\n	<li>Навигация нового поколения с жестким диском</li>\r\n</ul>', 300, 8, '2014-08-07 06:39:08', '2014-08-07 06:39:08'),
(47, 'QX80 5.6 4WD Hi-tech (7-местный)', '3 671 200 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование QX56 4WD</li>\r\n	<li>Системы активной безопасности (Safety Shield : DCA, LDW, LDP. FCW, BSW, IBA, ICC, BCP)</li>\r\n	<li>Система BOSE® Cabin Surround 5.1 с 15 динамиками</li>\r\n	<li>Система следящая за мертвыми точками Blind Spot Intervention</li>\r\n</ul>', '<ul>\r\n	<li>Разгон, 0-100 км/ч, с: 6,5</li>\r\n	<li>Максимальная скорость: 210 км/ч</li>\r\n	<li>20,6/11/14,5 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>22” легкосплавные диски</li>\r\n	<li>Хромированная декоративная решетка радиатора и ручки дверей</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Датчик света</li>\r\n	<li>Система кругового обзора AVM</li>\r\n	<li>Система обнаружения приближающихся объектов (AOD)</li>\r\n	<li>Система определения свободного места для парковки (PSM)</li>\r\n	<li>Система управления парковкой</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение")</li>\r\n	<li>Люк в крыше с функцией автоматического открывания</li>\r\n</ul>', '<ul>\r\n	<li>7-местный салон</li>\r\n	<li>Второй ряд «капитанских сидений» с индивидуальными подлокотниками</li>\r\n	<li>Кожаная обивка сидений</li>\r\n	<li>Четырехзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой Plasma Cluster (ионизатор и очиститель воздуха)</li>\r\n	<li>Рулевое колесо с отделкой из кожи и дерева с подогревом</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi Bose 2.0</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым VGA дисплеем</li>\r\n	<li>Навигация нового поколения с жестким диском</li>\r\n</ul>', 301, 8, '2014-08-07 06:40:08', '2014-08-07 06:40:08'),
(48, 'QX80 5.6 4WD Hi-tech (8-местный)', '3 671 200 руб.', NULL, '<ul>\r\n	<li>Включает все стандартное оборудование QX56 4WD</li>\r\n	<li>Системы активной безопасности (Safety Shield : DCA, LDW, LDP. FCW, BSW, IBA, ICC, BCP)</li>\r\n	<li>Система BOSE® Cabin Surround 5.1 с 15 динамиками</li>\r\n	<li>Система следящая за мертвыми точками Blind Spot Intervention</li>\r\n</ul>', '<ul>\r\n	<li>Разгон, 0-100 км/ч, с: 6,5</li>\r\n	<li>Максимальная скорость: 210 км/ч</li>\r\n	<li>20,6/11/14,5 (город/шоссе/смешанный) л/100 км</li>\r\n</ul>', '<ul>\r\n	<li>22” легкосплавные диски</li>\r\n	<li>Хромированная декоративная решетка радиатора и ручки дверей</li>\r\n	<li>Датчик дождя</li>\r\n	<li>Датчик света</li>\r\n	<li>Система кругового обзора AVM</li>\r\n	<li>Система обнаружения приближающихся объектов (AOD)</li>\r\n	<li>Система определения свободного места для парковки (PSM)</li>\r\n	<li>Система управления парковкой</li>\r\n	<li>Система адаптивного освещения (AFS)</li>\r\n	<li>Система Welcome Lightning ("интуитивное освещение")</li>\r\n	<li>Люк в крыше с функцией автоматического открывания</li>\r\n</ul>', '<ul>\r\n	<li>8-местный салон</li>\r\n	<li>Второй ряд «капитанских сидений» с индивидуальными подлокотниками</li>\r\n	<li>Кожаная обивка сидений</li>\r\n	<li>Четырехзонный климат-контроль с автоматическим режимом рециркуляции воздуха и системой Plasma Cluster (ионизатор и очиститель воздуха)</li>\r\n	<li>Рулевое колесо с отделкой из кожи и дерева с подогревом</li>\r\n	<li>Двухканальная аудиосистема Hi-Fi Bose 2.0</li>\r\n	<li>Контроллер Infiniti с 8-дюймовым VGA дисплеем</li>\r\n	<li>Навигация нового поколения с жестким диском</li>\r\n</ul>', 302, 8, '2014-08-07 06:41:12', '2014-08-07 06:41:52');

-- --------------------------------------------------------

--
-- Структура таблицы `products_galleries`
--

DROP TABLE IF EXISTS `products_galleries`;
CREATE TABLE IF NOT EXISTS `products_galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_galleries_product_id_index` (`product_id`),
  KEY `products_galleries_gallery_id_index` (`gallery_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `products_galleries`
--

INSERT INTO `products_galleries` (`id`, `product_id`, `gallery_id`, `title`, `desc`, `created_at`, `updated_at`) VALUES
(1, 1, 30, 'Экстерьер', '', '2014-08-06 15:55:12', '2014-08-06 16:05:21'),
(2, 1, 31, 'Интерьер', '', '2014-08-06 15:56:01', '2014-08-06 16:55:48'),
(3, 1, 32, '', '', '2014-08-06 15:57:05', '2014-08-06 16:05:21'),
(4, 4, 37, 'Экстерьер', '', '2014-08-07 13:42:52', '2014-08-07 13:42:52'),
(5, 4, 38, 'Интерьер', '', '2014-08-07 13:42:52', '2014-08-07 13:42:52'),
(6, 2, 39, 'Экстерьер', '', '2014-08-07 13:47:33', '2014-08-07 13:47:33'),
(7, 2, 40, 'Интерьер', '', '2014-08-07 13:47:33', '2014-08-07 13:47:33'),
(8, 3, 41, 'Экстерьер', '', '2014-08-07 13:51:33', '2014-08-07 13:51:33'),
(9, 3, 42, 'Интерьер', '', '2014-08-07 13:51:33', '2014-08-07 13:51:33'),
(10, 5, 43, 'Экстерьер', '', '2014-08-07 13:57:41', '2014-08-07 13:57:41'),
(11, 5, 44, 'Интерьер', '', '2014-08-07 13:57:41', '2014-08-07 13:57:41'),
(12, 6, 45, 'Экстерьер', '', '2014-08-07 14:04:26', '2014-08-07 14:04:26'),
(13, 6, 46, 'Интерьер', '', '2014-08-07 14:04:26', '2014-08-07 14:04:26'),
(14, 7, 47, 'Экстерьер', '', '2014-08-07 14:12:35', '2014-08-07 14:12:35'),
(15, 7, 48, 'Интерьер', '', '2014-08-07 14:12:35', '2014-08-07 14:12:35'),
(16, 8, 49, 'Экстрерьер', '', '2014-08-07 14:18:58', '2014-08-07 14:18:58'),
(17, 8, 50, 'Интерьер', '', '2014-08-07 14:18:58', '2014-08-07 14:18:58');

-- --------------------------------------------------------

--
-- Структура таблицы `products_instock`
--

DROP TABLE IF EXISTS `products_instock`;
CREATE TABLE IF NOT EXISTS `products_instock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `product_id` int(10) unsigned DEFAULT '0',
  `color_id` int(10) unsigned DEFAULT '0',
  `interior` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `engine` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transmission` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_id` int(10) unsigned DEFAULT NULL,
  `action_id` int(10) unsigned DEFAULT NULL,
  `price` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `products_instock`
--

INSERT INTO `products_instock` (`id`, `title`, `image_id`, `product_id`, `color_id`, `interior`, `year`, `engine`, `transmission`, `status_id`, `action_id`, `price`, `created_at`, `updated_at`) VALUES
(1, 'Q50 2.0 RWD Base', 169, 1, 4, 'Натуральная бежевая кожа / Алюминий', '2014', '2,0-литровый бензиновый двигатель с турбонаддувом мощностью 211л.с.', '7-ступенчатая автоматическая коробка передач с режимом ручного переключения', 2, 0, '1 450 000 руб.', '2014-08-05 15:10:14', '2014-08-06 07:36:15'),
(2, 'Q50 2.0 RWD Premium', 170, 1, 8, 'Бежевая ткань / Алюминий', '2014', '2,0-литровый бензиновый двигатель с турбонаддувом мощностью 211л.с.', '7-ступенчатая автоматическая коробка передач с режимом ручного переключения', 1, 0, '1 685 000 руб.', '2014-08-06 07:38:46', '2014-08-06 07:38:46');

-- --------------------------------------------------------

--
-- Структура таблицы `products_meta`
--

DROP TABLE IF EXISTS `products_meta`;
CREATE TABLE IF NOT EXISTS `products_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_title` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` mediumtext COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `in_menu_content` text COLLATE utf8_unicode_ci,
  `specifications` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_meta_product_id_index` (`product_id`),
  KEY `products_meta_language_index` (`language`),
  KEY `products_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `products_meta`
--

INSERT INTO `products_meta` (`id`, `product_id`, `language`, `title`, `price`, `short_title`, `preview`, `content`, `in_menu_content`, `specifications`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'INFINITI Q50', 'от 1 450 000 руб.', 'Q50', '<p>\r\n	                            ОБЪЕКТ ПРИТЯЖЕНИЯ\r\n</p>\r\n<ul>\r\n	<li>Двигатель 2.0 л R-4, 16V С Турбонаддувом</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний привод</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q50 – основные особености                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/OQUApuF90akguGBH.jpg">\r\n		<div class="column-body">\r\n			<h2>НУЛЕВАЯ ПОДЪЕМНАЯ СИЛА<br>\r\n			</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					                                        Скорость обладает особой магией. В миг, когда устремляешься вперед, ощущаешь, с какой силой ускоряются эмоции, как много страсти под капотом. Это больше, чем просто движение. Аэродинамика автомобиля направляет воздушные потоки так, чтобы ваш Q50 сохранял идеальный баланс, устойчивость и связь с дорогой даже во время сильного ветра и встречных потоков воздуха.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/qzCYL3h0Fe7fOJjH.jpg">\r\n		<div class="column-body">\r\n			<h2>СИСТЕМА ПРЕДОТВРАЩЕНИЯ СТОЛКНОВЕНИЯ</h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Уникальная технология, определеляющая с помощью сенсорсов наличие помехи сзади. Если что-то появляется на пути при движении назад, система предупредит вас и при необходимости активирует тормоза для избежания столкновения.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		 <img src="/uploads/Mea5vNmJnLAyJhss.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>АДАПТИВНОЕ ЭЛЕКТРОННОЕ УПРАВЛЕНИЕ                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Расширяет чувство полного контроля за рулем, вы можете полностью расслабиться: </span><span style="background-color: initial;">электронное адаптивное рулевое управление обеспечивает беспрецедентный уровень управляемости и устраняется вибрация на рулевом колесе.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>АКТИВНЫЙ КРУИЗ-КОНТРОЛЬ                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Система автоматически снижает скорость автомобиля, когда трафик перед вами замедляется. Когда путь свободен, автомобиль ускоряется обратно к желаемой скорости. Лазерные сенсоры и цифровой локатор обнаруживают впереди идущие автомобили и поддерживают выбранную Вами дистанцию.  Меньше усилий, больше легкости.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/jaYRH5eVQ1d0308B.jpg">\r\n		<div class="column-body">\r\n			<h2>СИЛА В КАЖДОМ ПРИКОСНОВЕНИИ                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">INFINITI INTOUCH™ включает вашу цифровую жизнь. Все приложения доступны с одного прикосновения. Одно движение пальцем – и вы в электронной почте, в вашей аудиотеке или в социальных сетях.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/UjEAQlKdJhLljkiM.jpg">\r\n		<div class="column-body">\r\n			<h2>ДИСПЛЕЙ КРУГОВОГО ОБЗОРА                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Революционная технология Infiniti, помогающая вам видеть автомобиль и окружающую обстановку сверху. С обзором 360° вы получаете стопроцентную уверенность в своих действиях.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/yHU1Ene28Vo0OxI5.jpg">\r\n		<div class="column-body">\r\n			<h2>ПРЯМОЙ ОТКЛИК                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Технология гибридного двигателя Infiniti Direct Response («Прямой отклик»)® не попросит Вас выбирать между эффективностью и экспрессией. С расходом бензина 6.8 литров на 100 км Вы получаете 355 лошадиных сил с захватывающей быстротой. Мощный двигатель дает высокий крутящий момент на большем диапазоне оборотов и дольше выдерживает перегрузки.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/1nRdKOxizGmVP3j9.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕПРЕВЗОЙДЕННАЯ ФАКТУРА МАТЕРИАЛОВ                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Прикоснитесь к материалу отделки салона и вы ощутите невероятное чувство. За полтора года мы опросили 360 человек по всему миру, чтобы определить самые приятные тактильные ощущения. А затем мы создали материалы, на 100% отвечающие вашим представлениям об идеальном прикосновении.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', '<p>\r\n	<span style="background-color: initial;">ОБЪЕКТ ПРИТЯЖЕНИЯ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель 2.0 л R-4, 16V С Турбонаддувом</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний привод</li>\r\n</ul>', '<section class="complectations inf-block"> <header>\r\n<h1>                             Оборудование и характеристики                         </h1>\r\n</header>\r\n<div class="filter">\r\n	<ul id="tabs" class="filter-ul">\r\n		<li data-tab="specs" class="filter-li"><a>Характеристики</a></li>\r\n		<li data-tab="base" class="filter-li"><a>Базовое оборудование</a></li>\r\n	</ul>\r\n</div>\r\n<ul id="tabContent" class="spec-tabs">\r\n	<li class="spec-tab" data-tab="specs">\r\n	<table>\r\n	<thead>\r\n	<tr>\r\n		<td>\r\n			                   Общие характеристики\r\n		</td>\r\n		<td>\r\n			<p>\r\n				            Q50 2.0 RWD\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</thead>\r\n	<tbody>\r\n	<tr>\r\n		<td>\r\n			<span style="background-color: initial;">Тип привода</span>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				               RWD\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				               Двигатель, л.\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				               2.0 л\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				               Рабочий объем, см3\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				               1991\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				               Число и расположение цилиндров, газораспреде- лительный механизм\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				               R-4, 16V С Турбонаддувом\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Максимальная мощность, л.с./кВт @ об/мин\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             211/155 @5500\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Максимальный крутящий момент (общий), Нм\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             350 Нм (при 1250-3500 об/мин)\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Емкость топливного бака, л.\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             80\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Снаряженная масса (кг)\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             1642\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Трансмиссия\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             7-ст АКП с функцией ручного переключения\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Коэффициент лобового сопротивления (Cd)\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             0,26\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             Независимая подвеска впереди/сзади\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             двухрычажная/многорычажная\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				             0–100 км/ч, с\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				             7,3\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	<thead>\r\n	<tr>\r\n		<td>\r\n			                   Ходовая часть\r\n		</td>\r\n		<td>\r\n			<p>\r\n				            Q50 2.0 RWD\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</thead>\r\n	<tbody>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				            Независимая подвеска впереди/сзади\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				            двухрычажная/многорычажная\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	<thead>\r\n	<tr>\r\n		<td>\r\n			                   Размеры салона\r\n		</td>\r\n		<td>\r\n			<p>\r\n				            Q50 2.0 RWD\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</thead>\r\n	<tbody>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				            Высота от сидений до крыши с люком впереди/сзади, мм\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				            1002,1/934,50\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				           Пространство для ног впереди/сзади, мм\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				           1131,4/892,1\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				           Ширина салона на уровне плеч впереди/сзади, мм\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				           1439,3/1425,6\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				 <span style="background-color: initial;">Ширина салона на уровне бедер впереди/сзади, мм</span>\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				           1352/1333,2\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				           Объем багажника, л.\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				           500\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	<thead>\r\n	<tr>\r\n		<td>\r\n			           Расход топлива\r\n		</td>\r\n		<td>\r\n			<p>\r\n				 <strong>Q50 2.0 RWD</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</thead>\r\n	<tbody>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				          Городской цикл, л/100км\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				          9.3\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				          Загородный цикл, л/100км\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				          5.7\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				          Смешанный цикл, л/100км\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				          7\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	<thead>\r\n	<tr>\r\n		<td>\r\n			                   Разгон\r\n		</td>\r\n		<td>\r\n			<p>\r\n				          Q50 2.0 RWD\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</thead>\r\n	<tbody>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				         Максимальная скорость, км/ч\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				         245\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<p>\r\n				         0–100 км/ч, с\r\n			</p>\r\n		</td>\r\n		<td>\r\n			<p>\r\n				         7,3\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	</table>\r\n	</li>\r\n	<li class="spec-tab" data-tab="base">\r\n	<h3>Безопасность</h3>\r\n	<ul>\r\n		<li>Электронная система распределения тормозных усилий (EBD)                                  </li>\r\n		<li>Система помощи при экстренном торможении (BA)                                  </li>\r\n		<li>4-канальная антиблокировочная система (ABS)                                  </li>\r\n		<li>Система динамической стабилизации автомобиля (VDC)                                  </li>\r\n		<li>Противобуксовочная система (TCS)                                  </li>\r\n		<li>Центральный замок с ДУ                                  </li>\r\n		<li>Выбор режима открытия только водительской двери или всех дверей                                  </li>\r\n		<li>Блокировка замков дверей от случайного открытия детьми                                  </li>\r\n		<li>Сигнализация Infiniti с иммобилайзером с закодированной микросхемой в чип-ключе                                  </li>\r\n		<li>Система улучшенных надувных подушек безопасности Infiniti (AABS)                                  </li>\r\n		<li>Дополнительные боковые надувные подушки                                  </li>\r\n		<li>Установленные на крыше дополнительные надувные шторки безопасности                                  </li>\r\n		<li>Передние и задние подголовники для всех пассажиров                                  </li>\r\n		<li>Передние активные подголовники                                  </li>\r\n		<li>3-точечные передние ремни безопасности с ELR/ALR                                  </li>\r\n		<li>3-точечные задние ремни безопасности с ELR/ALR                                  </li>\r\n		<li>Сдвижной блок педалей, активизирующийся при столкновении                                  </li>\r\n		<li>«Ломающийся» карданный вал помогает сохранить целостность пассажирского отсека при серьезных столкновениях                                  </li>\r\n		<li>Крепления для детского сиденья ISOFIX                                  </li>\r\n		<li>Устройство дистанционного открывания крышки багажника в экстренных случаях                              </li>\r\n	</ul>\r\n	<h3>ОБЗОР</h3>\r\n	<ul>\r\n		<li>Галогеновые фары</li>\r\n		<li>Передние противотуманные фары (LED)</li>\r\n		<li>Задний противотуманный фонарь</li>\r\n		<li>Задние фонари на светодиодах и лампы заднего хода (LED)</li>\r\n		<li>Омыватели фар</li>\r\n		<li>Обогреватель заднего стекла с таймером</li>\r\n		<li>Стекла с УФ-фильтром (ветровое - с зеленоватым затемнением)</li>\r\n	</ul>\r\n	<h3>ЭКСТЕРЬЕР</h3>\r\n	<ul>\r\n		<li>17" легкосплавные колесные диски, летние шины размерности 225/55R17</li>\r\n		<li>Хромированная декоративная решетка радиатора</li>\r\n		<li>Задний спойлер интегрированный в крышку багажника</li>\r\n		<li>Окрашенные в цвет кузова ручки дверей</li>\r\n		<li>Бамперы, окрашенные в цвет кузова</li>\r\n		<li>Боковые молдинги, окрашенные в цвет кузова</li>\r\n		<li>Две хромированные насадки на выпускные трубы</li>\r\n		<li>Стеклоочиститель с прерывистым режимом работы, зависящим от скорости движения автомобиля</li>\r\n		<li>(ASAP) Краска сопротивляющаяся мелким царапинам</li>\r\n	</ul>\r\n	<h3>ИНТЕРЬЕР</h3>\r\n	<ul>\r\n		<li>5-местный салон</li>\r\n		<li>Камера заднего вида</li>\r\n		<li>Подогрев лобового стекла в районе дворников</li>\r\n		<li>Чип-ключ "Intelligent key", кнопка включения зажигания</li>\r\n		<li>Автоматический двузонный климат-контроль</li>\r\n		<li>Датчик наружной температуры</li>\r\n		<li>Вентиляционные отверстия в задней части центральной консоли и воздуховоды отопителя на полу</li>\r\n		<li>Электрические стеклоподъемники двери водителя с режимом однократного нажатия для подъема/опускания и автореверсом</li>\r\n		<li>Замки дверей с электроприводом</li>\r\n		<li>Электрический привод открывания крышки багажника</li>\r\n		<li>Сохраняющееся в течение 45 секунд после остановки двигателя питание привода стекол дверей</li>\r\n		<li>Освещение при посадке в автомобиль с задержкой выключения</li>\r\n		<li>Ключ для обслуживающего персонала с функцией блокировки багажника</li>\r\n		<li>Удлинители передних солнцезащитных козырьков</li>\r\n		<li>Футляр для солнечных очков</li>\r\n		<li>Двойные передние и задние подстаканники</li>\r\n		<li>Передний подлокотник с емкостью для хранения вещей и электрической розеткой напряжением 12В</li>\r\n		<li>Откидной центральный подлокотник заднего сиденья с емкостью для хранения вещей</li>\r\n		<li>Зуммер предупреждения о забытых в автомобиле ключах</li>\r\n		<li>Зуммер предупреждения о невыключенных фарах</li>\r\n		<li>Световой индикатор предупреждения о незакрытой двери багажника</li>\r\n		<li>Неослепляющее салонное зеркало заднего вида</li>\r\n		<li>Солнцезащитные козырьки с зеркалом и подсветкой (для водителя и переднего пассажира)</li>\r\n		<li>Два подголовника задних сидений</li>\r\n		<li>Система давления в шинах (TPMS)</li>\r\n		<li>Cветодиодная подсветка салона спереди</li>\r\n	</ul>\r\n	<h3>СИДЕНЬЯ И ОТДЕЛКА</h3>\r\n	<ul>\r\n		<li>Обитое тканью сиденье водителя и переднего пассажира с механической регулировкой положения и регулируемой поясничной опорой</li>\r\n		<li>Передние сиденья с подогревом (с новым дизайном кнопок)</li>\r\n		<li>Отделка салона вставками из алюминия</li>\r\n	</ul>\r\n	<h3>КОНТРОЛЬНЫЕ ПРИБОРЫ, ОРГАНЫ УПРАВЛЕНИЯ И АУДИО</h3>\r\n	<ul>\r\n		<li>Круиз-контроль с управлением на рулевом колесе</li>\r\n		<li>Бортовой компьютер</li>\r\n		<li>IPOD/USB + Bluetooth</li>\r\n		<li>Аудиосистема с диапазонами AM/FM/CD, 6 динамиков</li>\r\n		<li>Авторегулировка громкости звука в зависимости от скорости движения автомобиля</li>\r\n		<li>Смонтированная на ветровом стекле антенна</li>\r\n		<li>Оптитронные приборы с бело-фиолетовой подсветкой</li>\r\n		<li>Рычаг переключения передач с оплеткой из натуральной кожи</li>\r\n		<li>Контроллер переключения режимов автомобиля Infiniti Drive Mode Selector</li>\r\n		<li>Двойной сенсорный дисплей</li>\r\n	</ul>\r\n	<h3>ТЕХНИКА</h3>\r\n	<ul>\r\n		<li>Использование платформы FM (Front Mid-ship), при которой двигатель расположен позади переднего моста</li>\r\n		<li>Топливный бак объемом 80 л</li>\r\n		<li>7-ступенчатая автоматическая коробка передач с режимом ручного переключения</li>\r\n		<li>Каталитический нейтрализатор выхлопных газов Евро 4</li>\r\n		<li>2,0-литровый бензиновый и электородвигатель мощностью 211л.с.</li>\r\n		<li>Европейская спецификация и настройка подвески и двигателя + улучшено качество отделки и материалов</li>\r\n		<li>Система помощи при старте на подъеме HSA</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n</section>', 'infiniti-q50', 'INFINITI Q50', '', '', '', '2014-07-31 12:08:41', '2014-08-18 09:24:42'),
(2, 2, 'ru', 'INFINITI Q60 Coupe', 'от 2 249 000 руб.', 'Q60', '<p>\r\n	           ЖАЖДА АДРЕНАЛИНА\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с.</li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	          и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q60 Coupe – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/LiAQ1WQDTOGQ6Wgh.jpg" style="opacity: 1;">\r\n		<div class="column-body">\r\n			<h2>ПРИРОДНОЕ ВДОХНОВЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					<span style="background-color: initial;">Вдохновение превращается в бесконечное чувство восхищения. Дизайнеры Infiniti смогли воплотить таинственное очарование простых природных линий в ярком, но вместе с тем притягательно волнующем облике Infiniti Q60 Coupe. Стремительные линии переднего бампера и  крыльев создают динамичный и  изысканный силуэт.</span>\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/hsHo75OSvhZbMly1.jpg" style="opacity: 1;">\r\n		<div class="column-body">\r\n			<h2>ИЗЯЩЕСТВО И ДИНАМИКА                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Оригинальная решетка радиатора и  аэродинамические пороги не только придают выразительному экстерьеру еще большую элегантность, но  и  повышают динамику автомобиля. Подрулевые переключатели из  магниевого сплава позволяют управлять автоматической коробкой передач, не отрывая рук от рулевого колеса, а педали из алюминиевого сплава подчеркивают спортивный стиль Q60 Coupe.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		<img src="/uploads/Nj2MJ832tKB3hkO2.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>СПОРТИВНЫЙ ХАРАКТЕР                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Выпускная система Infiniti Q60 Coupe специально настраивалась инженерами, чтобы придать особые нотки нарастающему звуку двигателя, а диапазон «звучания» системы составляет целую октаву. Используя идеальную симметрию новой конструкции с двумя коллекторами равной длины, выпускная система добавляет звуковое напряжение при разгоне.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>ОТТОЧЕННАЯ УПРАВЛЯЕМОСТЬ                             </h2>\r\n			<div class="column-desc">\r\n				<span style="background-color: initial;">Рулевое управление настолько легкое, что кажется, будто дорога повинуется Вашим желаниям. Система подруливания, изменяющая угол поворота передних и задних колес,  делает Infiniti Q60 Coupe еще более управляемым и «послушным», дарит Вам чувство полной уверенности и контроля над ситуацией.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/lbUnCPbDfLJd8Aqs.jpg" style="opacity: 1;">\r\n		<div class="column-body">\r\n			<h2>ИДЕАЛЬНАЯ АТМОСФЕРА                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					        Идеальная атмосфера в салоне поддерживается при помощи двухзонного климат-контроля с автоматическим режимом рециркуляции воздуха и системой Plasma Сluster. Фильтр удаляет аллергены,  а ионизатор генерирует положительно и отрицательно заряженные ионы в воздухе, сохраняя чистый и свежий воздух в салоне.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/RTe94eN11xNhgA61.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕУДЕРЖИМАЯ МОЩЬ                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					        Ускорение при разгоне превращается в стремительный бросок вперед. Это ощущение дарит уникальная система управления фазами газораспределения. Благодаря этой системе двигатель молниеносно откликается на управляющие воздействия, а максимальный крутящий момент становится доступен в более широком диапазоне оборотов, при этом уменьшается расход топлива и снижается уровень выбросов вредных веществ в атмосферу.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/SIAVv6u2U6bon9aN.jpg">\r\n		<div class="column-body">\r\n			<h2>ПЛАТФОРМА FRONT-MIDSHIP                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					        Центр тяжести двигателя расположен за передним мостом, благодаря чему происходит оптимальное распределение веса между задней и передней осью, улучшая маневренность и управляемость Вашего Infiniti  Q60 Coupe.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/XKgvERo4gWSPhtCt.jpg">\r\n		<div class="column-body">\r\n			<h2>МАКСИМАЛЬНЫЙ КОМФОРТ                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					        Infiniti Q60 Coupe оборудован стильными спортивными сиденьями. Их совершенная конструкция проработана до мелочей, а для отделки использованы высококачественные материалы, обеспечивающие водителю и пассажиру максимальный комфорт. Сиденье водителя имеет электропривод регулировок в 8 направлениях, электрическую регулировку валиков в области плеч и бедер, а также ручную регулировку поясничной поддержки и выдвижного валика подушки.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', '<p>\r\n	            ЖАЖДА АДРЕНАЛИНА\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с.</li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	           и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q60 Coupe – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/LiAQ1WQDTOGQ6Wgh.jpg" style="opacity: 1;">\r\n		<div class="column-body">\r\n			<h2>ПРИРОДНОЕ ВДОХНОВЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					 <span style="background-color: initial;">Вдохновение превращается в бесконечное чувство восхищения. Дизайнеры Infiniti смогли воплотить таинственное очарование простых природных линий в ярком, но вместе с тем притягательно волнующем облике Infiniti Q60 Coupe. Стремительные линии переднего бампера и  крыльев создают динамичный и  изысканный силуэт.</span>\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/hsHo75OSvhZbMly1.jpg" style="opacity: 1;">\r\n		<div class="column-body">\r\n			<h2>ИЗЯЩЕСТВО И ДИНАМИКА                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Оригинальная решетка радиатора и  аэродинамические пороги не только придают выразительному экстерьеру еще большую элегантность, но  и  повышают динамику автомобиля. Подрулевые переключатели из  магниевого сплава позволяют управлять автоматической коробкой передач, не отрывая рук от рулевого колеса, а педали из алюминиевого сплава подчеркивают спортивный стиль Q60 Coupe.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		 <img src="/uploads/Nj2MJ832tKB3hkO2.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>СПОРТИВНЫЙ ХАРАКТЕР                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Выпускная система Infiniti Q60 Coupe специально настраивалась инженерами, чтобы придать особые нотки нарастающему звуку двигателя, а диапазон «звучания» системы составляет целую октаву. Используя идеальную симметрию новой конструкции с двумя коллекторами равной длины, выпускная система добавляет звуковое напряжение при разгоне.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>ОТТОЧЕННАЯ УПРАВЛЯЕМОСТЬ                             </h2>\r\n			<div class="column-desc">\r\n				 <span style="background-color: initial;">Рулевое управление настолько легкое, что кажется, будто дорога повинуется Вашим желаниям. Система подруливания, изменяющая угол поворота передних и задних колес,  делает Infiniti Q60 Coupe еще более управляемым и «послушным», дарит Вам чувство полной уверенности и контроля над ситуацией.</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/lbUnCPbDfLJd8Aqs.jpg" style="opacity: 1;">\r\n		<div class="column-body">\r\n			<h2>ИДЕАЛЬНАЯ АТМОСФЕРА                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					         Идеальная атмосфера в салоне поддерживается при помощи двухзонного климат-контроля с автоматическим режимом рециркуляции воздуха и системой Plasma Сluster. Фильтр удаляет аллергены,  а ионизатор генерирует положительно и отрицательно заряженные ионы в воздухе, сохраняя чистый и свежий воздух в салоне.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/RTe94eN11xNhgA61.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕУДЕРЖИМАЯ МОЩЬ                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					         Ускорение при разгоне превращается в стремительный бросок вперед. Это ощущение дарит уникальная система управления фазами газораспределения. Благодаря этой системе двигатель молниеносно откликается на управляющие воздействия, а максимальный крутящий момент становится доступен в более широком диапазоне оборотов, при этом уменьшается расход топлива и снижается уровень выбросов вредных веществ в атмосферу.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/SIAVv6u2U6bon9aN.jpg">\r\n		<div class="column-body">\r\n			<h2>ПЛАТФОРМА FRONT-MIDSHIP                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					         Центр тяжести двигателя расположен за передним мостом, благодаря чему происходит оптимальное распределение веса между задней и передней осью, улучшая маневренность и управляемость Вашего Infiniti  Q60 Coupe.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/XKgvERo4gWSPhtCt.jpg">\r\n		<div class="column-body">\r\n			<h2>МАКСИМАЛЬНЫЙ КОМФОРТ                             </h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					         Infiniti Q60 Coupe оборудован стильными спортивными сиденьями. Их совершенная конструкция проработана до мелочей, а для отделки использованы высококачественные материалы, обеспечивающие водителю и пассажиру максимальный комфорт. Сиденье водителя имеет электропривод регулировок в 8 направлениях, электрическую регулировку валиков в области плеч и бедер, а также ручную регулировку поясничной поддержки и выдвижного валика подушки.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', 'infiniti-q60-coupe', 'INFINITI Q60 Coupe', '', '', '', '2014-08-01 08:50:25', '2014-08-11 13:57:44');
INSERT INTO `products_meta` (`id`, `product_id`, `language`, `title`, `price`, `short_title`, `preview`, `content`, `in_menu_content`, `specifications`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(3, 3, 'ru', 'INFINITI Q60 Cabrio', 'от 2 502 500 руб.', 'Q60', '<p>\r\n	          ОТКРОЙТЕ ТАЙНУ, ИЗВЕСТНУЮ ТОЛЬКО ВЕТРУ\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с. </li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	          и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q60 Cabrio – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/BMhWvsM11ECwrR64.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕУДЕРЖИМАЯ МОЩЬ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					  Кабриолет Q60cc – образец мощности, управляемости и эффективности. Стоит надавить на педаль газа и преимущество Infiniti Q60cc становится очевидным: 3,7‑литровый  двигатель мощностью 333 л. с. и система управления подъема клапанов VVEL, позволяет автомобилю плавно, но стремительно разгоняться, подчеркивая истинный характер Infiniti.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<img src="/uploads/DcMCmFytulQ5GJk3.jpg">\r\n			<h2>СПОРТИВНЫЙ ДУХ В КАЖДОЙ ПЕРЕДАЧЕ</h2>\r\n			<div class="column-desc">\r\n				    Спортивный дух Infiniti Q60cc усиливается 7-ступенчатой автоматической коробкой передач с режимом ручного переключения, спортивным режимом DS и функцией Downshift Rev Matching (DRM), обеспечивающей максимальное ускорение и управляемость на дороге.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		<img src="/uploads/mrut1c9tYvMNVzl9.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>ЗАХВАТЫВАЮЩЕЕ УСКОРЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				  Ускорение при разгоне превращается в стремительный бросок вперед. Это ощущение дарит уникальная система управления фазами газораспределения. Благодаря инженерным достижениям Infiniti двигатель выдает высокий крутящий момент в широком диапазоне оборотов, позволяя испытать незабываемые ощущения от ускорения.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>ИНФОРМАТИВНАЯ НАВИГАЦИЯ</h2>\r\n			<div class="column-desc">\r\n				  С навигационной системой Infiniti, отображающей информацию на  3-D дисплее, Вы быстро и легко определите самый удобный для Вас маршрут, принимая во внимание ситуацию на дорогах,  их загруженность и рекомендации системы RDS-TMC, которая  проинформирует Вас о возможных путях объезда.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/mFdBgHMJ8iFea0l7.jpg">\r\n		<div class="column-body">\r\n			<h2>АДАПТИВНЫЙ КЛИМАТ-КОНТРОЛЬ</h2>\r\n			<div class="column-desc">\r\n				   Адаптивная система климат‑контроля распознает все изменения, происходящие вокруг Вас. Если температура становится слишком высокой или система чувствует, что Вы сбавляете скорость и прохладный ветер утихает, автоматически увеличивается подача тепла или холода, чтобы Вы всегда находились в максимально комфортных условиях.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/NvBybFtDWjeZoQOE.jpg">\r\n		<div class="column-body">\r\n			<h2>ИНТЕЛЛЕКТУАЛЬНАЯ АКУСТИЧЕСКАЯ СИСТЕМА</h2>\r\n			<div class="column-desc">\r\n				   Акустическая система высшего класса Bose Open Air со встроенными в передние сиденья персональными динамиками вносит дополнительные ноты совершенства в восприятие звука. Система позволяет получать оптимальную акустическую сцену за счет автоматического регулирования громкости и частотных характеристик, изменяющихся в зависимости от скорости движения, положения откидного верха и уровня шума ветра.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/eUFHXWV9WuKq481M.jpg">\r\n		<div class="column-body">\r\n			<h2>ЧИП-КЛЮЧ INFINITI</h2>\r\n			<div class="column-desc">\r\n				   Infiniti Intelligent Key позволит Вам открыть или закрыть двери и багажник, не вынимая ключ из кармана, запустить двигатель нажатием одной кнопки. С помощью этой системы сиденье, рулевая колонка и боковые зеркала будут автоматически установлены в соответствии с Вашими предпочтениями, заложенными в память автомобиля.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		 <img src="/uploads/sMHoiH7Llsi79NB3.jpg">\r\n		<div class="column-body">\r\n			<h2>СОВЕРШЕНСТВО В КАЖДОЙ ДЕТАЛИ</h2>\r\n			<div class="column-desc">\r\n				   Все детали приборной панели, центральной консоли, переходы к отделке дверей не просто подогнаны с математической точностью. Один  взгляд на них доставляет удовольствие. Стильный и красивый  интерьер – результат ювелирной работы с пространством, где, например, стык между приборной панелью и дверями составляет от 3 до 2,4 мм, чтобы ничто не нарушало плавность линий.\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', '<p>\r\n	<span style="background-color: initial;">ОТКРОЙТЕ ТАЙНУ, ИЗВЕСТНУЮ ТОЛЬКО ВЕТРУ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.7 л, 333 л.с.</li>\r\n	<li>7-ст АКП с функцией ручного переключения <br>\r\n	      и cпортивным режимом DS</li>\r\n	<li>Задний привод (RWD)</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q60 Cabrio – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/BMhWvsM11ECwrR64.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕУДЕРЖИМАЯ МОЩЬ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					   Кабриолет Q60cc – образец мощности, управляемости и эффективности. Стоит надавить на педаль газа и преимущество Infiniti Q60cc становится очевидным: 3,7‑литровый  двигатель мощностью 333 л. с. и система управления подъема клапанов VVEL, позволяет автомобилю плавно, но стремительно разгоняться, подчеркивая истинный характер Infiniti.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			 <img src="/uploads/DcMCmFytulQ5GJk3.jpg">\r\n			<h2>СПОРТИВНЫЙ ДУХ В КАЖДОЙ ПЕРЕДАЧЕ</h2>\r\n			<div class="column-desc">\r\n				     Спортивный дух Infiniti Q60cc усиливается 7-ступенчатой автоматической коробкой передач с режимом ручного переключения, спортивным режимом DS и функцией Downshift Rev Matching (DRM), обеспечивающей максимальное ускорение и управляемость на дороге.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		 <img src="/uploads/mrut1c9tYvMNVzl9.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>ЗАХВАТЫВАЮЩЕЕ УСКОРЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				   Ускорение при разгоне превращается в стремительный бросок вперед. Это ощущение дарит уникальная система управления фазами газораспределения. Благодаря инженерным достижениям Infiniti двигатель выдает высокий крутящий момент в широком диапазоне оборотов, позволяя испытать незабываемые ощущения от ускорения.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>ИНФОРМАТИВНАЯ НАВИГАЦИЯ</h2>\r\n			<div class="column-desc">\r\n				   С навигационной системой Infiniti, отображающей информацию на  3-D дисплее, Вы быстро и легко определите самый удобный для Вас маршрут, принимая во внимание ситуацию на дорогах,  их загруженность и рекомендации системы RDS-TMC, которая  проинформирует Вас о возможных путях объезда.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/mFdBgHMJ8iFea0l7.jpg">\r\n		<div class="column-body">\r\n			<h2>АДАПТИВНЫЙ КЛИМАТ-КОНТРОЛЬ</h2>\r\n			<div class="column-desc">\r\n				    Адаптивная система климат‑контроля распознает все изменения, происходящие вокруг Вас. Если температура становится слишком высокой или система чувствует, что Вы сбавляете скорость и прохладный ветер утихает, автоматически увеличивается подача тепла или холода, чтобы Вы всегда находились в максимально комфортных условиях.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/NvBybFtDWjeZoQOE.jpg">\r\n		<div class="column-body">\r\n			<h2>ИНТЕЛЛЕКТУАЛЬНАЯ АКУСТИЧЕСКАЯ СИСТЕМА</h2>\r\n			<div class="column-desc">\r\n				    Акустическая система высшего класса Bose Open Air со встроенными в передние сиденья персональными динамиками вносит дополнительные ноты совершенства в восприятие звука. Система позволяет получать оптимальную акустическую сцену за счет автоматического регулирования громкости и частотных характеристик, изменяющихся в зависимости от скорости движения, положения откидного верха и уровня шума ветра.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/eUFHXWV9WuKq481M.jpg">\r\n		<div class="column-body">\r\n			<h2>ЧИП-КЛЮЧ INFINITI</h2>\r\n			<div class="column-desc">\r\n				    Infiniti Intelligent Key позволит Вам открыть или закрыть двери и багажник, не вынимая ключ из кармана, запустить двигатель нажатием одной кнопки. С помощью этой системы сиденье, рулевая колонка и боковые зеркала будут автоматически установлены в соответствии с Вашими предпочтениями, заложенными в память автомобиля.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/sMHoiH7Llsi79NB3.jpg">\r\n		<div class="column-body">\r\n			<h2>СОВЕРШЕНСТВО В КАЖДОЙ ДЕТАЛИ</h2>\r\n			<div class="column-desc">\r\n				    Все детали приборной панели, центральной консоли, переходы к отделке дверей не просто подогнаны с математической точностью. Один  взгляд на них доставляет удовольствие. Стильный и красивый  интерьер – результат ювелирной работы с пространством, где, например, стык между приборной панелью и дверями составляет от 3 до 2,4 мм, чтобы ничто не нарушало плавность линий.\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', 'infiniti-q60-cabrio', 'INFINITI Q60 Cabrio', '', '', '', '2014-08-01 09:09:02', '2014-08-11 14:20:55'),
(4, 4, 'ru', 'INFINITI Q70', 'от 1 808 200 руб.', 'Q70', '<p>\r\n	 <span style="background-color: initial;">РОСКОШЕН. СОВЕРШЕНЕН.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л, 3.7 л и V8 5.6 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний и полный приводы</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q70 – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/4wG3ilMptOtvT6B8.jpg">\r\n		<div class="column-body">\r\n			<h2>ЗАХВАТЫВАЮЩЕЕ УСКОРЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				   Infiniti Q70 преобразует механическую энергию в эмоциональный подъем. Мощный двигатель молниеносно откликается, высвобождая высокий крутящий момент на большем диапазоне оборотов, одаривая волной захватывающих ощущений, которые нарастают по мере увеличения разгона.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<img src="/uploads/XUi3AJsEptFr42VT.jpg">\r\n			<h2>ИНТЕЛЛЕТУАЛЬНАЯ СИСТЕМА ПОЛНОГО ПРИВОДА</h2>\r\n			<div class="column-desc">\r\n				         Благодаря интеллектуальной системе полного привода ATTESA E-TS и платформе новейшего поколения Zero-lift Front Midship Platform достигается оптимальное распределение весовых нагрузок между передней и задней осями – вне зависимости от качества дороги управление новым Infiniti Q70 превращается в совершенное удовольствие.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		 <img src="/uploads/9FaD0wxWOhFCj2Z9.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>МАСТЕРСТВО В РАНГЕ ИСКУССТВА</h2>\r\n			<div class="column-desc">\r\n				       Вдохновение природой помогает нам создавать не только динамику, которой нет равных, но и  эстетику плавных обтекаемых линий кузова, отражающих красоту и силу природных стихий.  Буквально все в Infiniti Q70 говорит об удовольствии,  для которого он предназначен.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>СИСТЕМА СЛЕЖЕНИЯ ЗА «МЕРТВЫМИ ЗОНАМИ»</h2>\r\n			<div class="column-desc">\r\n				       С помощью радара система сканирует "мертвую зону" и предупреждает об опасности, которую Вы можете не заметить. При появлении помехи система предупредит Вас и при необходимости поможет предотвратить столкновение.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/68fbFTV7I2wyn77Q.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕУДЕРЖИМАЯ МОЩЬ</h2>\r\n			<div class="column-desc">\r\n				        3,7‑литровый бензиновый двигатель V6 и система управления подъема клапанов VVEL, позволяет автомобилю плавно, но стремительно разгоняться, подчеркивая истинный характер Infiniti.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/xeU2QgbZ7RLKRC4S.jpg">\r\n		<div class="column-body">\r\n			<h2>ИНТУИТИВНОЕ ОСВЕЩЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				        Система освещения Welcome Lighting встречает Вас включением габаритных огней. При приближении к автомобилю внешнее освещение сменяется внутренним, тепло приветствуя Вас. Покидая свой автомобль, Вы увидите, что каскад освещения включается в обратном порядке.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/GckO0s7LTyNC8kFM.jpg">\r\n		<div class="column-body">\r\n			<h2>ВОЖДЕНИЕ INFINITI Q70 — СЛОВНО ПРОГУЛКА В ЛЕСУ</h2>\r\n			<div class="column-desc">\r\n				        Система климат-контроля  создает атмосферу леса внутри салона. Циркуляция воздуха вокруг Вас помогает восстановить силы и дарит успокаивающее ощущение от легкого бриза.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/faSCdNIdXXUdl9P9.jpg">\r\n		<div class="column-body">\r\n			<h2>ИНТУИТИВНО ПОНЯТНОЕ УПРАВЛЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				        Настройте автомобиль в соответствии с дорожными условиями, используя различные режимы вождения Infiniti Drive: Auto, Snow, Sport, Eco. Каждый из этих режимов помогает максимально использовать потенциал автомобиля в соответствующих условиях. В частности, при режиме Eco активируется функция «экономичная педаль» (Eco Pedal): педаль акселератора деликатно сопротивляется водителю, если он нажимает ее слишком сильно, что приводит к большему расходу топлива. Если же водитель предпочитает не использовать «экономичную педаль», данную функцию можно отключить.\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', '<p>\r\n	 <span style="background-color: initial;">РОСКОШЕН. СОВЕРШЕНЕН.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л, 3.7 л и V8 5.6 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Задний и полный приводы</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI Q70 – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/4wG3ilMptOtvT6B8.jpg">\r\n		<div class="column-body">\r\n			<h2>ЗАХВАТЫВАЮЩЕЕ УСКОРЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				   Infiniti Q70 преобразует механическую энергию в эмоциональный подъем. Мощный двигатель молниеносно откликается, высвобождая высокий крутящий момент на большем диапазоне оборотов, одаривая волной захватывающих ощущений, которые нарастают по мере увеличения разгона.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<img src="/uploads/XUi3AJsEptFr42VT.jpg">\r\n			<h2>ИНТЕЛЛЕТУАЛЬНАЯ СИСТЕМА ПОЛНОГО ПРИВОДА</h2>\r\n			<div class="column-desc">\r\n				         Благодаря интеллектуальной системе полного привода ATTESA E-TS и платформе новейшего поколения Zero-lift Front Midship Platform достигается оптимальное распределение весовых нагрузок между передней и задней осями – вне зависимости от качества дороги управление новым Infiniti Q70 превращается в совершенное удовольствие.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-100">\r\n		 <img src="/uploads/9FaD0wxWOhFCj2Z9.jpg">\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<div class="column-body">\r\n			<h2>МАСТЕРСТВО В РАНГЕ ИСКУССТВА</h2>\r\n			<div class="column-desc">\r\n				       Вдохновение природой помогает нам создавать не только динамику, которой нет равных, но и  эстетику плавных обтекаемых линий кузова, отражающих красоту и силу природных стихий.  Буквально все в Infiniti Q70 говорит об удовольствии,  для которого он предназначен.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<h2>СИСТЕМА СЛЕЖЕНИЯ ЗА «МЕРТВЫМИ ЗОНАМИ»</h2>\r\n			<div class="column-desc">\r\n				       С помощью радара система сканирует "мертвую зону" и предупреждает об опасности, которую Вы можете не заметить. При появлении помехи система предупредит Вас и при необходимости поможет предотвратить столкновение.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/68fbFTV7I2wyn77Q.jpg">\r\n		<div class="column-body">\r\n			<h2>НЕУДЕРЖИМАЯ МОЩЬ</h2>\r\n			<div class="column-desc">\r\n				        3,7‑литровый бензиновый двигатель V6 и система управления подъема клапанов VVEL, позволяет автомобилю плавно, но стремительно разгоняться, подчеркивая истинный характер Infiniti.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/xeU2QgbZ7RLKRC4S.jpg">\r\n		<div class="column-body">\r\n			<h2>ИНТУИТИВНОЕ ОСВЕЩЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				        Система освещения Welcome Lighting встречает Вас включением габаритных огней. При приближении к автомобилю внешнее освещение сменяется внутренним, тепло приветствуя Вас. Покидая свой автомобль, Вы увидите, что каскад освещения включается в обратном порядке.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-left">\r\n		 <img src="/uploads/GckO0s7LTyNC8kFM.jpg">\r\n		<div class="column-body">\r\n			<h2>ВОЖДЕНИЕ INFINITI Q70 — СЛОВНО ПРОГУЛКА В ЛЕСУ</h2>\r\n			<div class="column-desc">\r\n				        Система климат-контроля  создает атмосферу леса внутри салона. Циркуляция воздуха вокруг Вас помогает восстановить силы и дарит успокаивающее ощущение от легкого бриза.\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<img src="/uploads/faSCdNIdXXUdl9P9.jpg">\r\n		<div class="column-body">\r\n			<h2>ИНТУИТИВНО ПОНЯТНОЕ УПРАВЛЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				        Настройте автомобиль в соответствии с дорожными условиями, используя различные режимы вождения Infiniti Drive: Auto, Snow, Sport, Eco. Каждый из этих режимов помогает максимально использовать потенциал автомобиля в соответствующих условиях. В частности, при режиме Eco активируется функция «экономичная педаль» (Eco Pedal): педаль акселератора деликатно сопротивляется водителю, если он нажимает ее слишком сильно, что приводит к большему расходу топлива. Если же водитель предпочитает не использовать «экономичную педаль», данную функцию можно отключить.\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', 'infiniti-q70', 'INFINITI Q70', '', '', '', '2014-08-01 09:20:12', '2014-08-12 06:42:16'),
(5, 5, 'ru', 'INFINITI QX50', 'от 1 760 000 руб.', 'QX50', '<p>\r\n	           ЭЛЕГАНТНОСТЬ ТОЖЕ СПОРТ\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л и 3.7 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения<br>\r\n	          и cпортивным режимом DS</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI QX50 – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/eDJgV3RfYfhsyWCk.jpg">\r\n		<div class="column-body">\r\n			<h2>НАРАСТАЮЩЕЕ УСКОРЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					   Infiniti QX50 – это не только великолепный дизайн, но и потрясающая мощь и динамика. Какими бы впечатляющими ни были эргономика, роскошь и комфорт, они не смогут сравниться с тем удовольствием от вождения, которое Вы испытаете за рулем Вашего Infiniti QX50.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<img src="/uploads/ZSozQqBC2ykhgwSn.jpg">\r\n			<h2>ИНТУИТИВНОЕ ОСВЕЩЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					   Система Welcome Lightning («интуитивное освещение»), равномерно подсвечивающая салон автомобиля и пространство вокруг него при приближении и удалении от автомобиля. В салоне Infiniti QX50 свет не только подчеркивает достоинства дизайна, но и создает уютную и комфортную обстановку для водителя и пассажиров.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="clearfix">\r\n	</div>\r\n	<div class="column-100">\r\n		<img src="/uploads/p8wDkRwlUi1Xnjg1.jpg">\r\n		<div class="column-50 column-left">\r\n			<div class="column-body">\r\n				<h2>АКТИВНЫЙ КРУИЗ-КОНТРОЛЬ</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Лазерные сенсоры и цифровой локатор обнаруживают впереди идущие автомобили и поддерживают выбранную Вами дистанцию. Даже когда система отключена, сенсоры продолжают контролировать дистанцию и передают информацию в систему помощи при экстренном торможении.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="column-50 column-right">\r\n			<div class="column-body">\r\n				<h2>ЛЕГКАЯ ПАРКОВКА</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Система Infiniti Around View Monitor (AVM) - это 4 камеры обзора, проецирующие объемную картинку автомобиля на мониторе при парковке и 360° градусов обзора.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="clearfix">\r\n		</div>\r\n		<div class="column-50 column-left">\r\n			<img src="/uploads/yc12IpuEGsPXBgPF.jpg">\r\n			<div class="column-body">\r\n				<h2>ИНТЕЛЛЕТУАЛЬНАЯ СИСТЕМА ПОЛНОГО ПРИВОДА</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   По-настоящему яркие впечатления от вождения можно получить, только ощущая полный контроль над автомобилем. Интеллектуальная система полного привода Infiniti (ATTESA E-TS) анализирует поверхность дороги и включает полный привод, когда это необходимо, затем снова автоматически переключается на задний привод.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="column-50 column-right">\r\n			<img src="/uploads/rF0lB6qBAxL97dzZ.jpg">\r\n			<div class="column-body">\r\n				<h2>АДАПТИВНАЯ СИСТЕМА ОСВЕЩЕНИЯ ПЕРЕДНИХ ФАР</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Система AFS (Adaptive Front lightening System – адаптивные фары) направляет световые лучи фар Infiniti QX50 в соответствии с углом поворота колес и скоростью автомобиля, подсвечивая повороты и улучшая видимость на извилистой дороге в ночное время.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="clearfix">\r\n		</div>\r\n		<div class="column-50 column-left">\r\n			<img src="/uploads/nv5yj6a3xsCJUBZi.jpg">\r\n			<div class="column-body">\r\n				<h2>ПРОСТРАНСТВО В ВАШЕЙ ВЛАСТИ</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Чтобы легко разместить габаритный груз можно сложить задние сиденья одним нажатием кнопки на передней приборной панели. Еще одно нажатие – и кресла примут свое исходное положение.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="column-50 column-right">\r\n			<img src="/uploads/f2UdAalY8YWN06gN.jpg">\r\n			<div class="column-body">\r\n				<h2>ИНФОРМАТИВНАЯ НАВИГАЦИЯ</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   С навигационной системой Infiniti Вы быстро и легко определите самый удобный для Вас путь, принимая во внимание ситуацию на дороге, их загруженность и рекомендации системы RDS-TMC, которая проинформирует Вас о путях объезда.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', '<p>\r\n	<span style="background-color: initial;">ЭЛЕГАНТНОСТЬ ТОЖЕ СПОРТ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 2.5 л и 3.7 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения<br>\r\n	        и cпортивным режимом DS</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '<section class="model-sect">\r\n<h1>                     INFINITI QX50 – основные особенности                 </h1>\r\n<div class="columns clearfix">\r\n	<div class="column-50 column-left">\r\n		<img src="/uploads/eDJgV3RfYfhsyWCk.jpg">\r\n		<div class="column-body">\r\n			<h2>НАРАСТАЮЩЕЕ УСКОРЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					   Infiniti QX50 – это не только великолепный дизайн, но и потрясающая мощь и динамика. Какими бы впечатляющими ни были эргономика, роскошь и комфорт, они не смогут сравниться с тем удовольствием от вождения, которое Вы испытаете за рулем Вашего Infiniti QX50.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="column-50 column-right">\r\n		<div class="column-body">\r\n			<img src="/uploads/ZSozQqBC2ykhgwSn.jpg">\r\n			<h2>ИНТУИТИВНОЕ ОСВЕЩЕНИЕ</h2>\r\n			<div class="column-desc">\r\n				<p>\r\n					   Система Welcome Lightning («интуитивное освещение»), равномерно подсвечивающая салон автомобиля и пространство вокруг него при приближении и удалении от автомобиля. В салоне Infiniti QX50 свет не только подчеркивает достоинства дизайна, но и создает уютную и комфортную обстановку для водителя и пассажиров.\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class="clearfix">\r\n	</div>\r\n	<div class="column-100">\r\n		<img src="/uploads/p8wDkRwlUi1Xnjg1.jpg">\r\n		<div class="column-50 column-left">\r\n			<div class="column-body">\r\n				<h2>АКТИВНЫЙ КРУИЗ-КОНТРОЛЬ</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Лазерные сенсоры и цифровой локатор обнаруживают впереди идущие автомобили и поддерживают выбранную Вами дистанцию. Даже когда система отключена, сенсоры продолжают контролировать дистанцию и передают информацию в систему помощи при экстренном торможении.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="column-50 column-right">\r\n			<div class="column-body">\r\n				<h2>ЛЕГКАЯ ПАРКОВКА</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Система Infiniti Around View Monitor (AVM) - это 4 камеры обзора, проецирующие объемную картинку автомобиля на мониторе при парковке и 360° градусов обзора.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="clearfix">\r\n		</div>\r\n		<div class="column-50 column-left">\r\n			<img src="/uploads/yc12IpuEGsPXBgPF.jpg">\r\n			<div class="column-body">\r\n				<h2>ИНТЕЛЛЕТУАЛЬНАЯ СИСТЕМА ПОЛНОГО ПРИВОДА</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   По-настоящему яркие впечатления от вождения можно получить, только ощущая полный контроль над автомобилем. Интеллектуальная система полного привода Infiniti (ATTESA E-TS) анализирует поверхность дороги и включает полный привод, когда это необходимо, затем снова автоматически переключается на задний привод.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="column-50 column-right">\r\n			<img src="/uploads/rF0lB6qBAxL97dzZ.jpg">\r\n			<div class="column-body">\r\n				<h2>АДАПТИВНАЯ СИСТЕМА ОСВЕЩЕНИЯ ПЕРЕДНИХ ФАР</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Система AFS (Adaptive Front lightening System – адаптивные фары) направляет световые лучи фар Infiniti QX50 в соответствии с углом поворота колес и скоростью автомобиля, подсвечивая повороты и улучшая видимость на извилистой дороге в ночное время.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="clearfix">\r\n		</div>\r\n		<div class="column-50 column-left">\r\n			<img src="/uploads/nv5yj6a3xsCJUBZi.jpg">\r\n			<div class="column-body">\r\n				<h2>ПРОСТРАНСТВО В ВАШЕЙ ВЛАСТИ</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   Чтобы легко разместить габаритный груз можно сложить задние сиденья одним нажатием кнопки на передней приборной панели. Еще одно нажатие – и кресла примут свое исходное положение.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n		<div class="column-50 column-right">\r\n			<img src="/uploads/f2UdAalY8YWN06gN.jpg">\r\n			<div class="column-body">\r\n				<h2>ИНФОРМАТИВНАЯ НАВИГАЦИЯ</h2>\r\n				<div class="column-desc">\r\n					<p>\r\n						   С навигационной системой Infiniti Вы быстро и легко определите самый удобный для Вас путь, принимая во внимание ситуацию на дороге, их загруженность и рекомендации системы RDS-TMC, которая проинформирует Вас о путях объезда.\r\n					</p>\r\n				</div>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</section>', 'infiniti-qx50', 'INFINITI QX50', '', '', '', '2014-08-01 09:26:55', '2014-08-12 08:03:07'),
(6, 6, 'ru', 'INFINITI QX60', 'от 2 225 000 руб.', 'QX60', '<p>\r\n	           РОСКОШЬ ВО ВСЕХ ИЗМЕРЕНИЯХ\r\n</p>\r\n<p>\r\n	  Кредит от <strong style="background-color: initial;">5,75%</strong>\r\n</p>', '', '<p>\r\n	 <span style="background-color: initial;">РОСКОШЬ ВО ВСЕХ ИЗМЕРЕНИЯХ</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V6 3.5 л, 262 л.с.</li>\r\n	<li>Трансмиссия СVT (Xtronic) с функцией <br>\r\n	       ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx60', 'INFINITI QX60', '', '', '', '2014-08-01 09:37:33', '2014-08-08 12:43:45'),
(7, 7, 'ru', 'INFINITI QX70', '', 'QX70', '<p>\r\n	    ПРИРОЖДЕННЫЙ ПРОВОКАТОР\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 3.0 л, 3.7 л и V8 5.0 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', '<p>\r\n	 <span style="background-color: initial;">ПРИРОЖДЕННЫЙ ПРОВОКАТОР</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатели V6 3.0 л, 3.7 л и V8 5.0 л</li>\r\n	<li>7-ст АКП с функцией ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx70', 'INFINITI QX70', '', '', '', '2014-08-01 10:10:34', '2014-08-08 12:45:42'),
(8, 8, 'ru', 'INFINITI QX80', '', 'QX80', '<p>\r\n	      ЕЖЕДНЕВНО. ПЕРВЫМ КЛАССОМ.\r\n</p>\r\n<ul>\r\n	<li>Двигатель V8 5.6 л, 405 л.с.</li>\r\n	<li>7-ст АКП с функцией <br>\r\n	    ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', '<p>\r\n	 <span style="background-color: initial;">ЕЖЕДНЕВНО. ПЕРВЫМ КЛАССОМ.</span>\r\n</p>\r\n<ul>\r\n	<li>Двигатель V8 5.6 л, 405 л.с.</li>\r\n	<li>7-ст АКП с функцией <br>\r\n	   ручного переключения</li>\r\n	<li>Полный привод (AWD)</li>\r\n</ul>', '', 'infiniti-qx80', 'INFINITI QX80', '', '', '', '2014-08-01 10:17:05', '2014-08-08 12:49:46');

-- --------------------------------------------------------

--
-- Структура таблицы `products_video`
--

DROP TABLE IF EXISTS `products_video`;
CREATE TABLE IF NOT EXISTS `products_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci,
  `product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Структура таблицы `related_production`
--

DROP TABLE IF EXISTS `related_production`;
CREATE TABLE IF NOT EXISTS `related_production` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT '0',
  `related_product_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `related_production`
--

INSERT INTO `related_production` (`id`, `product_id`, `related_product_id`, `created_at`, `updated_at`) VALUES
(5, 2, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=51 ;

--
-- Дамп данных таблицы `rel_mod_gallery`
--

INSERT INTO `rel_mod_gallery` (`id`, `module`, `unit_id`, `gallery_id`) VALUES
(1, 'products', 1, 1),
(2, 'products', 1, 2),
(3, 'products', 1, 3),
(4, 'products', 1, 4),
(5, 'products', 9, 5),
(7, 'products', 10, 7),
(8, 'products', 9, 8),
(9, 'products', 9, 9),
(10, 'products', 10, 10),
(11, 'products', 11, 11),
(12, 'products', 1, 12),
(13, 'products', 1, 13),
(14, 'products', 1, 14),
(15, 'products', 1, 15),
(16, 'products', 1, 16),
(17, 'products', 8, 17),
(18, 'products', 7, 18),
(19, 'products', 6, 19),
(20, 'products', 5, 20),
(21, 'products', 4, 21),
(22, 'products', 3, 22),
(23, 'products', 2, 23),
(24, 'products', 4, 24),
(25, 'products', 3, 25),
(26, 'products', 4, 26),
(27, 'products', 1, 27),
(28, 'products', 1, 28),
(29, 'products', 1, 29),
(30, 'products', 1, 30),
(31, 'products', 1, 31),
(32, 'products', 1, 32),
(33, 'products', 6, 33),
(34, 'products', 6, 34),
(35, 'products', 9, 35),
(36, 'products', 5, 36),
(37, 'products', 4, 37),
(38, 'products', 4, 38),
(39, 'products', 2, 39),
(40, 'products', 2, 40),
(41, 'products', 3, 41),
(42, 'products', 3, 42),
(43, 'products', 5, 43),
(44, 'products', 5, 44),
(45, 'products', 6, 45),
(46, 'products', 6, 46),
(47, 'products', 7, 47),
(48, 'products', 7, 48),
(49, 'products', 8, 49),
(50, 'products', 8, 50);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('0206468449886918025a9075067824d03f513a3d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjdkRmpIMzRxVXRSaWlZdjhGVWJablhFTUd2ZFhEeVB5OVBYSlpoVSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODM1MzQ2MztzOjE6ImMiO2k6MTQwODM1MzE5ODtzOjE6ImwiO3M6MToiMCI7fX0=', 1408353463),
('03ff0e5b736984c8e48aa4dff86acc0ba18ef134', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTE53STNoaVBNVWVpcnZ2WkpDUUw0aU15SGNiN0ozOTR5SWFuQWhITCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTg7czoxOiJjIjtpOjE0MDgzNTI5MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352919),
('08eb4291ad90b5772be275c4a1887a6b07f67775', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVhvcnp4U1F2OVZnTDBBdExTZ2VZcGhhOEVNVzFMeThiWGJnMnhRNyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODM1NDgzOTtzOjE6ImMiO2k6MTQwODM1NDgzMTtzOjE6ImwiO3M6MToiMCI7fX0=', 1408354839),
('0ba90a3559270636ad394d08bcfbdee4e71c9a4b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1JSdHpVY2FEaXdpcXJXWXhXcjRmMGtHbmM4bU9IWnhZUXR1Z1B1bSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NDc7czoxOiJjIjtpOjE0MDgzNTI5NDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352947),
('0c476846d8c031381e6dbad90371b3f9dcf403d7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU2NtNVJEaTVJUThYdlpBYUNXcjlDdGZTMjhCdzJuMlYwWnVRdHRhcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4Mzg7czoxOiJjIjtpOjE0MDgzNTM4Mzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353839),
('19947476234fcab384e3b0d1379710ee99467bb9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFhPVWF3WDBFTVJEQ090NUN0SlV4M1pzYmU4WXp3TGVsSmJLcEJ0RCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MjM7czoxOiJjIjtpOjE0MDgzNTI5MjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352923),
('1ab6b84bf7cdf9693b1e7d8b67b3ce6cce6eb2bc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVk5iMG5kcW1IMjJYT2pLYVh4R1ZCbEV3c3EwRjJmMVg5WkI0T0dRViI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzM7czoxOiJjIjtpOjE0MDgzNTI5MzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352933),
('1cb456ba9f7dfbecab37cd204ece587c2735f731', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnJHN3lXVjVhYW1kMFFVbjJsZm1oNjVPeWlJdHpLM01EdGs0ZVJZMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MjI7czoxOiJjIjtpOjE0MDgzNTI5MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352922),
('25874a81f37fefa29d42a955f9052f965811b30d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTTZsRkc0M2V0bDJ0R1NYSzROcWRsYTA0cHZzWWozdTk0eFQ4WEhEaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4NTA7czoxOiJjIjtpOjE0MDgzNTM4NTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353850),
('2c9e32771f76baa84f62019c101952977da43cd4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWlwVnJWbEo3TkFNTUpKaTRaWjZJemg2ZGJJaDBxTzZkYXk4ZlNjTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4NDM7czoxOiJjIjtpOjE0MDgzNTM4NDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353843),
('2d89e1e73c424187cfdf4ed5a8935aa72531ac1e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1FLbzNscXBTaVpwYWcxMElmWWdDVW9URnJ1RDNyQ3ZWSkhNY3FZMyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI4NDU7czoxOiJjIjtpOjE0MDgzNTI4NDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352845),
('3024bb50279a8271ee263bf2e867e1f6d1988b28', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVFCRW9OMm5FbjJUQjFacnhzZDNDaVpUdlBMREo0eWcwOEFIOVFMVyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTk7czoxOiJjIjtpOjE0MDgzNTI5MTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352920),
('33cc7567e6d9e519a6c852ff6de7f97415564a89', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT0pybUFrWnVNYTh4TllsOW05Um5IMlZYOElkWlNVeU9rSVppdDgwTyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNjM1NzE7czoxOiJjIjtpOjE0MDgzNjM1NzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408363571),
('347a4dd39513f008715e5afa0767188fead0b57d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNUpMcDlvMTcwQmRjc3JRN0lTNnJSMmt2VGtRNWVHWTFzbUkzMW9mUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzA7czoxOiJjIjtpOjE0MDgzNTI5MzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352930),
('352819980b84d78bd4c8405719048a6f089f9b37', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFFVcjVRbWkxcFk4ZnFhVWJ1YmZaVW8xRHZoVkdPaW1ueXN0dTZCZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTU7czoxOiJjIjtpOjE0MDgzNTI5MTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352915),
('381a6a4875d8d6934f8e807e43aba7ac4b59ae08', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVNQNXFZQmpmVjhGRVg3WjJrc3hQU0xiMk1BSTRRUGhnZzNoemlDcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTg7czoxOiJjIjtpOjE0MDgzNTI5MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352919),
('39d5b77b92cebdb7695785929bdd7159950d250f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOXFTcW95R1Bmcm9jRTVRQ3ZqeDZiS2NZdWhyUWNUVXZZTXY2VGl4NCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzQ7czoxOiJjIjtpOjE0MDgzNTI5MzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352935),
('417e5de3ae6719c29a431564c8c31ac620a68820', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTJvVWtVRE1NT3FNVm1Cd09OUHpUUVRXVk11YVk1U2NCWll0VERLMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4NDY7czoxOiJjIjtpOjE0MDgzNTM4NDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353846),
('431a81c561afbecedb553710df7955fed12acb28', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYXpwVkZ5djBQVEpTUG8ybHdGbzZwUGVxVWMxWGw0UmNKQnFVeDNBWSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTU7czoxOiJjIjtpOjE0MDgzNTI5MTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352915),
('4c81a965077fa2fe747c93a0164938cd693b322d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMGt1YmUwSnA2N1lueThBOUhscjA1aHZGNUFhVXBuVENQMVJlaTB2ayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTY7czoxOiJjIjtpOjE0MDgzNTI5MTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352917),
('4f7ae17e96189490a3b7afb9c6fe08c615e0954d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibTNTZ3FNcG9vcFlaeHFBdjJreFNuNkdpMTVFQnBwUlZZeGYyU0hMeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTY7czoxOiJjIjtpOjE0MDgzNTI5MTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352916),
('4ff406b7de022da1930c04803dce93f73f5b0e97', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaFlyQ25FQWNHdHBsZFhLVnRUcFU5SnVQdFVKeG1SY2tPUUFmaU52UCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTg7czoxOiJjIjtpOjE0MDgzNTI5MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352919),
('508f487947eb48907d148883c12218e08798c5ca', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUzNZWUtFU1Y2aGlYZnRqczVkbWVCSUpiWnljUFJiWFo4MzFhN242NSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODM1NDMxNDtzOjE6ImMiO2k6MTQwODM0Mjc4NTtzOjE6ImwiO3M6MToiMCI7fX0=', 1408354314),
('53c23236fd318d3db5120c993b01abdc09327ffd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZUpoRERKUFdzdjJwWkZDd09IcHlFY0lTZ3VjYTlkcWduaWFoWWdsdSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MjM7czoxOiJjIjtpOjE0MDgzNTI5MjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352923),
('5ad7ccc2851711e0ca9b2b79d30bb906837cdad3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWZiRG1UclRYbXM1elc4aE9pQm5WSzczS2djeDJ0QnBiNVdOQWFObiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTY7czoxOiJjIjtpOjE0MDgzNTI5MTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352916),
('6493ea77b0b9d1440b5c876744a24b8508452228', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmwwbWFnZk04WWhXVGExRjNVeW1sT3JaTVhienBGTnVKNmRRTktyRyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzE7czoxOiJjIjtpOjE0MDgzNTI5MzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352931),
('67e7a8697a89502a5609b3cc7447bb857fc8a906', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlljdWpSUkNmUWZ5YWdxMW9jNElQRGxMUEhSRmtBeTNXaE1mT2lSOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTU7czoxOiJjIjtpOjE0MDgzNTI5NTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352956),
('6c006cbd41bd5be296893055e09d5e7565c5d17a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieU5sSHpQRGhxb3A4SXFITkdKWmRIU2xGa1UxSkpBUWVCNUtjcHpJZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTM7czoxOiJjIjtpOjE0MDgzNTI5NTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352954),
('6c5f511be3e8ca7031f47afc9bec541909da7bbe', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVExMTlFoRHF1ekZiZlA5dUN0emtCWHJ0WEt1OG1ZU1BlM0Z4YUw5OSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNjM1NzQ7czoxOiJjIjtpOjE0MDgzNjM1NzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408363574),
('6f936430c33ffa864ca891992bed011c72e41042', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNElVUXVvUVZqM1c0YkN0U1pjODg1dGNIeHZ2UE9TSU9jb1ZXQkJwcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTI7czoxOiJjIjtpOjE0MDgzNTI5MTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352912),
('7061862947f071a9922d45e636d4b94440bc5960', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoieHl6NXpsa0Q4ajBsTjZjTlJtb0ZIenRHMEd0SW1HQ2p1RjVFZkFMYiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIxIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODM1NDk5MjtzOjE6ImMiO2k6MTQwODM1NDk3ODtzOjE6ImwiO3M6MToiMCI7fX0=', 1408354992),
('748aa52b79a6f178280708ec3661deefbef88a34', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2hCSU5iZldHVlBjN1RaNjE2TDBvWFVMQXJ5SUJwMWFPOHZRTzBLbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTI7czoxOiJjIjtpOjE0MDgzNTI5NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352953),
('7c51128db87c0f9d47775c236bb21fb818eccf3d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidE9TWlFLUzNTSGtwdFNleDd0bXZKN1VZWVVrYWNCd2pMWUdHY0FGYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzY7czoxOiJjIjtpOjE0MDgzNTI5MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352936),
('80535da8b60a9d0357d3cc590d2ff187ca7bfa75', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2Q4NGxZaTVaOGhGUzZnYTJKMktieERGNHp0RHhJVVNEMk9SZE9uVCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzU7czoxOiJjIjtpOjE0MDgzNTI5MzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352935),
('8865c0b494f5f059bc9362d2960d23f138354d3a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2JkNXJEVUh4RWRHaE9OV1ZPRmtFZTJXVEpicFJOZWxYTXFNYUk1biI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NDg7czoxOiJjIjtpOjE0MDgzNTI5NDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352948),
('8a853aec0bf64df58d265a83502c91f7da5d00ef', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieGxLR3dLdEs0UEludlJzaDJoREFCVVVTRk5leUk5R2NtYVJWVEF3dCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTU7czoxOiJjIjtpOjE0MDgzNTI5NTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352955),
('8dd3c3cd410ac5e98aa267ba6988c9ffcb35cbae', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3VpU2JlUkJuSXVJTktOYlZLRVRyNVp1dEdKU2VOam16U0hJYVZaWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM1OTU7czoxOiJjIjtpOjE0MDgzNTM1OTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353595),
('8e99f3bf13ccf40140060a3d6048197a4ad2557c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUFg0VjFGWWU2OXc5WEVzbDNnVmRZVkJmcGU4SGJxcE5zd2xVYlk4aCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNjQyMTQ7czoxOiJjIjtpOjE0MDgzNjQyMTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408364214),
('903504659ed4139026bf6f5b5f0722588191ddc1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0ZVNnZldmpSb0MyT1pCSkdvNGpwSDc0WGxxdFBtcDhkQ015eUE2cyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTE7czoxOiJjIjtpOjE0MDgzNTI5NTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352951),
('907466ec4c288ff695c74fbea1dce1a0b6c5ccbd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHdLTmVhZHV2YnNKRDJ6ZVRBazdwQjZsWGZlWHJtZlo4Y3pSdW1BZiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTg7czoxOiJjIjtpOjE0MDgzNTI5MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352919),
('9089cb3eda229a714d398d0649f16f276d2e704e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaExoZkk5bjJRcDhDQlJJZmlxQXNPS1BrclhSdTdMOTBHMHpHanRhWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTI7czoxOiJjIjtpOjE0MDgzNTI5NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352952),
('97909ebb15ac5a93d71ac0815e8a9659bc8dff9d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkpkNEdqaDFhc2M2ZVBlNTl5MzlldTdHQWZtOXhhSUxmaVRIQXJUOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5Mzk7czoxOiJjIjtpOjE0MDgzNTI5Mzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352939),
('9b03cf9888d7beb326419e41057038a09fed0eff', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid0lYenNzU1NCTUI1d2U1Z1FUYkdTZnFGMzlJaU50ZVFXc0dKUGpmdyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTI7czoxOiJjIjtpOjE0MDgzNTI5MTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352912),
('9de57df3fd1d02c579b5a45fa494200554e1148c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2dtSXdEQnpzRFd0cElYVWFiZ0Z4MzhpRDNmNFgxZ0ltZlN1OTJHSiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM1OTc7czoxOiJjIjtpOjE0MDgzNTM1OTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353598),
('a28c77b5488b1cf5077913aa158bb5bd6c0853b4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTEdpUWt6dDhRSzM4UTM5aUc5WEduMDRSNzY5RXp6MFRhcnB2WHZQaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTc7czoxOiJjIjtpOjE0MDgzNTI5MTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352918),
('a3d80aef19be24dfcea4da3c43730ecf9790599f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTFnWkxMaEhBVUNESXcxNkx3NWVpSWlxYnBpcDVpcXJBWm5PYURnMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzU7czoxOiJjIjtpOjE0MDgzNTI5MzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352936),
('a6dd74199f6611781fd0f0c7962ef5b67127c127', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibHd6cTR3cGhob095dlVIczJVUnYwbnlBUk1YOGNaTjJ5RERHZlE3NCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4NDI7czoxOiJjIjtpOjE0MDgzNTM4NDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353842),
('abf3c370630aa617897496bd64fba569c3126d60', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMGI3NFNKemQ2VURzT3dHeG9yTGlVZGh2OU5CZEJEWmRMQkRUNnUwYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzY7czoxOiJjIjtpOjE0MDgzNTI5MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352936),
('b080c7412aedc781ddabfe5dc21dced3c52118d3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2pjOG5BZFVTODRmMkZ2Q3gyM2h6VlN5aW1KdXl4RXhCa2RGTTdJcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTQ7czoxOiJjIjtpOjE0MDgzNTI5MTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352914),
('b10f9f3cd7e38d8574a159014d933c861a81dcae', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiazUxRXhZVHdCaXhBNUpuTGFscjBYSlhlSFM0SXVuWFlFVDFkSDZDbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5Mjc7czoxOiJjIjtpOjE0MDgzNTI5Mjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352927),
('c1377b5e01d08d2d91aa2024a96aa34c813fda68', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRWpIUlh5cjJNWmQwekpLaGt0eHhnMTltcDFXQUVBNVZEd21teEhDdSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTI7czoxOiJjIjtpOjE0MDgzNTI5MTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352912),
('c1f92ca170bf0b712ecbd50f046b44307d72fd15', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3VLTG9sN3h0SWlGRGVtT0lTeWpDOHB0WlRmTEJmSlhjeUg0N25UMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTg7czoxOiJjIjtpOjE0MDgzNTI5MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352919),
('c2e9e1cfb0dc63568b4a0e6540335f27f6b1f73b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWk9tWU5jSm0yU1M5MkJWN04wQUxFSVVUQTNTekJsZThGT0c2MTFkMyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTI7czoxOiJjIjtpOjE0MDgzNTI5NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352953),
('c9272b972639646c8d0d7cab08e4508074981a30', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibk9ZbkRsWDJJOXd4WmZpMU5RRmNyQUVnY3M2a29QaXhwaG8xOXpUWSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTk7czoxOiJjIjtpOjE0MDgzNTI5NTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352959),
('cae1ed0bfd0decd5e82af4c5899c0cab492cae7d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGthQnppejdMRVNyd0hXeTFwYlRqOFFOODVEZ2p1Zm1PSnJ1YUxiOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTk4Mjg7czoxOiJjIjtpOjE0MDgzNTk4Mjg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408359829),
('cb7befc9548b00043f089f1cd56921c947180eb4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDNscjEyeG15cTA1RGhLSW9SQXFxaDd2NXZqOExkcmx4SjZ3RUdjTiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTc7czoxOiJjIjtpOjE0MDgzNTI5MTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352918),
('cfdafa5d8e8daac2254e9846b8f36dd6dc4dee9d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT1BraFpWY0Z2SlZFM3NvNWhRWnNBU0NRT1JEQUE3cE9rWWhSczNDMiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MjE7czoxOiJjIjtpOjE0MDgzNTI5MjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352921),
('d1d1e3b1625c16846ceceee063a3a06f245db49b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoielhhYnA3MUhQZExlV0lMeTdkWGlLQjdLWjMxVThJbXhzRlV0ZWV0OCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MjQ7czoxOiJjIjtpOjE0MDgzNTI5MjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352925),
('d275ae774db870a5e69badfcf38812445f5a25eb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTYwYVpzaTV2cVhFb0U0ZlRmWnZueDVWZHZXbWpXd1dWa2drRlpLeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTMxOTg7czoxOiJjIjtpOjE0MDgzNTMxOTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353198),
('d3e3e5e06822c9a48fe4b207ec74a664e2af092d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidzdKRWZvUjlMMU1uZUpocXNhVG8zNkdPMEdXbjJlbDkzQzBjamQwZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MzU7czoxOiJjIjtpOjE0MDgzNTI5MzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352935),
('d7602ced91b7747cb5154ac1a21cd72976c4667e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXFTbDRlUkpCVVhiUGpwYXhFRWtvWHM4V3E5N2d1VDlubk1ybXpDTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTk7czoxOiJjIjtpOjE0MDgzNTI5MTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352920),
('d8e95a1da62896fa7dc05a625be65f8bd3b0a3cc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTczclhMZThsMmlIeTlFT0FzcWpMd0NyTzhwbEQ4SzBLT0JRdHhjWCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4MzM7czoxOiJjIjtpOjE0MDgzNTM4MzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353833),
('dc64b32a92a28d503f8b9016d97c764e8d98e246', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN09QdGNHSFJJSG5mVkhNajh3ZWhxb0RHelAzamdhZjFJSkdaUkRhaSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5Mzk7czoxOiJjIjtpOjE0MDgzNTI5Mzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352939),
('de1dfb216d65db4cc8e411d3f33b65a6d827f282', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQktuQWZSc0RGbUg5WUJEakR6eE1IOWw1bjZTRThWRWsxUHZCUENmZiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTg7czoxOiJjIjtpOjE0MDgzNTI5NTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352958),
('e1a4f062dd403d8bf7ced1d2f66b69763f6f1012', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibE44dVZ2c29kMHlYdGNCdmV5UzZGZ2NVRk1qVTM5Y3lCaHlkQ0dGeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MjI7czoxOiJjIjtpOjE0MDgzNTI5MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352922),
('e3bf4b3c987d9e53bf85d6b9fb28d0eb142a96c7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTlmQ01neWJTelZva1ZBZlB6aTJnNUFRQ2FhaXpNc1YwY21WMlpmSiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTU7czoxOiJjIjtpOjE0MDgzNTI5MTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352915),
('e460987e51d76cfb4954c0c81b0489120b6dc81b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZFBCak9rbmpQdFZsWEdQNzdyWnNjQUhIRkpCTmVoTGN0bzZQQ0RPTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTQ7czoxOiJjIjtpOjE0MDgzNTI5NTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352955),
('e5edd5098022092214806517d2150d5a0e340379', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid1ZXTW9wQkpCaW9TaFlZSTFLQjh4Mjd1c2U0YllGc0lNVTg4ZlhVbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MDk7czoxOiJjIjtpOjE0MDgzNTI5MDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352909),
('e648a12e2e9bfe6370104963a7821d3ffce6a842', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia1k1ZzQ4MXpJb3Q4b0xncHFzVHhrZnZpT0NPaTJkVVpFZWoyd2x0TiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5NTQ7czoxOiJjIjtpOjE0MDgzNTI5NTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352954),
('e8effafb32103682b108a895e0de483409a7f4fc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYUhIT2hjbGUyaldiTmtKWlZVM2cydnFZaTJxaHd1bHZFQzVGTGp0MCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNjM0Mjk7czoxOiJjIjtpOjE0MDgzNjM0Mjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408363429),
('eab6a7d7fcf9367574b07af1010acfc7ef1d16b5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWm03OUVrdXFFcGRBZm1xN0w2V1h2MFBUeU15YzVuR1lzTkZuNGYwZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTM4MjY7czoxOiJjIjtpOjE0MDgzNTM4MjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408353826),
('f18af0b6fd581eadb38549d0713fe3a37e5fcbea', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidk5qdXNXMjhLc3FMVG9OZm05V1I4ZEVJR3QwaW5DbnRMaGRSODhNbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTc7czoxOiJjIjtpOjE0MDgzNTI5MTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352918),
('f22d27a42e785bf4469ee299c8b57c1fdc81d234', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOHZQSGN5QU9DVTNLbTJxb3pST0hLNnBycmQyc1R4bVFkZGdiQWxnQSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNjQ4Njc7czoxOiJjIjtpOjE0MDgzNjQ4Njc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408364872),
('fbefa7cf5a1877c99bbeca821c8294f89149a83a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMmVQbVFackpxaDZYRU5rUHRQQmpLQ29nN0dCM1JURnF1R3hzVG94RiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTEzNTQ7czoxOiJjIjtpOjE0MDgzNTEzNTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408351354),
('fffc848389a43c5ad1c5124015f2fb5e4a4a7418', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTl4UEExM3dlZHJtRThJUkZiVTFqWFdJbmVFbnhVU2pKMXhiVDVkeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzNTI5MTc7czoxOiJjIjtpOjE0MDgzNTI5MTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408352918);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-07-31 11:11:01', '2014-07-31 11:11:01');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `tag` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_module_unit_id_tag_unique` (`module`,`unit_id`,`tag`),
  KEY `tags_module_index` (`module`),
  KEY `tags_module_unit_id_index` (`module`,`unit_id`),
  KEY `tags_tag_index` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@infiniti-gedon.ru', 1, '$2y$10$TgZ.n2ih/yOxxMKgiEl.Uu7zWsCBM6wF/ILTnKwFcT8hSodPoonYG', '', '', '', 0, 'Q38vPtDXED0urRxZlmHmOvTh7qmvRL0mRLcwLGQazTjjK6XXmhTd1jqkeR8H', '2014-07-31 11:11:00', '2014-07-31 11:11:33'),
(2, 2, 'Пользователь', '', 'user@infiniti-gedon.ru', 1, '$2y$10$C/4m6SMOWkjVlrN63CBmRuUkW7PmAd.HkB9dtWV4Ky7uhrlqIsE7i', '', '', '', 0, NULL, '2014-07-31 11:11:00', '2014-07-31 11:11:00'),
(3, 3, 'Модератор', '', 'moder@infiniti-gedon.ru', 1, '$2y$10$H6tRPiRo7pOQfmfVTl1Fs..TualCzyl9zihCaj5XpIP/Qtb60E4m6', '', '', '', 0, NULL, '2014-07-31 11:11:01', '2014-07-31 11:11:01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
